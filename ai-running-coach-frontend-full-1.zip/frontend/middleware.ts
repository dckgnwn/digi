import { NextResponse, type NextRequest } from 'next/server';
import { isJwtExpiringSoon } from './lib/jwt-decode';

const ACCESS_COOKIE = 'apex_access_token';
const REFRESH_COOKIE = 'apex_refresh_token';
const AUTH_PAGES = new Set(['/login', '/register', '/forgot-password', '/reset-password', '/verify-email']);
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000/api';

const ACCESS_COOKIE_MAX_AGE_SEC = 60 * 60;
const REFRESH_COOKIE_MAX_AGE_SEC = 30 * 24 * 60 * 60;

/**
 * Middleware ini melakukan DUA hal:
 *  1. Proteksi route murah (cek keberadaan & freshness cookie access token).
 *  2. SILENT REFRESH transparan: jika access token kadaluarsa/hampir
 *     kadaluarsa tapi refresh token masih ada & valid, middleware memanggil
 *     backend /v1/auth/refresh SENDIRI (Edge runtime mendukung fetch),
 *     lalu menuliskan cookie pasangan token baru ke response — sebelum
 *     Server Component manapun sempat merender. Ini penting karena Server
 *     Component (page.tsx/layout.tsx) TIDAK BISA menulis cookie saat
 *     render (batasan Next.js App Router) — hanya middleware & Route
 *     Handler yang bisa.
 *
 * Verifikasi signature JWT yang sesungguhnya tetap SELALU dilakukan backend
 * Express di setiap request (src/middleware/auth.js) — decode di sini hanya
 * heuristik murah untuk keputusan UX, bukan mekanisme keamanan.
 */
export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const isAuthPage = AUTH_PAGES.has(pathname);

  const accessToken = request.cookies.get(ACCESS_COOKIE)?.value;
  const refreshToken = request.cookies.get(REFRESH_COOKIE)?.value;

  const accessTokenStillFresh = accessToken && !isJwtExpiringSoon(accessToken, 60);

  if (accessTokenStillFresh) {
    if (isAuthPage) return NextResponse.redirect(new URL('/', request.url));
    return NextResponse.next();
  }

  // Access token tidak ada / hampir kadaluarsa — coba silent refresh jika ada refresh token.
  if (refreshToken) {
    try {
      const refreshRes = await fetch(`${API_BASE_URL}/v1/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken }),
      });

      if (refreshRes.ok) {
        const data = await refreshRes.json();
        const response = isAuthPage
          ? NextResponse.redirect(new URL('/', request.url))
          : NextResponse.next();

        response.cookies.set(ACCESS_COOKIE, data.accessToken, { path: '/', maxAge: ACCESS_COOKIE_MAX_AGE_SEC });
        response.cookies.set(REFRESH_COOKIE, data.refreshToken, { path: '/', maxAge: REFRESH_COOKIE_MAX_AGE_SEC });
        return response;
      }
    } catch {
      // Jaringan/refresh gagal — lanjut ke logika redirect di bawah.
    }
  }

  if (isAuthPage) return NextResponse.next();

  const response = NextResponse.redirect(new URL('/login', request.url));
  response.cookies.delete(ACCESS_COOKIE);
  response.cookies.delete(REFRESH_COOKIE);
  return response;
}

export const config = {
  matcher: [
    '/',
    '/calendar',
    '/onboarding',
    '/login',
    '/register',
    '/forgot-password',
    '/reset-password',
    '/verify-email',
  ],
};
