// -----------------------------------------------------------------------
// lib/api.ts
// -----------------------------------------------------------------------
// Klien fetch tipeup ke backend Express. Untuk panggilan CLIENT-SIDE
// (browser, tanpa parameter token eksplisit): jika request pertama gagal
// 401, api.ts mencoba refresh token SEKALI (single-flight — lihat
// _tryRefreshTokens) lalu mengulang request itu sekali. Untuk panggilan
// SERVER-SIDE (Server Component, token dioper eksplisit dari cookie):
// TIDAK ada retry di sini karena middleware.ts sudah menjamin token segar
// sebelum request sampai ke Server Component.
// -----------------------------------------------------------------------

import { clearAuthTokens, getAccessToken, getRefreshToken, setAuthTokens } from './auth-client';
import type {
  AthleteBaseline,
  AuthResult,
  AvailabilityDay,
  CalendarEvent,
  ChatMessage,
  CoachBriefing,
  DailyPrescription,
  DashboardOverview,
  TelemetryPoint,
  User,
  VdotHistoryPoint,
} from './types';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000/api';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

// ---------------------------------------------------------------------------
// SINGLE-FLIGHT TOKEN REFRESH (client-side)
// ---------------------------------------------------------------------------
// PENTING: backend merotasi refresh token setiap dipakai dan MENOLAK token
// yang sudah dipakai (reuse detection -> logout paksa semua sesi). Jika dua
// request client 401 bersamaan masing-masing mencoba refresh sendiri-sendiri
// dengan refresh token yang SAMA, permintaan kedua akan dianggap "reuse" dan
// mengunci seluruh sesi user. Single-flight promise di bawah memastikan
// HANYA SATU panggilan refresh nyata terjadi; pemanggil lain ikut menunggu
// promise yang sama.

let refreshPromise: Promise<{ accessToken: string; refreshToken: string } | null> | null = null;

function tryRefreshTokens(): Promise<{ accessToken: string; refreshToken: string } | null> {
  if (!refreshPromise) {
    refreshPromise = (async () => {
      const refreshToken = getRefreshToken();
      if (!refreshToken) return null;
      try {
        const res = await fetch(`${API_BASE_URL}/v1/auth/refresh`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken }),
        });
        if (!res.ok) {
          clearAuthTokens();
          return null;
        }
        const data = await res.json();
        setAuthTokens(data.accessToken, data.refreshToken);
        return { accessToken: data.accessToken, refreshToken: data.refreshToken };
      } catch {
        return null;
      } finally {
        refreshPromise = null;
      }
    })();
  }
  return refreshPromise;
}

// ---------------------------------------------------------------------------
// FETCH GENERIK
// ---------------------------------------------------------------------------

async function _doFetch(path: string, init: RequestInit | undefined, authToken: string | null): Promise<Response> {
  return fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
      ...(init?.headers || {}),
    },
    cache: 'no-store',
  });
}

async function _parseOrThrow<T>(response: Response, path: string): Promise<T> {
  if (!response.ok) {
    let message = `Request ke ${path} gagal (HTTP ${response.status})`;
    try {
      const body = await response.json();
      if (body?.error) message = body.error;
    } catch {
      // respons bukan JSON — pertahankan pesan default
    }
    throw new ApiError(message, response.status);
  }
  if (response.status === 204) return undefined as T;
  const text = await response.text();
  return (text ? JSON.parse(text) : null) as T;
}

async function apiFetch<T>(path: string, init?: RequestInit, explicitToken?: string): Promise<T> {
  const isServerCall = explicitToken !== undefined;
  const authToken = explicitToken ?? getAccessToken();

  let response = await _doFetch(path, init, authToken);

  if (response.status === 401 && !isServerCall) {
    const refreshed = await tryRefreshTokens();
    if (refreshed) {
      response = await _doFetch(path, init, refreshed.accessToken);
    }
  }

  return _parseOrThrow<T>(response, path);
}

// ---------------------------------------------------------------------------
// AUTH
// ---------------------------------------------------------------------------

export function registerUser(payload: {
  email: string;
  password: string;
  fullName: string;
  weightKg?: number;
  heightCm?: number;
}): Promise<AuthResult> {
  return apiFetch<AuthResult>('/v1/auth/register', { method: 'POST', body: JSON.stringify(payload) });
}

export function loginUser(payload: { email: string; password: string }): Promise<AuthResult> {
  return apiFetch<AuthResult>('/v1/auth/login', { method: 'POST', body: JSON.stringify(payload) });
}

export function logoutUser(): Promise<void> {
  const refreshToken = getRefreshToken();
  return apiFetch<void>('/v1/auth/logout', { method: 'POST', body: JSON.stringify({ refreshToken }) });
}

export function getMe(token?: string): Promise<User> {
  return apiFetch<User>('/v1/auth/me', undefined, token);
}

export function verifyEmail(token: string): Promise<{ message: string }> {
  return apiFetch<{ message: string }>('/v1/auth/verify-email', { method: 'POST', body: JSON.stringify({ token }) });
}

export function resendVerificationEmail(): Promise<{ message: string }> {
  return apiFetch<{ message: string }>('/v1/auth/resend-verification', { method: 'POST' });
}

export function forgotPassword(email: string): Promise<{ message: string }> {
  return apiFetch<{ message: string }>('/v1/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) });
}

export function resetPassword(token: string, newPassword: string): Promise<{ message: string }> {
  return apiFetch<{ message: string }>('/v1/auth/reset-password', {
    method: 'POST',
    body: JSON.stringify({ token, newPassword }),
  });
}

// ---------------------------------------------------------------------------
// ATHLETE BASELINE / ONBOARDING
// ---------------------------------------------------------------------------

export function getBaseline(token?: string): Promise<AthleteBaseline | null> {
  return apiFetch<AthleteBaseline | null>('/v1/athlete/baseline', undefined, token);
}

export function saveBaseline(payload: AthleteBaseline): Promise<AthleteBaseline> {
  return apiFetch<AthleteBaseline>('/v1/athlete/baseline', { method: 'PUT', body: JSON.stringify(payload) });
}

// ---------------------------------------------------------------------------
// DASHBOARD
// ---------------------------------------------------------------------------

export function getDashboardOverview(token?: string): Promise<DashboardOverview> {
  return apiFetch<DashboardOverview>('/v1/dashboard/overview', undefined, token);
}

export function getCoachBriefing(token?: string): Promise<CoachBriefing | null> {
  return apiFetch<CoachBriefing | null>('/v1/dashboard/briefing', undefined, token);
}

export function getTodayPrescription(token?: string): Promise<DailyPrescription | null> {
  return apiFetch<DailyPrescription | null>('/v1/dashboard/today-prescription', undefined, token);
}

export function requestScheduleAdjustment(): Promise<{ message: string }> {
  return apiFetch<{ message: string }>('/v1/coach/request-adjustment', { method: 'POST' });
}

export function triggerStravaSync(): Promise<{ synced: boolean; newActivities: number }> {
  return apiFetch<{ synced: boolean; newActivities: number }>('/v1/strava/sync', { method: 'POST' });
}

// ---------------------------------------------------------------------------
// KALENDER & AVAILABILITY
// ---------------------------------------------------------------------------

export function getCalendarEvents(fromISO: string, toISO: string, token?: string): Promise<CalendarEvent[]> {
  return apiFetch<CalendarEvent[]>(`/v1/calendar/events?from=${fromISO}&to=${toISO}`, undefined, token);
}

export function getAvailability(token?: string): Promise<AvailabilityDay[]> {
  return apiFetch<AvailabilityDay[]>('/v1/availability', undefined, token);
}

export function saveAvailability(days: AvailabilityDay[]): Promise<void> {
  return apiFetch<void>('/v1/availability', { method: 'PUT', body: JSON.stringify({ days }) });
}

// ---------------------------------------------------------------------------
// ANALYTICS
// ---------------------------------------------------------------------------

export function getActivityTelemetry(executedActivityId: string, token?: string): Promise<TelemetryPoint[]> {
  return apiFetch<TelemetryPoint[]>(`/v1/activities/${encodeURIComponent(executedActivityId)}/telemetry`, undefined, token);
}

export function getVdotHistory(token?: string): Promise<VdotHistoryPoint[]> {
  return apiFetch<VdotHistoryPoint[]>('/v1/athletes/vdot-history', undefined, token);
}

// ---------------------------------------------------------------------------
// CHAT COACH
// ---------------------------------------------------------------------------

export function sendChatMessage(message: string): Promise<ChatMessage> {
  return apiFetch<ChatMessage>('/v1/coach/chat', { method: 'POST', body: JSON.stringify({ message }) });
}
