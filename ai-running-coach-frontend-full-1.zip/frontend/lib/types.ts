// -----------------------------------------------------------------------
// lib/types.ts
// Tipe-tipe ini SENGAJA dicerminkan persis dari kontrak backend Fase 1-3
// (schema.sql, scienceEngine.js, geminiCoachService.js) agar frontend dan
// backend tidak pernah "berbeda pemahaman" soal bentuk data.
// -----------------------------------------------------------------------

export type SessionType = 'EASY' | 'INTERVAL' | 'TEMPO' | 'LONG_RUN' | 'GYM' | 'REST' | 'RACE' | 'STRICT_ZONE1_WALK';

export type ActivityPreference = 'REST' | 'EASY' | 'INTERVAL' | 'TEMPO' | 'LONG_RUN' | 'GYM';

export type EquipmentType = 'FULL_GYM' | 'HOME_DUMBBELL' | 'BODYWEIGHT';

/** Status TSB yang disederhanakan untuk tampilan UI (spec: Fresh/Optimal/Overreaching). */
export type ReadinessStatus = 'FRESH' | 'OPTIMAL' | 'OVERREACHING';

export interface DashboardOverview {
  readinessScorePct: number; // 0-100, turunan dari TSB (lihat lib/utils readiness mapping di komponen)
  tsb: number;
  ctl: number;
  atl: number;
  readinessStatus: ReadinessStatus;
  lastStravaSyncAt: string | null; // ISO datetime, null jika belum pernah sync
  lastExecutedActivityId: string | null; // dipakai untuk memuat CardiacDriftChart aktivitas terakhir
  lastActivityCardiacDriftPct: number | null;
}

export interface CoachBriefing {
  auditSummary: string;
  verdict: 'COMPLIANT' | 'EGO_RUNNING_JUNK_MILES' | 'UNDERPERFORMED' | 'HIGH_HR_LOW_PACE_INVESTIGATE' | 'OTHER';
  reprimandMessage: string | null;
  generatedAt: string; // ISO datetime
}

export interface PrescriptionDrill {
  name: string;
  sets: number;
  distance_m: number;
  notes: string;
}

export interface PrescriptionRunSegment {
  segment: string;
  duration_minutes: number;
  distance_km: number;
  target_pace: string; // "M:SS"
  target_hr: number;
  recovery_minutes: number;
}

export interface PrescriptionMainRun {
  description: string;
  target_distance_km: number;
  target_duration_minutes: number;
  target_pace_min_sec_km: string; // "M:SS", batas tercepat
  target_pace_max_sec_km: string; // "M:SS", batas terlambat
  target_hr_min: number;
  target_hr_max: number;
  structure: PrescriptionRunSegment[];
}

export interface GymExercise {
  name: string;
  sets: number;
  reps: number;
  load_guidance: string;
  rpe: number;
}

export interface DailyPrescription {
  session_date: string;
  session_type: SessionType;
  weather_adjusted: boolean;
  warmup: {
    duration_minutes: number;
    description: string;
    drills: string[];
  };
  running_drills: PrescriptionDrill[];
  main_run: PrescriptionMainRun;
  gym_strength: {
    required: boolean;
    sequence_after_run: boolean;
    exercises: GymExercise[];
  };
  cooldown: {
    duration_minutes: number;
    description: string;
  };
  nutrition: {
    pre_workout: string;
    during_workout: string;
    post_workout: string;
    hydration_notes: string;
  };
  coach_notes: string;
}

export type CalendarEventType = 'COMPLETED_RUN' | 'SCHEDULED_RUN' | 'GYM' | 'RACE_DAY';

export interface CalendarEvent {
  id: string;
  date: string; // YYYY-MM-DD
  type: CalendarEventType;
  title: string;
  sessionType?: SessionType;
  distanceKm?: number | null;
  isCompleted: boolean;
}

export interface AvailabilityDay {
  dayOfWeek: number; // 0=Minggu .. 6=Sabtu
  activityPreference: ActivityPreference;
  maxDurationMinutes: number;
  equipmentType: EquipmentType | null;
}

export interface TelemetryPoint {
  t: number; // detik sejak start
  heart_rate: number | null;
  pace_sec_km: number | null;
  speed_mps: number | null;
}

export interface VdotHistoryPoint {
  date: string; // YYYY-MM-DD
  vdot: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'coach';
  content: string;
  createdAt: string;
}

export interface User {
  id: string;
  email: string;
  full_name: string;
  weight_kg: number | null;
  height_cm: number | null;
  email_verified: boolean;
  created_at: string;
}

export interface AuthResult {
  accessToken: string;
  refreshToken: string;
  user: User;
}

export interface AthleteBaseline {
  maxHr: number;
  lthr: number;
  restingHr: number;
  vdot: number | null;
  targetRaceName: string | null;
  targetRaceDistanceKm: number | null;
  targetRaceDate: string | null; // YYYY-MM-DD
  targetRaceTimeSeconds: number | null;
}

