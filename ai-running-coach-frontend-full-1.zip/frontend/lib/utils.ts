import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Gabungkan className Tailwind dengan aman (menghindari konflik utility). */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** Format total detik menjadi "M:SS" (konvensi tampilan pace lari). */
export function formatPaceFromSec(totalSec: number | null | undefined): string {
  if (totalSec == null || !isFinite(totalSec) || totalSec < 0) return '--:--';
  const rounded = Math.round(totalSec);
  const minutes = Math.floor(rounded / 60);
  const seconds = rounded % 60;
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

/** Parse string pace "M:SS" menjadi total detik. */
export function parsePaceToSec(pace: string): number {
  const [m, s] = pace.split(':').map(Number);
  return (m || 0) * 60 + (s || 0);
}

/** Format tanggal ISO ("2026-09-17") menjadi label pendek berbahasa Indonesia. */
export function formatDateLabel(dateStr: string, opts: { weekday?: boolean } = {}): string {
  const date = new Date(`${dateStr}T00:00:00`);
  return new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'short',
    weekday: opts.weekday ? 'short' : undefined,
  }).format(date);
}

/** Format angka menit menjadi "1j 15m" atau "45m". */
export function formatDurationMinutes(minutes: number | null | undefined): string {
  if (minutes == null || !isFinite(minutes)) return '--';
  const total = Math.round(minutes);
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (h === 0) return `${m}m`;
  return `${h}j ${m}m`;
}

/** Nama hari (0=Minggu ... 6=Sabtu) sesuai konvensi day_of_week backend. */
export const DAY_NAMES_ID = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', "Jum'at", 'Sabtu'];
export const DAY_NAMES_SHORT_ID = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

export function toISODateOnly(date: Date): string {
  return date.toISOString().slice(0, 10);
}

export function addDaysToISO(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return toISODateOnly(d);
}
