'use client';

// -----------------------------------------------------------------------
// lib/auth-client.ts
// -----------------------------------------------------------------------
// Menyimpan PASANGAN token (access pendek-umur + refresh panjang-umur) di
// localStorage (dipakai Client Component memanggil API langsung dari
// browser) DAN di cookie biasa (dibaca middleware.ts & Server Component).
// -----------------------------------------------------------------------

const ACCESS_TOKEN_KEY = 'apex_access_token';
const REFRESH_TOKEN_KEY = 'apex_refresh_token';
const ACCESS_COOKIE_NAME = 'apex_access_token';
const REFRESH_COOKIE_NAME = 'apex_refresh_token';

const ACCESS_COOKIE_MAX_AGE_SEC = 60 * 60; // 1 jam — sekadar batas atas cookie, freshness sebenarnya dari exp JWT
const REFRESH_COOKIE_MAX_AGE_SEC = 30 * 24 * 60 * 60; // selaras REFRESH_TOKEN_TTL_DAYS default backend

export function setAuthTokens(accessToken: string, refreshToken: string): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
  window.localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
  document.cookie = `${ACCESS_COOKIE_NAME}=${accessToken}; path=/; max-age=${ACCESS_COOKIE_MAX_AGE_SEC}; SameSite=Lax`;
  document.cookie = `${REFRESH_COOKIE_NAME}=${refreshToken}; path=/; max-age=${REFRESH_COOKIE_MAX_AGE_SEC}; SameSite=Lax`;
}

export function getAccessToken(): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem(ACCESS_TOKEN_KEY);
}

export function getRefreshToken(): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem(REFRESH_TOKEN_KEY);
}

export function clearAuthTokens(): void {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(ACCESS_TOKEN_KEY);
  window.localStorage.removeItem(REFRESH_TOKEN_KEY);
  document.cookie = `${ACCESS_COOKIE_NAME}=; path=/; max-age=0`;
  document.cookie = `${REFRESH_COOKIE_NAME}=; path=/; max-age=0`;
}
