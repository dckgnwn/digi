// -----------------------------------------------------------------------
// lib/jwt-decode.ts
// -----------------------------------------------------------------------
// HANYA decode payload (base64url), TIDAK memverifikasi signature — dipakai
// sebagai optimisasi murah untuk memutuskan "apakah perlu refresh sekarang"
// di middleware Edge & browser. Verifikasi signature yang sesungguhnya
// SELALU dilakukan backend Express (src/middleware/auth.js) di setiap
// request — file ini bukan mekanisme keamanan, hanya heuristik UX.
// -----------------------------------------------------------------------

export interface DecodedJwtPayload {
  sub?: string;
  email?: string;
  exp?: number; // unix seconds
  [key: string]: unknown;
}

export function decodeJwtPayload(token: string): DecodedJwtPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length < 2) return null;
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
    const json = atob(padded);
    return JSON.parse(json) as DecodedJwtPayload;
  } catch {
    return null;
  }
}

/** true jika token tidak valid/tidak bisa didekode, atau kadaluarsa dalam <= bufferSeconds. */
export function isJwtExpiringSoon(token: string, bufferSeconds = 60): boolean {
  const payload = decodeJwtPayload(token);
  if (!payload || typeof payload.exp !== 'number') return true;
  const nowSec = Math.floor(Date.now() / 1000);
  return payload.exp - nowSec <= bufferSeconds;
}
