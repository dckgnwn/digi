import 'server-only';
import { cookies } from 'next/headers';

const ACCESS_COOKIE_NAME = 'apex_access_token';
const REFRESH_COOKIE_NAME = 'apex_refresh_token';

/**
 * Hanya boleh dipanggil dari Server Component / Route Handler. Nilai ini
 * SUDAH difreshkan oleh middleware.ts sebelum request sampai ke sini
 * (lihat middleware.ts) — Server Component tidak perlu memikirkan refresh.
 */
export function getServerAccessToken(): string | null {
  return cookies().get(ACCESS_COOKIE_NAME)?.value ?? null;
}

export function getServerRefreshToken(): string | null {
  return cookies().get(REFRESH_COOKIE_NAME)?.value ?? null;
}
