'use client';

import { useEffect, useState } from 'react';
import {
  addDays,
  addMonths,
  addWeeks,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  isToday,
  startOfMonth,
  startOfWeek,
  subMonths,
  subWeeks,
} from 'date-fns';
import { id as idLocale } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Dumbbell, Flag, Loader2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getCalendarEvents } from '@/lib/api';
import { cn, toISODateOnly } from '@/lib/utils';
import type { CalendarEvent, CalendarEventType } from '@/lib/types';

type ViewMode = 'week' | 'month';

const EVENT_DOT_CLASS: Record<CalendarEventType, string> = {
  COMPLETED_RUN: 'bg-success',
  SCHEDULED_RUN: 'bg-secondary',
  GYM: 'bg-gym',
  RACE_DAY: 'bg-race',
};

const LEGEND_ITEMS: { type: CalendarEventType; label: string }[] = [
  { type: 'COMPLETED_RUN', label: 'Completed Run (Strava)' },
  { type: 'SCHEDULED_RUN', label: 'Scheduled Run (AI Coach)' },
  { type: 'GYM', label: 'Gym Strength' },
  { type: 'RACE_DAY', label: 'Target Race Day' },
];

interface CalendarViewProps {
  initialEvents: CalendarEvent[];
  initialAnchorDate: string; // YYYY-MM-DD
}

function getRange(anchor: Date, view: ViewMode): { start: Date; end: Date } {
  if (view === 'week') {
    return { start: startOfWeek(anchor), end: endOfWeek(anchor) };
  }
  return { start: startOfWeek(startOfMonth(anchor)), end: endOfWeek(endOfMonth(anchor)) };
}

export function CalendarView({ initialEvents, initialAnchorDate }: CalendarViewProps) {
  const [view, setView] = useState<ViewMode>('month');
  const [anchor, setAnchor] = useState<Date>(new Date(`${initialAnchorDate}T00:00:00`));
  const [events, setEvents] = useState<CalendarEvent[]>(initialEvents);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(initialAnchorDate);

  const { start, end } = getRange(anchor, view);
  const days = eachDayOfInterval({ start, end });

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    getCalendarEvents(toISODateOnly(start), toISODateOnly(end))
      .then((data) => {
        if (!cancelled) setEvents(data);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Gagal memuat kalender.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, anchor.getTime()]);

  function goPrev() {
    setAnchor((d) => (view === 'week' ? subWeeks(d, 1) : subMonths(d, 1)));
  }
  function goNext() {
    setAnchor((d) => (view === 'week' ? addWeeks(d, 1) : addMonths(d, 1)));
  }
  function goToday() {
    const now = new Date();
    setAnchor(now);
    setSelectedDate(toISODateOnly(now));
  }

  function eventsForDay(day: Date): CalendarEvent[] {
    const iso = toISODateOnly(day);
    return events.filter((e) => e.date === iso);
  }

  const selectedDayEvents = selectedDate ? events.filter((e) => e.date === selectedDate) : [];

  return (
    <Card>
      <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <CardTitle>{format(anchor, view === 'week' ? "'Minggu' d MMM yyyy" : 'MMMM yyyy', { locale: idLocale })}</CardTitle>
          {loading && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
        </div>
        <div className="flex items-center gap-2">
          <Tabs value={view} onValueChange={(v: string) => setView(v as ViewMode)}>
            <TabsList>
              <TabsTrigger value="week">Mingguan</TabsTrigger>
              <TabsTrigger value="month">Bulanan</TabsTrigger>
            </TabsList>
          </Tabs>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" onClick={goPrev} aria-label="Sebelumnya">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToday}>
              Hari Ini
            </Button>
            <Button variant="outline" size="icon" onClick={goNext} aria-label="Berikutnya">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {error && <p className="text-sm text-danger">{error}</p>}

        {/* Legend */}
        <div className="flex flex-wrap gap-x-4 gap-y-1.5">
          {LEGEND_ITEMS.map((item) => (
            <div key={item.type} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className={cn('h-2 w-2 rounded-full', EVENT_DOT_CLASS[item.type])} />
              {item.label}
            </div>
          ))}
        </div>

        {/* Grid header hari */}
        <div className="grid grid-cols-7 gap-1.5 text-center text-xs text-muted-foreground">
          {['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map((d) => (
            <div key={d}>{d}</div>
          ))}
        </div>

        {/* Grid tanggal */}
        <div className={cn('grid grid-cols-7 gap-1.5', view === 'month' ? 'auto-rows-[5.5rem]' : 'auto-rows-[7rem]')}>
          {days.map((day: Date) => {
            const iso = toISODateOnly(day);
            const dayEvents = eventsForDay(day);
            const outsideMonth = view === 'month' && !isSameMonth(day, anchor);
            const isSelected = selectedDate === iso;

            return (
              <button
                key={iso}
                onClick={() => setSelectedDate(iso)}
                className={cn(
                  'flex flex-col items-start gap-1 rounded-md border p-1.5 text-left transition-colors',
                  outsideMonth ? 'border-transparent text-muted-foreground/50' : 'border-border hover:bg-muted/40',
                  isSelected && 'border-primary ring-1 ring-primary',
                  isToday(day) && !isSelected && 'border-secondary/60'
                )}
              >
                <span
                  className={cn(
                    'tabular-stat text-xs font-medium',
                    isToday(day) && 'flex h-5 w-5 items-center justify-center rounded-full bg-secondary text-secondary-foreground'
                  )}
                >
                  {format(day, 'd')}
                </span>
                <div className="flex flex-wrap gap-1">
                  {dayEvents.slice(0, 4).map((e) => (
                    <span key={e.id} className={cn('h-1.5 w-1.5 rounded-full', EVENT_DOT_CLASS[e.type])} title={e.title} />
                  ))}
                </div>
              </button>
            );
          })}
        </div>

        {/* Detail hari terpilih */}
        {selectedDate && (
          <div className="rounded-md border border-border p-4">
            <h4 className="mb-2 text-sm font-medium">
              {format(new Date(`${selectedDate}T00:00:00`), 'EEEE, d MMMM yyyy', { locale: idLocale })}
            </h4>
            {selectedDayEvents.length === 0 ? (
              <p className="text-sm text-muted-foreground">Tidak ada event pada tanggal ini.</p>
            ) : (
              <ul className="space-y-2">
                {selectedDayEvents.map((e) => (
                  <li key={e.id} className="flex items-center gap-2 text-sm">
                    <span className={cn('h-2 w-2 rounded-full', EVENT_DOT_CLASS[e.type])} />
                    {e.type === 'GYM' && <Dumbbell className="h-3.5 w-3.5 text-gym" />}
                    {e.type === 'RACE_DAY' && <Flag className="h-3.5 w-3.5 text-race" />}
                    <span className="font-medium">{e.title}</span>
                    {e.distanceKm != null && (
                      <span className="tabular-stat text-muted-foreground">{e.distanceKm} km</span>
                    )}
                    {e.isCompleted && (
                      <span className="ml-auto text-xs text-success">Selesai</span>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
