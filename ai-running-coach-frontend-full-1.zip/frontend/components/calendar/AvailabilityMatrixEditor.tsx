'use client';

import { useState } from 'react';
import { Check, Loader2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { saveAvailability } from '@/lib/api';
import { DAY_NAMES_ID } from '@/lib/utils';
import type { ActivityPreference, AvailabilityDay, EquipmentType } from '@/lib/types';

const ACTIVITY_OPTIONS: { value: ActivityPreference; label: string }[] = [
  { value: 'REST', label: 'Rest' },
  { value: 'EASY', label: 'Easy Run' },
  { value: 'INTERVAL', label: 'Interval' },
  { value: 'TEMPO', label: 'Tempo' },
  { value: 'LONG_RUN', label: 'Long Run' },
  { value: 'GYM', label: 'Gym' },
];

const EQUIPMENT_OPTIONS: { value: EquipmentType; label: string }[] = [
  { value: 'FULL_GYM', label: 'Full Gym' },
  { value: 'HOME_DUMBBELL', label: 'Dumbbell Rumahan' },
  { value: 'BODYWEIGHT', label: 'Bodyweight' },
];

function buildDefaultWeek(existing: AvailabilityDay[]): AvailabilityDay[] {
  return Array.from({ length: 7 }, (_, dayOfWeek) => {
    const found = existing.find((d) => d.dayOfWeek === dayOfWeek);
    return (
      found ?? {
        dayOfWeek,
        activityPreference: 'REST' as ActivityPreference,
        maxDurationMinutes: 30,
        equipmentType: null,
      }
    );
  });
}

interface AvailabilityMatrixEditorProps {
  initialAvailability: AvailabilityDay[];
}

export function AvailabilityMatrixEditor({ initialAvailability }: AvailabilityMatrixEditorProps) {
  const [days, setDays] = useState<AvailabilityDay[]>(() => buildDefaultWeek(initialAvailability));
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function updateDay(dayOfWeek: number, patch: Partial<AvailabilityDay>) {
    setDays((prev) => prev.map((d) => (d.dayOfWeek === dayOfWeek ? { ...d, ...patch } : d)));
    setSaved(false);
  }

  async function handleSave() {
    setSaving(true);
    setError(null);
    try {
      await saveAvailability(days);
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal menyimpan availability.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Availability Matrix</CardTitle>
        <CardDescription>Atur preferensi aktivitas dan batas durasi untuk tiap hari dalam seminggu.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {days.map((day) => (
            <div
              key={day.dayOfWeek}
              className="grid grid-cols-1 items-center gap-2 rounded-md border border-border p-3 sm:grid-cols-[5rem_1fr_7rem_1fr]"
            >
              <span className="text-sm font-medium">{DAY_NAMES_ID[day.dayOfWeek]}</span>

              <Select
                value={day.activityPreference}
                onValueChange={(v: ActivityPreference) => updateDay(day.dayOfWeek, { activityPreference: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ACTIVITY_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex items-center gap-1">
                <Input
                  type="number"
                  min={0}
                  max={600}
                  value={day.maxDurationMinutes}
                  onChange={(e) => updateDay(day.dayOfWeek, { maxDurationMinutes: Number(e.target.value) })}
                  className="tabular-stat"
                />
                <span className="whitespace-nowrap text-xs text-muted-foreground">menit</span>
              </div>

              <Select
                value={day.equipmentType ?? undefined}
                disabled={day.activityPreference !== 'GYM'}
                onValueChange={(v: EquipmentType) => updateDay(day.dayOfWeek, { equipmentType: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Equipment" />
                </SelectTrigger>
                <SelectContent>
                  {EQUIPMENT_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between border-t border-border pt-4">
          {error && <span className="text-xs text-danger">{error}</span>}
          {saved && !error && (
            <span className="flex items-center gap-1 text-xs text-success">
              <Check className="h-3.5 w-3.5" />
              Tersimpan
            </span>
          )}
          {!error && !saved && <span />}
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {saving ? 'Menyimpan...' : 'Simpan Availability'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
