'use client';

import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { TrendingUp } from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatDateLabel } from '@/lib/utils';
import type { VdotHistoryPoint } from '@/lib/types';

interface VdotTrendChartProps {
  history: VdotHistoryPoint[];
}

export function VdotTrendChart({ history }: VdotTrendChartProps) {
  const sorted = [...history].sort((a, b) => a.date.localeCompare(b.date));
  const first = sorted[0]?.vdot;
  const last = sorted[sorted.length - 1]?.vdot;
  const delta = first != null && last != null ? Math.round((last - first) * 100) / 100 : null;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle>Tren VDOT</CardTitle>
        {delta != null && (
          <span className="tabular-stat flex items-center gap-1 text-xs font-medium text-success">
            <TrendingUp className="h-3.5 w-3.5" />
            {delta > 0 ? '+' : ''}
            {delta} poin
          </span>
        )}
      </CardHeader>
      <CardContent>
        {sorted.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">Belum ada riwayat VDOT.</p>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sorted} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(d: string) => formatDateLabel(d)}
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={11}
                  tickLine={false}
                  minTickGap={24}
                />
                <YAxis
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={11}
                  tickLine={false}
                  width={32}
                  domain={['dataMin - 1', 'dataMax + 1']}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  labelFormatter={(d: string) => formatDateLabel(d, { weekday: true })}
                  formatter={(value: number) => [value.toFixed(2), 'VDOT']}
                />
                <Line
                  type="monotone"
                  dataKey="vdot"
                  name="VDOT"
                  stroke="hsl(var(--success))"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: 'hsl(var(--success))', strokeWidth: 0 }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
