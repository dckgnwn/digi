'use client';

import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatPaceFromSec } from '@/lib/utils';
import type { TelemetryPoint } from '@/lib/types';

interface CardiacDriftChartProps {
  telemetry: TelemetryPoint[];
  cardiacDriftPct: number | null;
}

function formatTimeAxis(tSec: number): string {
  const m = Math.floor(tSec / 60);
  const s = tSec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

/**
 * Downsample telemetri 1Hz agar Recharts tidak me-render ribuan titik untuk
 * lari panjang (mis. long run 2 jam = 7200 sampel). Target ~300 titik cukup
 * untuk menampilkan tren drift tanpa mengorbankan performa render.
 */
function downsample(points: TelemetryPoint[], targetCount = 300): TelemetryPoint[] {
  if (points.length <= targetCount) return points;
  const step = Math.ceil(points.length / targetCount);
  return points.filter((_, i) => i % step === 0);
}

export function CardiacDriftChart({ telemetry, cardiacDriftPct }: CardiacDriftChartProps) {
  const chartData = downsample(telemetry).map((p) => ({
    t: p.t,
    heartRate: p.heart_rate,
    paceSecKm: p.pace_sec_km,
  }));

  const driftIsConcerning = cardiacDriftPct != null && cardiacDriftPct > 5;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle>Cardiac Drift</CardTitle>
        {cardiacDriftPct != null && (
          <Badge variant={driftIsConcerning ? 'destructive' : 'success'}>
            {cardiacDriftPct > 0 ? '+' : ''}
            {cardiacDriftPct.toFixed(1)}%
          </Badge>
        )}
      </CardHeader>
      <CardContent>
        {chartData.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">
            Belum ada data telemetri 1Hz untuk aktivitas ini.
          </p>
        ) : (
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="t"
                  tickFormatter={formatTimeAxis}
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={11}
                  tickLine={false}
                />
                <YAxis
                  yAxisId="hr"
                  stroke="hsl(var(--danger))"
                  fontSize={11}
                  tickLine={false}
                  width={36}
                  domain={['dataMin - 5', 'dataMax + 5']}
                />
                <YAxis
                  yAxisId="pace"
                  orientation="right"
                  stroke="hsl(var(--secondary))"
                  fontSize={11}
                  tickLine={false}
                  width={44}
                  reversed
                  tickFormatter={(v: number) => formatPaceFromSec(v)}
                  domain={['dataMin - 15', 'dataMax + 15']}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  labelFormatter={(t: number) => `Waktu ${formatTimeAxis(t)}`}
                  formatter={(value: number, name: string) => {
                    if (name === 'Heart Rate') return [`${value} bpm`, name];
                    return [`${formatPaceFromSec(value)}/km`, name];
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line
                  yAxisId="hr"
                  type="monotone"
                  dataKey="heartRate"
                  name="Heart Rate"
                  stroke="hsl(var(--danger))"
                  dot={false}
                  strokeWidth={2}
                  connectNulls
                />
                <Line
                  yAxisId="pace"
                  type="monotone"
                  dataKey="paceSecKm"
                  name="Pace"
                  stroke="hsl(var(--secondary))"
                  dot={false}
                  strokeWidth={2}
                  connectNulls
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
