'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Save } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ApiError, saveBaseline } from '@/lib/api';
import type { AthleteBaseline } from '@/lib/types';

interface BaselineFormProps {
  initialBaseline: AthleteBaseline | null;
}

function toInputValue(v: number | null): string {
  return v == null ? '' : String(v);
}

export function BaselineForm({ initialBaseline }: BaselineFormProps) {
  const router = useRouter();
  const [maxHr, setMaxHr] = useState(toInputValue(initialBaseline?.maxHr ?? null));
  const [lthr, setLthr] = useState(toInputValue(initialBaseline?.lthr ?? null));
  const [restingHr, setRestingHr] = useState(toInputValue(initialBaseline?.restingHr ?? null));
  const [targetRaceName, setTargetRaceName] = useState(initialBaseline?.targetRaceName ?? '');
  const [targetRaceDistanceKm, setTargetRaceDistanceKm] = useState(
    toInputValue(initialBaseline?.targetRaceDistanceKm ?? null)
  );
  const [targetRaceDate, setTargetRaceDate] = useState(initialBaseline?.targetRaceDate ?? '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSaved(false);
    try {
      await saveBaseline({
        maxHr: Number(maxHr),
        lthr: Number(lthr),
        restingHr: Number(restingHr),
        vdot: initialBaseline?.vdot ?? null,
        targetRaceName: targetRaceName || null,
        targetRaceDistanceKm: targetRaceDistanceKm ? Number(targetRaceDistanceKm) : null,
        targetRaceDate: targetRaceDate || null,
        targetRaceTimeSeconds: initialBaseline?.targetRaceTimeSeconds ?? null,
      });
      setSaved(true);
      router.refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Gagal menyimpan baseline.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="space-y-1.5">
          <label htmlFor="maxHr" className="text-sm font-medium">
            HR Maks (bpm)
          </label>
          <Input id="maxHr" type="number" min={100} max={230} value={maxHr} onChange={(e) => setMaxHr(e.target.value)} required />
        </div>
        <div className="space-y-1.5">
          <label htmlFor="lthr" className="text-sm font-medium">
            LTHR (bpm)
          </label>
          <Input id="lthr" type="number" min={80} max={220} value={lthr} onChange={(e) => setLthr(e.target.value)} required />
        </div>
        <div className="space-y-1.5">
          <label htmlFor="restingHr" className="text-sm font-medium">
            HR Istirahat (bpm)
          </label>
          <Input
            id="restingHr"
            type="number"
            min={30}
            max={100}
            value={restingHr}
            onChange={(e) => setRestingHr(e.target.value)}
            required
          />
        </div>
      </div>

      <div className="space-y-4 border-t border-border pt-4">
        <p className="text-sm font-medium">Target Race (opsional)</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="space-y-1.5">
            <label htmlFor="targetRaceName" className="text-sm font-medium text-muted-foreground">
              Nama Race
            </label>
            <Input id="targetRaceName" value={targetRaceName} onChange={(e) => setTargetRaceName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="targetRaceDistanceKm" className="text-sm font-medium text-muted-foreground">
              Jarak (km)
            </label>
            <Input
              id="targetRaceDistanceKm"
              type="number"
              min={0}
              step="0.01"
              value={targetRaceDistanceKm}
              onChange={(e) => setTargetRaceDistanceKm(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="targetRaceDate" className="text-sm font-medium text-muted-foreground">
              Tanggal
            </label>
            <Input id="targetRaceDate" type="date" value={targetRaceDate} onChange={(e) => setTargetRaceDate(e.target.value)} />
          </div>
        </div>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}
      {saved && !error && <p className="text-sm text-success">Baseline tersimpan.</p>}

      <div className="flex items-center justify-between border-t border-border pt-4">
        <Button type="button" variant="outline" onClick={() => router.push('/')}>
          Lewati untuk Sekarang
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {loading ? 'Menyimpan...' : 'Simpan & Lanjutkan'}
        </Button>
      </div>
    </form>
  );
}
