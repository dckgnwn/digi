import type { ReactNode } from 'react';
import { Flame, MapPin, Timer } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { GymExerciseTable } from '@/components/workout/GymExerciseTable';
import { formatDurationMinutes } from '@/lib/utils';
import type { DailyPrescription } from '@/lib/types';

const SESSION_TYPE_LABEL: Record<string, string> = {
  EASY: 'Easy Run',
  INTERVAL: 'Interval',
  TEMPO: 'Tempo',
  LONG_RUN: 'Long Run',
  GYM: 'Gym',
  REST: 'Rest',
  RACE: 'Race Day',
  STRICT_ZONE1_WALK: 'Jalan Zona 1 (Revisi)',
};

interface NextWorkoutCardProps {
  prescription: DailyPrescription | null;
}

export function NextWorkoutCard({ prescription }: NextWorkoutCardProps) {
  if (!prescription || prescription.session_type === 'REST') {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sesi Hari Ini</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border py-12 text-center">
            <Timer className="h-6 w-6 text-muted-foreground" />
            <p className="text-sm font-medium">Hari Istirahat</p>
            <p className="max-w-xs text-xs text-muted-foreground">
              Tidak ada beban latihan hari ini. Pemulihan adalah bagian dari program, bukan jeda darinya.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const { main_run, warmup, running_drills, gym_strength, cooldown, nutrition, coach_notes, weather_adjusted } =
    prescription;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle>{SESSION_TYPE_LABEL[prescription.session_type] ?? prescription.session_type}</CardTitle>
        <div className="flex items-center gap-2">
          {weather_adjusted && (
            <Badge variant="warning" className="gap-1">
              <Flame className="h-3 w-3" />
              Disesuaikan Cuaca
            </Badge>
          )}
          <Badge variant="outline">{formatDurationMinutes(main_run.target_duration_minutes)}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="main-run">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="drills">Drills</TabsTrigger>
            <TabsTrigger value="main-run">Main Run</TabsTrigger>
            <TabsTrigger value="gym">Gym Strength</TabsTrigger>
          </TabsList>

          {/* ------------------------------------------------------------- */}
          <TabsContent value="drills" className="space-y-4">
            <div>
              <h4 className="mb-1 text-sm font-medium">Warmup ({formatDurationMinutes(warmup.duration_minutes)})</h4>
              <p className="text-sm text-muted-foreground">{warmup.description}</p>
              {warmup.drills.length > 0 && (
                <ul className="mt-2 flex flex-wrap gap-1.5">
                  {warmup.drills.map((d, i) => (
                    <Badge key={i} variant="outline">
                      {d}
                    </Badge>
                  ))}
                </ul>
              )}
            </div>

            {running_drills.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Drill</TableHead>
                    <TableHead className="text-center">Set</TableHead>
                    <TableHead className="text-center">Jarak</TableHead>
                    <TableHead>Catatan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {running_drills.map((drill, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{drill.name}</TableCell>
                      <TableCell className="tabular-stat text-center">{drill.sets}</TableCell>
                      <TableCell className="tabular-stat text-center">{drill.distance_m}m</TableCell>
                      <TableCell className="text-muted-foreground">{drill.notes}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-sm text-muted-foreground">Tidak ada drill teknik untuk sesi ini.</p>
            )}
          </TabsContent>

          {/* ------------------------------------------------------------- */}
          <TabsContent value="main-run" className="space-y-4">
            <p className="text-sm leading-relaxed text-foreground">{main_run.description}</p>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <StatBlock icon={<MapPin className="h-3.5 w-3.5" />} label="Jarak" value={`${main_run.target_distance_km} km`} />
              <StatBlock icon={<Timer className="h-3.5 w-3.5" />} label="Durasi" value={formatDurationMinutes(main_run.target_duration_minutes)} />
              <StatBlock
                label="Pace Target"
                value={`${main_run.target_pace_min_sec_km}-${main_run.target_pace_max_sec_km}/km`}
              />
              <StatBlock label="HR Target" value={`${main_run.target_hr_min}-${main_run.target_hr_max} bpm`} />
            </div>

            {main_run.structure.length > 0 && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Segmen</TableHead>
                    <TableHead className="text-center">Jarak</TableHead>
                    <TableHead className="text-center">Pace</TableHead>
                    <TableHead className="text-center">HR</TableHead>
                    <TableHead className="text-center">Recovery</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {main_run.structure.map((seg, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{seg.segment}</TableCell>
                      <TableCell className="tabular-stat text-center">{seg.distance_km} km</TableCell>
                      <TableCell className="tabular-stat text-center">{seg.target_pace}/km</TableCell>
                      <TableCell className="tabular-stat text-center">{seg.target_hr}</TableCell>
                      <TableCell className="tabular-stat text-center">{seg.recovery_minutes}m</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}

            <div className="rounded-md border border-border bg-muted/30 p-4">
              <h4 className="mb-1 text-sm font-medium">Cooldown ({formatDurationMinutes(cooldown.duration_minutes)})</h4>
              <p className="text-sm text-muted-foreground">{cooldown.description}</p>
            </div>

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              <NutritionBlock label="Sebelum" value={nutrition.pre_workout} />
              <NutritionBlock label="Selama" value={nutrition.during_workout} />
              <NutritionBlock label="Sesudah" value={nutrition.post_workout} />
            </div>
            <p className="text-xs text-muted-foreground">{nutrition.hydration_notes}</p>

            {coach_notes && (
              <div className="rounded-md border border-secondary/30 bg-secondary/10 p-3 text-sm text-foreground">
                {coach_notes}
              </div>
            )}
          </TabsContent>

          {/* ------------------------------------------------------------- */}
          <TabsContent value="gym">
            <GymExerciseTable
              exercises={gym_strength.exercises}
              required={gym_strength.required}
              sequenceAfterRun={gym_strength.sequence_after_run}
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function StatBlock({ icon, label, value }: { icon?: ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-md border border-border p-3">
      <div className="flex items-center gap-1 text-xs text-muted-foreground">
        {icon}
        {label}
      </div>
      <p className="tabular-stat mt-1 text-sm font-semibold">{value}</p>
    </div>
  );
}

function NutritionBlock({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm">{value}</p>
    </div>
  );
}
