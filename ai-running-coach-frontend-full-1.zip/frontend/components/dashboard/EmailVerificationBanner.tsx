'use client';

import { useState } from 'react';
import { Loader2, Mail, X } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { ApiError, resendVerificationEmail } from '@/lib/api';

export function EmailVerificationBanner() {
  const [dismissed, setDismissed] = useState(false);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  if (dismissed) return null;

  async function handleResend() {
    setSending(true);
    setMessage(null);
    try {
      const result = await resendVerificationEmail();
      setMessage(result.message);
    } catch (err) {
      setMessage(err instanceof ApiError ? err.message : 'Gagal mengirim ulang email verifikasi.');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="border-b border-warning/30 bg-warning/10">
      <div className="container flex flex-col gap-2 py-2.5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 text-sm text-foreground">
          <Mail className="h-4 w-4 shrink-0 text-warning" />
          <span>{message || 'Email Anda belum diverifikasi.'}</span>
        </div>
        <div className="flex items-center gap-2">
          {!message && (
            <Button onClick={handleResend} disabled={sending} variant="outline" size="sm">
              {sending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {sending ? 'Mengirim...' : 'Kirim Ulang'}
            </Button>
          )}
          <button
            onClick={() => setDismissed(true)}
            className="rounded-sm p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
            aria-label="Tutup"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
