'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { LogOut, RefreshCw, Zap } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ReadinessGauge } from '@/components/dashboard/ReadinessGauge';
import { triggerStravaSync, logoutUser } from '@/lib/api';
import { clearAuthTokens } from '@/lib/auth-client';
import { cn } from '@/lib/utils';
import type { DashboardOverview, ReadinessStatus } from '@/lib/types';

const STATUS_LABEL: Record<ReadinessStatus, string> = {
  FRESH: 'Fresh',
  OPTIMAL: 'Optimal',
  OVERREACHING: 'Overreaching',
};

const STATUS_BADGE_VARIANT: Record<ReadinessStatus, 'success' | 'secondary' | 'destructive'> = {
  FRESH: 'success',
  OPTIMAL: 'secondary',
  OVERREACHING: 'destructive',
};

interface ReadinessTopbarProps {
  initialData: DashboardOverview;
}

export function ReadinessTopbar({ initialData }: ReadinessTopbarProps) {
  const router = useRouter();
  const [data, setData] = useState(initialData);
  const [syncing, setSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  async function handleSync() {
    setSyncing(true);
    setSyncMessage(null);
    try {
      const result = await triggerStravaSync();
      setSyncMessage(
        result.newActivities > 0
          ? `${result.newActivities} aktivitas baru diproses.`
          : 'Tidak ada aktivitas baru.'
      );
      router.refresh();
    } catch (err) {
      setSyncMessage(err instanceof Error ? err.message : 'Sync gagal.');
    } finally {
      setSyncing(false);
    }
  }

  async function handleLogout() {
    try {
      await logoutUser();
    } catch {
      // Tetap lanjut hapus token lokal meski revoke server gagal (mis. offline) —
      // yang penting sesi di browser ini berakhir.
    }
    clearAuthTokens();
    router.push('/login');
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="container flex flex-col gap-4 py-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <ReadinessGauge scorePct={data.readinessScorePct} status={data.readinessStatus} size={72} />
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center gap-2">
              <Badge variant={STATUS_BADGE_VARIANT[data.readinessStatus]}>{STATUS_LABEL[data.readinessStatus]}</Badge>
              <span className="tabular-stat text-xs text-muted-foreground">TSB {data.tsb > 0 ? '+' : ''}{data.tsb}</span>
            </div>
            <div className="tabular-stat flex gap-3 text-xs text-muted-foreground">
              <span>CTL {data.ctl.toFixed(1)}</span>
              <span>ATL {data.atl.toFixed(1)}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-start gap-1.5 sm:items-end">
          <div className="flex items-center gap-2">
            <Button onClick={handleSync} disabled={syncing} variant="outline" size="sm">
              <RefreshCw className={cn('h-4 w-4', syncing && 'animate-spin')} />
              {syncing ? 'Menyinkronkan...' : 'Sync Strava'}
            </Button>
            <Button onClick={handleLogout} variant="ghost" size="icon" aria-label="Keluar">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
          {syncMessage && <span className="text-xs text-muted-foreground">{syncMessage}</span>}
          {!syncMessage && data.lastStravaSyncAt && (
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Zap className="h-3 w-3 text-primary" />
              Terakhir sync {new Date(data.lastStravaSyncAt).toLocaleString('id-ID')}
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
