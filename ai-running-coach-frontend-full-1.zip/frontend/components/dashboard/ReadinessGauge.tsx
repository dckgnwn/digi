import { cn } from '@/lib/utils';
import type { ReadinessStatus } from '@/lib/types';

const STATUS_COLOR_VAR: Record<ReadinessStatus, string> = {
  FRESH: 'hsl(var(--success))',
  OPTIMAL: 'hsl(var(--secondary))',
  OVERREACHING: 'hsl(var(--danger))',
};

interface ReadinessGaugeProps {
  scorePct: number; // 0-100
  status: ReadinessStatus;
  size?: number;
  className?: string;
}

/**
 * Gauge radial menampilkan Readiness Score — dirancang mengingatkan pada
 * cincin kesiapan di jam lari (Garmin/COROS), elemen visual paling
 * "berbicara" di dashboard ini, sengaja dibuat menonjol sementara elemen
 * lain di sekitarnya tetap tenang.
 */
export function ReadinessGauge({ scorePct, status, size = 128, className }: ReadinessGaugeProps) {
  const clamped = Math.max(0, Math.min(100, scorePct));
  const strokeWidth = size * 0.09;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - clamped / 100);
  const color = STATUS_COLOR_VAR[status];

  return (
    <div className={cn('relative inline-flex items-center justify-center', className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="hsl(var(--muted))"
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.6s ease-out' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="tabular-stat text-2xl font-semibold leading-none">{Math.round(clamped)}</span>
        <span className="mt-1 text-[10px] text-muted-foreground">Readiness</span>
      </div>
    </div>
  );
}
