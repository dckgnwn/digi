'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { AlertTriangle, MessageSquareWarning, Sparkles } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { requestScheduleAdjustment } from '@/lib/api';
import type { CoachBriefing } from '@/lib/types';

const VERDICT_LABEL: Record<CoachBriefing['verdict'], string> = {
  COMPLIANT: 'Sesuai Rencana',
  EGO_RUNNING_JUNK_MILES: 'Ego Running — Junk Miles',
  UNDERPERFORMED: 'Di Bawah Target',
  HIGH_HR_LOW_PACE_INVESTIGATE: 'HR Tinggi, Pace Rendah',
  OTHER: 'Lainnya',
};

const VERDICT_BADGE_VARIANT: Record<CoachBriefing['verdict'], 'success' | 'destructive' | 'warning' | 'secondary'> = {
  COMPLIANT: 'success',
  EGO_RUNNING_JUNK_MILES: 'destructive',
  UNDERPERFORMED: 'warning',
  HIGH_HR_LOW_PACE_INVESTIGATE: 'warning',
  OTHER: 'secondary',
};

interface CoachBriefingCardProps {
  briefing: CoachBriefing | null;
}

export function CoachBriefingCard({ briefing }: CoachBriefingCardProps) {
  const router = useRouter();
  const [requesting, setRequesting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  async function handleRequestAdjustment() {
    setRequesting(true);
    setFeedback(null);
    try {
      const result = await requestScheduleAdjustment();
      setFeedback(result.message);
      router.refresh();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Gagal meminta penyesuaian.');
    } finally {
      setRequesting(false);
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-secondary" />
          <CardTitle>Evaluasi Coach</CardTitle>
        </div>
        {briefing && <Badge variant={VERDICT_BADGE_VARIANT[briefing.verdict]}>{VERDICT_LABEL[briefing.verdict]}</Badge>}
      </CardHeader>
      <CardContent className="space-y-4">
        {!briefing ? (
          <p className="text-sm text-muted-foreground">
            Belum ada aktivitas yang diaudit hari ini. Selesaikan sesi lari Anda, lalu Coach akan mengevaluasi di sini.
          </p>
        ) : (
          <>
            <p className="text-sm leading-relaxed text-foreground">{briefing.auditSummary}</p>

            {briefing.reprimandMessage && (
              <div className="flex gap-3 rounded-md border border-danger/30 bg-danger/10 p-4">
                <MessageSquareWarning className="mt-0.5 h-4 w-4 shrink-0 text-danger" />
                <p className="text-sm leading-relaxed text-foreground">{briefing.reprimandMessage}</p>
              </div>
            )}

            <div className="flex items-center justify-between border-t border-border pt-4">
              <span className="text-xs text-muted-foreground">
                Dievaluasi {new Date(briefing.generatedAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
              </span>
              <Button onClick={handleRequestAdjustment} disabled={requesting} variant="secondary" size="sm">
                <AlertTriangle className="h-4 w-4" />
                {requesting ? 'Memproses...' : 'Minta Penyesuaian'}
              </Button>
            </div>

            {feedback && <p className="text-xs text-muted-foreground">{feedback}</p>}
          </>
        )}
      </CardContent>
    </Card>
  );
}
