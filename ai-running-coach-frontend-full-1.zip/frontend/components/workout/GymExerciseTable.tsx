import { Dumbbell } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import type { GymExercise } from '@/lib/types';

interface GymExerciseTableProps {
  exercises: GymExercise[];
  required: boolean;
  sequenceAfterRun: boolean;
}

function rpeBadgeVariant(rpe: number): 'success' | 'warning' | 'destructive' {
  if (rpe <= 6) return 'success';
  if (rpe <= 8) return 'warning';
  return 'destructive';
}

export function GymExerciseTable({ exercises, required, sequenceAfterRun }: GymExerciseTableProps) {
  if (!required || exercises.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border py-10 text-center">
        <Dumbbell className="h-6 w-6 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">Tidak ada sesi gym untuk hari ini.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {sequenceAfterRun && (
        <Badge variant="gym" className="gap-1.5">
          <Dumbbell className="h-3 w-3" />
          Dilakukan PASCA lari — bukan sesi terpisah
        </Badge>
      )}
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Gerakan</TableHead>
            <TableHead className="text-center">Set</TableHead>
            <TableHead className="text-center">Reps</TableHead>
            <TableHead>Panduan Beban</TableHead>
            <TableHead className="text-center">RPE</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {exercises.map((ex, idx) => (
            <TableRow key={`${ex.name}-${idx}`}>
              <TableCell className="font-medium">{ex.name}</TableCell>
              <TableCell className="tabular-stat text-center">{ex.sets}</TableCell>
              <TableCell className="tabular-stat text-center">{ex.reps}</TableCell>
              <TableCell className="text-muted-foreground">{ex.load_guidance}</TableCell>
              <TableCell className="text-center">
                <Badge variant={rpeBadgeVariant(ex.rpe)}>{ex.rpe.toFixed(1)}</Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
