# AI Running Coach Elit — Dashboard (Fase 4 + Fase 5: Auth)

Frontend Next.js App Router untuk dashboard AI Running Coach Elit, dengan
autentikasi JWT penuh terhubung ke backend Express (Fase 1-5).

## Setup

```bash
npm install
cp .env.local.example .env.local
# Edit .env.local: arahkan NEXT_PUBLIC_API_BASE_URL ke backend Express
npm run dev
```

Alur pertama kali: `/register` → `/onboarding` (isi HR max/LTHR/HR istirahat,
wajib sebelum backend bisa memproses aktivitas apa pun) → `/` (dashboard).

## Struktur

```
middleware.ts                    Proteksi route berbasis cookie token
app/
  layout.tsx                     Root layout (font, tema dark)
  login/page.tsx                 Login
  register/page.tsx              Register
  onboarding/page.tsx            Form baseline fisiologis (server wrapper)
  (dashboard)/
    layout.tsx                   Topbar persisten + nav + Floating Coach Drawer
    page.tsx                     Main Overview
    calendar/page.tsx            Interactive Calendar + Availability Matrix
components/
  ui/                            Primitif shadcn/ui (ditulis tangan)
  dashboard/                     ReadinessGauge, ReadinessTopbar, CoachBriefingCard,
                                  NextWorkoutCard
  workout/GymExerciseTable.tsx
  calendar/                      CalendarView (toggle mingguan/bulanan),
                                  AvailabilityMatrixEditor
  analytics/                     CardiacDriftChart, VdotTrendChart (Recharts)
  chat/FloatingCoachDrawer.tsx
  onboarding/BaselineForm.tsx
lib/
  types.ts                       Kontrak tipe — dicerminkan dari schema backend
  api.ts                         Klien fetch tipeup (token derived, bukan parameter userId)
  auth-client.ts                 Token localStorage + cookie (dipakai Client Component)
  auth-server.ts                 Baca cookie via next/headers (Server Component saja)
  utils.ts                       Helper (cn, format pace/durasi/tanggal)
```

## Autentikasi (Fase 5)

- Token JWT didapat dari `POST /v1/auth/register` atau `/v1/auth/login`,
  disimpan di **localStorage** (dipakai Client Component memanggil API
  langsung dari browser) DAN di **cookie biasa** `apex_auth_token` (dibaca
  Server Component lewat `next/headers` saat SSR).
- `middleware.ts` melakukan pengecekan MURAH (keberadaan cookie) di Edge
  untuk mencegah flash konten sebelum redirect — verifikasi signature JWT
  yang sesungguhnya selalu dilakukan backend Express di setiap request.
- Semua fungsi di `lib/api.ts` TIDAK LAGI menerima `userId` — identitas
  selalu diturunkan backend dari token yang diverifikasi (`req.user.id`),
  bukan dari input client manapun.

## Kontrak API (diimplementasikan penuh di backend Fase 5)

Lihat `src/routes/apiRoutes.js` pada proyek backend untuk daftar endpoint
lengkap: `/v1/auth/*`, `/v1/athlete/baseline`, `/v1/dashboard/*`,
`/v1/calendar/*`, `/v1/availability`, `/v1/activities/:id/telemetry`,
`/v1/athletes/vdot-history`, `/v1/coach/*`.

## Catatan Desain

- Tema selalu dark (Dark Slate `#09090B`), token warna didefinisikan sebagai
  CSS variable HSL di `app/globals.css` dan dipetakan di `tailwind.config.ts`.
- Komponen kalender menggabungkan mode "mingguan" dan "bulanan" dalam SATU
  komponen (`CalendarView`) dengan toggle, bukan dua file terpisah.
