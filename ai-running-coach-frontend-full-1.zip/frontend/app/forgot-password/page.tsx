'use client';

import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { ArrowLeft, Loader2, Mail } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { forgotPassword } from '@/lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    try {
      const result = await forgotPassword(email);
      setMessage(result.message);
    } catch {
      // Backend selalu merespons pesan generik yang sama untuk endpoint ini
      // (mencegah email enumeration) — jalur error praktis tidak akan terpicu,
      // tapi tetap ditangani untuk kasus jaringan gagal total.
      setMessage('Jika email terdaftar, tautan reset password telah dikirim.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="items-center text-center">
          <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <Mail className="h-5 w-5" />
          </div>
          <CardTitle>Lupa Password</CardTitle>
          <CardDescription>Masukkan email Anda, kami kirimkan tautan reset password.</CardDescription>
        </CardHeader>
        <CardContent>
          {message ? (
            <p className="rounded-md border border-border bg-muted/30 p-3 text-center text-sm text-foreground">
              {message}
            </p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  autoComplete="email"
                  placeholder="nama@email.com"
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {loading ? 'Mengirim...' : 'Kirim Tautan Reset'}
              </Button>
            </form>
          )}

          <Link href="/login" className="mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" />
            Kembali ke halaman masuk
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
