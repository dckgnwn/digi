import { redirect } from 'next/navigation';

import { CoachBriefingCard } from '@/components/dashboard/CoachBriefingCard';
import { NextWorkoutCard } from '@/components/dashboard/NextWorkoutCard';
import { CardiacDriftChart } from '@/components/analytics/CardiacDriftChart';
import { VdotTrendChart } from '@/components/analytics/VdotTrendChart';
import {
  ApiError,
  getActivityTelemetry,
  getCoachBriefing,
  getDashboardOverview,
  getTodayPrescription,
  getVdotHistory,
} from '@/lib/api';
import { getServerAccessToken } from '@/lib/auth-server';

export default async function OverviewPage() {
  const token = getServerAccessToken();
  if (!token) redirect('/login');

  try {
    // Next.js men-dedup pemanggilan fetch() dengan URL+opsi identik dalam satu
    // request render yang sama, jadi overview di sini TIDAK memicu network
    // request kedua — panggilan ini "gratis" karena sudah dipanggil di layout.
    const [overview, briefing, prescription, vdotHistory] = await Promise.all([
      getDashboardOverview(token),
      getCoachBriefing(token),
      getTodayPrescription(token),
      getVdotHistory(token),
    ]);

    const telemetry = overview.lastExecutedActivityId
      ? await getActivityTelemetry(overview.lastExecutedActivityId, token)
      : [];

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <CoachBriefingCard briefing={briefing} />
          <NextWorkoutCard prescription={prescription} />
        </div>

        <div>
          <h2 className="mb-3 text-sm font-medium text-muted-foreground">Analitik Terkini</h2>
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <CardiacDriftChart telemetry={telemetry} cardiacDriftPct={overview.lastActivityCardiacDriftPct} />
            <VdotTrendChart history={vdotHistory} />
          </div>
        </div>
      </div>
    );
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) redirect('/login');
    throw err;
  }
}
