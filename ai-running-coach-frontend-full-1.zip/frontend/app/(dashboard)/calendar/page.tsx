import { endOfMonth, endOfWeek, startOfMonth, startOfWeek } from 'date-fns';
import { redirect } from 'next/navigation';

import { CalendarView } from '@/components/calendar/CalendarView';
import { AvailabilityMatrixEditor } from '@/components/calendar/AvailabilityMatrixEditor';
import { ApiError, getAvailability, getCalendarEvents } from '@/lib/api';
import { getServerAccessToken } from '@/lib/auth-server';
import { toISODateOnly } from '@/lib/utils';

export default async function CalendarPage() {
  const token = getServerAccessToken();
  if (!token) redirect('/login');

  const now = new Date();
  const rangeStart = toISODateOnly(startOfWeek(startOfMonth(now)));
  const rangeEnd = toISODateOnly(endOfWeek(endOfMonth(now)));

  try {
    const [events, availability] = await Promise.all([
      getCalendarEvents(rangeStart, rangeEnd, token),
      getAvailability(token),
    ]);

    return (
      <div className="space-y-6">
        <CalendarView initialEvents={events} initialAnchorDate={toISODateOnly(now)} />
        <AvailabilityMatrixEditor initialAvailability={availability} />
      </div>
    );
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) redirect('/login');
    throw err;
  }
}
