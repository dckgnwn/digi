import type { ReactNode } from 'react';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { CalendarDays, LayoutDashboard, UserCog } from 'lucide-react';

import { ReadinessTopbar } from '@/components/dashboard/ReadinessTopbar';
import { EmailVerificationBanner } from '@/components/dashboard/EmailVerificationBanner';
import { FloatingCoachDrawer } from '@/components/chat/FloatingCoachDrawer';
import { ApiError, getDashboardOverview, getMe } from '@/lib/api';
import { getServerAccessToken } from '@/lib/auth-server';

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const token = getServerAccessToken();
  if (!token) redirect('/login');

  let overview;
  let me;
  try {
    [overview, me] = await Promise.all([getDashboardOverview(token), getMe(token)]);
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) redirect('/login');
    throw err;
  }

  return (
    <div className="min-h-screen bg-background">
      <ReadinessTopbar initialData={overview} />
      {!me.email_verified && <EmailVerificationBanner />}

      <nav className="container flex gap-1 border-b border-border py-2">
        <Link
          href="/"
          className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <LayoutDashboard className="h-4 w-4" />
          Overview
        </Link>
        <Link
          href="/calendar"
          className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <CalendarDays className="h-4 w-4" />
          Kalender
        </Link>
        <Link
          href="/onboarding"
          className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <UserCog className="h-4 w-4" />
          Profil
        </Link>
      </nav>

      <main className="container py-6">{children}</main>

      <FloatingCoachDrawer />
    </div>
  );
}
