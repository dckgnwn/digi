'use client';

import { Suspense, useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { CheckCircle2, Loader2, XCircle } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ApiError, verifyEmail } from '@/lib/api';

type Status = 'loading' | 'success' | 'error';

function VerifyEmailContent() {
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  const [status, setStatus] = useState<Status>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!token) {
      setStatus('error');
      setMessage('Tautan verifikasi tidak valid — token tidak ditemukan.');
      return;
    }
    verifyEmail(token)
      .then((result) => {
        setStatus('success');
        setMessage(result.message);
      })
      .catch((err) => {
        setStatus('error');
        setMessage(err instanceof ApiError ? err.message : 'Gagal memverifikasi email.');
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  return (
    <Card className="w-full max-w-sm">
      <CardHeader className="items-center text-center">
        {status === 'loading' && <Loader2 className="h-10 w-10 animate-spin text-muted-foreground" />}
        {status === 'success' && <CheckCircle2 className="h-10 w-10 text-success" />}
        {status === 'error' && <XCircle className="h-10 w-10 text-danger" />}
        <CardTitle className="mt-2">
          {status === 'loading' && 'Memverifikasi...'}
          {status === 'success' && 'Email Terverifikasi'}
          {status === 'error' && 'Verifikasi Gagal'}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 text-center">
        <p className="text-sm text-muted-foreground">{message}</p>
        {status !== 'loading' && (
          <Link href="/">
            <Button className="w-full">Ke Dashboard</Button>
          </Link>
        )}
      </CardContent>
    </Card>
  );
}

export default function VerifyEmailPage() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <Suspense fallback={<Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />}>
        <VerifyEmailContent />
      </Suspense>
    </div>
  );
}
