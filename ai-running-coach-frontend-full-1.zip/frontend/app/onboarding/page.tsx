import { redirect } from 'next/navigation';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BaselineForm } from '@/components/onboarding/BaselineForm';
import { ApiError, getBaseline } from '@/lib/api';
import { getServerAccessToken } from '@/lib/auth-server';

export default async function OnboardingPage() {
  const token = getServerAccessToken();
  if (!token) redirect('/login');

  let baseline;
  try {
    baseline = await getBaseline(token);
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) redirect('/login');
    throw err;
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <Card className="w-full max-w-xl">
        <CardHeader>
          <CardTitle>Lengkapi Profil Fisiologis</CardTitle>
          <CardDescription>
            Data ini adalah dasar seluruh perhitungan TSS, VDOT, dan zona pace Anda — tanpa ini, Coach tidak
            bisa mengevaluasi latihan Anda secara akurat.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <BaselineForm initialBaseline={baseline} />
        </CardContent>
      </Card>
    </div>
  );
}
