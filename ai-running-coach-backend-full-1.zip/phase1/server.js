'use strict';

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const apiRoutes = require('./src/routes/apiRoutes');
const { apiLimiter } = require('./src/middleware/rateLimiter');

const app = express();

const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:3000';
app.use(cors({ origin: CORS_ORIGIN, credentials: true }));

// Strava webhook mengirim JSON; body-parser standar sudah cukup.
app.use(express.json({ limit: '10mb' }));

// Rate limit umum untuk semua endpoint API — endpoint auth punya limiter
// tambahan yang lebih ketat, didaftarkan di apiRoutes.js.
app.use('/api', apiLimiter);

app.use('/api', apiRoutes);

app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// Error handler terpusat
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`AI Running Coach Elit API berjalan di port ${PORT}`);
});
