'use strict';

/**
 * src/config/init-db.js
 * -----------------------------------------------------------------------
 * Script inisialisasi skema database Neon PostgreSQL untuk AI Running
 * Coach Elit — Fase 1 (Database & Core Sports Science Engine).
 *
 * Cara pakai:
 *   DATABASE_URL="postgresql://user:pass@ep-xxxx.neon.tech/dbname?sslmode=require" \
 *   node src/config/init-db.js
 *
 * Script ini IDEMPOTEN — aman dijalankan berkali-kali. Semua CREATE TABLE
 * memakai IF NOT EXISTS, dan semua CREATE TYPE dibungkus DO block agar
 * tidak error saat enum sudah ada.
 * -----------------------------------------------------------------------
 */

require('dotenv').config();
const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  console.error('FATAL: environment variable DATABASE_URL belum diset.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // wajib untuk koneksi Neon
});

// ---------------------------------------------------------------------------
// DAFTAR STATEMENT SQL — dieksekusi berurutan dalam satu transaksi
// ---------------------------------------------------------------------------

const STATEMENTS = [
  // -------------------------------------------------------------------
  // EXTENSIONS
  // -------------------------------------------------------------------
  `CREATE EXTENSION IF NOT EXISTS pgcrypto;`,

  // -------------------------------------------------------------------
  // ENUM TYPES (idempotent via DO block, karena Postgres tidak
  // mendukung "CREATE TYPE IF NOT EXISTS")
  // -------------------------------------------------------------------
  `DO $$ BEGIN
     CREATE TYPE activity_preference_enum AS ENUM (
       'REST', 'EASY', 'INTERVAL', 'TEMPO', 'LONG_RUN', 'GYM'
     );
   EXCEPTION WHEN duplicate_object THEN NULL;
   END $$;`,

  `DO $$ BEGIN
     CREATE TYPE equipment_type_enum AS ENUM (
       'FULL_GYM', 'HOME_DUMBBELL', 'BODYWEIGHT'
     );
   EXCEPTION WHEN duplicate_object THEN NULL;
   END $$;`,

  // -------------------------------------------------------------------
  // 1. users
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS users (
     id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     email          TEXT NOT NULL UNIQUE,
     password_hash  TEXT NOT NULL,
     full_name      TEXT NOT NULL,
     weight_kg      NUMERIC(5,2),
     height_cm      NUMERIC(5,2),
     created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
   );`,

  // -------------------------------------------------------------------
  // 2. athlete_baselines  (1 baris "current baseline" per user)
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS athlete_baselines (
     id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id                   UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
     max_hr                    SMALLINT NOT NULL,
     lthr                      SMALLINT NOT NULL,
     resting_hr                SMALLINT NOT NULL,
     vdot                      NUMERIC(5,2),
     target_race_name          TEXT,
     target_race_distance_km   NUMERIC(6,2),
     target_race_date          DATE,
     target_race_time_seconds  INTEGER,
     updated_at                TIMESTAMPTZ NOT NULL DEFAULT now()
   );`,

  // -------------------------------------------------------------------
  // 3. user_availability  (flexible matrix hari/durasi/equipment)
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS user_availability (
     id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id               UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     day_of_week           SMALLINT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
     activity_preference   activity_preference_enum NOT NULL,
     max_duration_minutes  SMALLINT NOT NULL CHECK (max_duration_minutes > 0),
     equipment_type        equipment_type_enum,
     UNIQUE (user_id, day_of_week)
   );`,

  // -------------------------------------------------------------------
  // 4. user_integrations  (Strava + Google Calendar, 1 baris per user)
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS user_integrations (
     id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id                  UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
     strava_athlete_id        BIGINT,
     strava_access_token      TEXT,
     strava_refresh_token     TEXT,
     strava_token_expires_at  TIMESTAMPTZ,
     google_calendar_id       TEXT
   );`,

  // -------------------------------------------------------------------
  // 5. daily_readiness  (CTL/ATL/TSB harian + wellness)
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS daily_readiness (
     id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     date         DATE NOT NULL,
     ctl          NUMERIC(7,2) NOT NULL DEFAULT 0,
     atl          NUMERIC(7,2) NOT NULL DEFAULT 0,
     tsb          NUMERIC(7,2) NOT NULL DEFAULT 0,
     sleep_score  SMALLINT CHECK (sleep_score BETWEEN 0 AND 100),
     hrv_rmssd    NUMERIC(6,2),
     notes        TEXT,
     UNIQUE (user_id, date)
   );`,

  // -------------------------------------------------------------------
  // 6. scheduled_workouts  (rencana yang di-generate AI)
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS scheduled_workouts (
     id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     scheduled_date   DATE NOT NULL,
     workout_type     TEXT NOT NULL,     -- ex: 'EASY','INTERVAL','TEMPO','LONG_RUN','GYM','REST'
     title            TEXT NOT NULL,
     prescribed_json  JSONB NOT NULL DEFAULT '{}'::jsonb,
     is_completed     BOOLEAN NOT NULL DEFAULT false,
     google_event_id  TEXT,
     created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
     updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
   );`,

  // -------------------------------------------------------------------
  // 7. executed_activities  (data aktual dari Strava/device/.FIT)
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS executed_activities (
     id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id               UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     scheduled_workout_id  UUID REFERENCES scheduled_workouts(id) ON DELETE SET NULL,
     source                TEXT NOT NULL DEFAULT 'manual',  -- 'strava','garmin','coros','manual'
     external_activity_id  TEXT,
     title                 TEXT,
     distance_km           NUMERIC(6,2) NOT NULL,
     duration_minutes      NUMERIC(7,2) NOT NULL,
     avg_pace_sec          INTEGER,
     avg_hr                SMALLINT,
     max_hr                SMALLINT,
     avg_cadence           SMALLINT,
     tss_score             NUMERIC(6,2),
     cardiac_drift_pct     NUMERIC(5,2),
     telemetry_1hz         JSONB,
     created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
   );`,

  // Mencegah duplikasi import aktivitas yang sama dari sumber eksternal
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_executed_activities_source_external
     ON executed_activities (source, external_activity_id)
     WHERE external_activity_id IS NOT NULL;`,

  // -------------------------------------------------------------------
  // 8. coaching_logs  (hasil evaluasi AI per aktivitas)
  // -------------------------------------------------------------------
  `CREATE TABLE IF NOT EXISTS coaching_logs (
     id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id               UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     executed_activity_id  UUID REFERENCES executed_activities(id) ON DELETE CASCADE,
     evaluation_summary    TEXT,
     ai_response_json      JSONB,
     schedule_adjusted     BOOLEAN NOT NULL DEFAULT false,
     created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
   );`,

  // -------------------------------------------------------------------
  // INDEXES tambahan untuk query yang sering dipanggil dashboard
  // -------------------------------------------------------------------
  `CREATE INDEX IF NOT EXISTS idx_daily_readiness_user_date
     ON daily_readiness (user_id, date DESC);`,

  `CREATE INDEX IF NOT EXISTS idx_scheduled_workouts_user_date
     ON scheduled_workouts (user_id, scheduled_date);`,

  `CREATE INDEX IF NOT EXISTS idx_executed_activities_user_created
     ON executed_activities (user_id, created_at DESC);`,

  `CREATE INDEX IF NOT EXISTS idx_executed_activities_scheduled_workout
     ON executed_activities (scheduled_workout_id);`,

  `CREATE INDEX IF NOT EXISTS idx_coaching_logs_user
     ON coaching_logs (user_id, created_at DESC);`,

  `CREATE INDEX IF NOT EXISTS idx_user_availability_user
     ON user_availability (user_id);`,

  // -------------------------------------------------------------------
  // MIGRASI FASE 2: kolom OAuth Google Calendar pada user_integrations.
  // Ditambahkan di sini (bukan mengganti tabel) agar init-db.js tetap
  // idempotent dan aman dijalankan ulang di database yang sudah ada.
  // Dibutuhkan oleh src/services/adaptiveEngine.js untuk update event
  // kalender saat jadwal direvisi otomatis.
  // -------------------------------------------------------------------
  `ALTER TABLE user_integrations
     ADD COLUMN IF NOT EXISTS google_access_token TEXT;`,

  `ALTER TABLE user_integrations
     ADD COLUMN IF NOT EXISTS google_refresh_token TEXT;`,

  `ALTER TABLE user_integrations
     ADD COLUMN IF NOT EXISTS google_token_expires_at TIMESTAMPTZ;`,

  // -------------------------------------------------------------------
  // MIGRASI FASE 5: tabel vdot_history belum ada di skema Fase 1 semula.
  // Dibutuhkan untuk VdotTrendChart (Fase 4) dan estimasi VDOT otomatis
  // dari sesi aerobik steady-state (webhookController._processCompletedActivity).
  // -------------------------------------------------------------------
  `DO $$ BEGIN
     CREATE TYPE vdot_source_enum AS ENUM ('race', 'time_trial', 'estimated', 'manual');
   EXCEPTION WHEN duplicate_object THEN NULL;
   END $$;`,

  `CREATE TABLE IF NOT EXISTS vdot_history (
     id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     date               DATE NOT NULL,
     vdot               NUMERIC(5,2) NOT NULL,
     source             vdot_source_enum NOT NULL DEFAULT 'estimated',
     source_distance_m  INTEGER,
     source_time_sec    INTEGER,
     created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
     UNIQUE (user_id, date)
   );`,

  `CREATE INDEX IF NOT EXISTS idx_vdot_history_user_date ON vdot_history (user_id, date DESC);`,

  // -------------------------------------------------------------------
  // MIGRASI FASE 6: verifikasi email, reset password, refresh token rotation
  // -------------------------------------------------------------------
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified BOOLEAN NOT NULL DEFAULT false;`,
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verification_token TEXT;`,
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verification_expires_at TIMESTAMPTZ;`,
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_token TEXT;`,
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_expires_at TIMESTAMPTZ;`,

  `CREATE TABLE IF NOT EXISTS refresh_tokens (
     id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     token_hash       TEXT NOT NULL UNIQUE,
     expires_at       TIMESTAMPTZ NOT NULL,
     created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
     revoked_at       TIMESTAMPTZ,
     replaced_by_hash TEXT
   );`,

  `CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user ON refresh_tokens (user_id);`,
  `CREATE INDEX IF NOT EXISTS idx_refresh_tokens_hash ON refresh_tokens (token_hash);`,
];

// ---------------------------------------------------------------------------
// EKSEKUSI
// ---------------------------------------------------------------------------

async function initDatabase() {
  const client = await pool.connect();
  console.log('Koneksi ke Neon PostgreSQL berhasil. Memulai inisialisasi skema...\n');

  try {
    await client.query('BEGIN');

    for (let i = 0; i < STATEMENTS.length; i++) {
      const stmt = STATEMENTS[i];
      const label = stmt.trim().split('\n')[0].slice(0, 70);
      process.stdout.write(`[${i + 1}/${STATEMENTS.length}] ${label} ... `);
      await client.query(stmt);
      console.log('OK');
    }

    await client.query('COMMIT');
    console.log('\n✅ Skema database berhasil diinisialisasi/diverifikasi (idempotent).');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('\n❌ Gagal inisialisasi database. Transaksi di-rollback.');
    console.error(err);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
}

initDatabase();
