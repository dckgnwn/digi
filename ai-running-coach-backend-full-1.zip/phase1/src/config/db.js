'use strict';

/**
 * src/config/db.js
 * -----------------------------------------------------------------------
 * Koneksi pool Neon PostgreSQL bersama, dipakai oleh adaptiveEngine.js dan
 * service lain yang butuh akses database. Terpisah dari init-db.js karena
 * init-db.js hanya dijalankan sekali (migrasi), sementara db.js dipakai
 * terus-menerus di runtime API.
 * -----------------------------------------------------------------------
 */

require('dotenv').config();
const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL belum diset di environment variables');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // wajib untuk Neon
  max: 10,
  idleTimeoutMillis: 30000,
});

pool.on('error', (err) => {
  console.error('Unexpected error pada idle client Postgres:', err);
});

async function query(text, params) {
  return pool.query(text, params);
}

async function withTransaction(callback) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, query, withTransaction };
