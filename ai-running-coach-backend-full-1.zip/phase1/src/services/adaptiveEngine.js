'use strict';

/**
 * src/services/adaptiveEngine.js
 * -----------------------------------------------------------------------
 * Mengeksekusi konsekuensi KONKRET dari auditResult (hasil
 * geminiCoachService.auditExecutedRun) dan/atau kondisi cuaca terhadap
 * scheduled_workouts BESOK di database, lalu (jika terhubung) mendorong
 * pembaruan ke Google Calendar.
 *
 * ASUMSI KONTRAK auditResult (dari pemanggil / hasil gabungan fase
 * sebelumnya) — semua field WAJIB ada agar autoAdjustSchedule bisa bekerja:
 *   {
 *     session_date: 'YYYY-MM-DD',       // tanggal sesi yang diaudit (hari ini)
 *     ego_running_detected: boolean,
 *     cancel_tomorrow_interval: boolean,
 *     tsb: number,                      // TSB terkini (setelah sesi hari ini)
 *     weatherTempC: number | null,      // suhu saat/menjelang sesi besok, jika diketahui
 *     executed_activity_id: string | null, // untuk referensi coaching_logs
 *     schedule_adjustment_reason: string,
 *   }
 * -----------------------------------------------------------------------
 */

const { withTransaction } = require('../config/db');
const { google } = require('googleapis');

// ---------------------------------------------------------------------------
// KONSTANTA GUARDRAIL
// ---------------------------------------------------------------------------

const TSB_REST_THRESHOLD = -40;   // di bawah ini: istirahat total, bukan sekadar jalan
const TSB_WALK_THRESHOLD = -30;   // di bawah ini: downgrade ke jalan kaki zona 1
const WEATHER_ADJUST_TEMP_C = 30;
const WEATHER_ADJUST_SEC_MODERATE = 10; // 30°C < t < 35°C
const WEATHER_ADJUST_SEC_SEVERE = 15;   // t >= 35°C
const WEATHER_HR_ADJUST_BPM = 5;

const HARD_SESSION_TYPES = new Set(['INTERVAL', 'TEMPO', 'LONG_RUN']);

// ---------------------------------------------------------------------------
// FUNGSI MURNI (dapat diuji tanpa DB/Calendar)
// ---------------------------------------------------------------------------

/** Tambah n hari ke string tanggal 'YYYY-MM-DD', kembalikan 'YYYY-MM-DD'. */
function _addDays(dateStr, n) {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/**
 * Tentukan apakah & bagaimana sesi besok harus di-downgrade.
 * @returns {'REST'|'STRICT_ZONE1_WALK'|null} null berarti tidak perlu downgrade
 */
function determineDowngradeSessionType(auditResult) {
  const tsb = auditResult.tsb;
  const forceDowngrade = auditResult.cancel_tomorrow_interval === true || (typeof tsb === 'number' && tsb < TSB_WALK_THRESHOLD);

  if (!forceDowngrade) return null;

  if (typeof tsb === 'number' && tsb < TSB_REST_THRESHOLD) {
    return 'REST';
  }
  return 'STRICT_ZONE1_WALK';
}

/**
 * Hitung penyesuaian pace/HR akibat cuaca panas.
 * @param {number|null} tempC
 * @returns {{adjusted:boolean, paceAdjustmentSec:number, hrAdjustmentBpm:number}}
 */
function computeWeatherAdjustment(tempC) {
  if (typeof tempC !== 'number' || tempC <= WEATHER_ADJUST_TEMP_C) {
    return { adjusted: false, paceAdjustmentSec: 0, hrAdjustmentBpm: 0 };
  }
  const paceAdjustmentSec = tempC >= 35 ? WEATHER_ADJUST_SEC_SEVERE : WEATHER_ADJUST_SEC_MODERATE;
  return { adjusted: true, paceAdjustmentSec, hrAdjustmentBpm: WEATHER_HR_ADJUST_BPM };
}

/** Geser string pace "M:SS" sejumlah detik (boleh negatif). */
function _shiftPaceString(paceStr, deltaSec) {
  const [m, s] = String(paceStr).split(':').map(Number);
  const totalSec = Math.max(0, m * 60 + s + deltaSec);
  const newM = Math.floor(totalSec / 60);
  const newS = Math.round(totalSec % 60);
  return `${newM}:${String(newS).padStart(2, '0')}`;
}

/**
 * Terapkan penyesuaian cuaca ke objek prescribed_json (tidak memutasi input).
 */
function applyWeatherToPrescription(prescribedJson, weatherAdjustment) {
  if (!weatherAdjustment.adjusted || !prescribedJson || !prescribedJson.main_run) {
    return prescribedJson;
  }
  const clone = JSON.parse(JSON.stringify(prescribedJson));
  const mr = clone.main_run;
  mr.target_pace_min_sec_km = _shiftPaceString(mr.target_pace_min_sec_km, weatherAdjustment.paceAdjustmentSec);
  mr.target_pace_max_sec_km = _shiftPaceString(mr.target_pace_max_sec_km, weatherAdjustment.paceAdjustmentSec);
  mr.target_hr_max = mr.target_hr_max + weatherAdjustment.hrAdjustmentBpm;
  clone.weather_adjusted = true;
  return clone;
}

function _buildAdjustmentSummary({ oldType, newType, weatherAdjustment, reason }) {
  const parts = [];
  if (newType && newType !== oldType) {
    parts.push(`Sesi diturunkan dari '${oldType}' menjadi '${newType}'. Alasan: ${reason}`);
  }
  if (weatherAdjustment.adjusted) {
    parts.push(
      `Target pace dilonggarkan +${weatherAdjustment.paceAdjustmentSec}s/km dan batas HR ` +
      `+${weatherAdjustment.hrAdjustmentBpm}bpm karena prakiraan suhu tinggi.`
    );
  }
  return parts.length > 0 ? parts.join(' ') : 'Tidak ada penyesuaian.';
}

// ---------------------------------------------------------------------------
// GOOGLE CALENDAR
// ---------------------------------------------------------------------------

/**
 * Bangun OAuth2 client Google dari token tersimpan, dengan auto-persist
 * saat token di-refresh oleh library googleapis.
 */
function _buildGoogleOAuthClient(userId, integration, persistTokenCallback) {
  const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
  oauth2Client.setCredentials({
    access_token: integration.google_access_token,
    refresh_token: integration.google_refresh_token,
  });
  oauth2Client.on('tokens', async (tokens) => {
    try {
      await persistTokenCallback(userId, tokens);
    } catch (err) {
      console.error('[adaptiveEngine] Gagal menyimpan token Google baru:', err.message);
    }
  });
  return oauth2Client;
}

async function _persistRefreshedGoogleToken(userId, tokens) {
  const fields = [];
  const values = [];
  let idx = 1;

  if (tokens.access_token) {
    fields.push(`google_access_token = $${idx++}`);
    values.push(tokens.access_token);
  }
  if (tokens.refresh_token) {
    fields.push(`google_refresh_token = $${idx++}`);
    values.push(tokens.refresh_token);
  }
  if (tokens.expiry_date) {
    fields.push(`google_token_expires_at = $${idx++}`);
    values.push(new Date(tokens.expiry_date));
  }
  if (fields.length === 0) return;

  values.push(userId);
  const { query } = require('../config/db');
  await query(`UPDATE user_integrations SET ${fields.join(', ')} WHERE user_id = $${idx}`, values);
}

/**
 * Update event Google Calendar yang berkaitan dengan sesi besok, jika user
 * terhubung (punya google_calendar_id + token) dan event-nya sudah ada
 * (google_event_id tidak null).
 */
async function _updateGoogleCalendarEvent({ userId, integration, googleEventId, newTitle, summaryText }) {
  if (!integration || !integration.google_calendar_id || !googleEventId) {
    return { updated: false, reason: 'Tidak terhubung ke Google Calendar atau event belum ada' };
  }
  if (!integration.google_access_token && !integration.google_refresh_token) {
    return { updated: false, reason: 'Token Google Calendar belum tersedia untuk user ini' };
  }

  const oauth2Client = _buildGoogleOAuthClient(userId, integration, _persistRefreshedGoogleToken);
  const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

  const response = await calendar.events.patch({
    calendarId: integration.google_calendar_id,
    eventId: googleEventId,
    requestBody: {
      summary: newTitle,
      description: summaryText,
    },
  });

  return { updated: true, eventId: response.data.id, status: response.data.status };
}

// ---------------------------------------------------------------------------
// ORKESTRASI UTAMA
// ---------------------------------------------------------------------------

/**
 * Terapkan hasil audit ke jadwal besok: downgrade sesi jika Ego Running/TSB
 * kritis, sesuaikan pace jika cuaca panas, catat ke coaching_logs, dan
 * dorong perubahan ke Google Calendar jika terhubung.
 *
 * @param {string} userId
 * @param {object} auditResult lihat kontrak di header file ini
 * @returns {Promise<object>} ringkasan seluruh perubahan yang diterapkan
 */
async function autoAdjustSchedule(userId, auditResult) {
  if (!userId) throw new Error('userId wajib diisi');
  if (!auditResult || !auditResult.session_date) {
    throw new Error('auditResult.session_date wajib diisi untuk menentukan tanggal besok');
  }

  const tomorrowDate = _addDays(auditResult.session_date, 1);
  const downgradeType = determineDowngradeSessionType(auditResult);
  const weatherAdjustment = computeWeatherAdjustment(auditResult.weatherTempC);

  const changesApplied = [];

  const dbResult = await withTransaction(async (client) => {
    const { rows: tomorrowWorkouts } = await client.query(
      `SELECT * FROM scheduled_workouts WHERE user_id = $1 AND scheduled_date = $2`,
      [userId, tomorrowDate]
    );

    const updatedRows = [];

    for (const workout of tomorrowWorkouts) {
      const oldType = workout.workout_type;
      let newType = oldType;
      let newPrescribedJson = workout.prescribed_json;
      let reason = null;

      const isHardSession = HARD_SESSION_TYPES.has(oldType);

      if (downgradeType && isHardSession) {
        newType = downgradeType;
        reason =
          auditResult.schedule_adjustment_reason ||
          (auditResult.cancel_tomorrow_interval
            ? 'Ego Running terdeteksi kemarin — sesi kualitas besok dibatalkan demi mencegah akumulasi fatigue.'
            : `TSB kritis (${auditResult.tsb}) — sesi kualitas besok diturunkan untuk mencegah overreaching non-fungsional.`);

        // Sesi yang didowngrade ke REST/WALK tidak lagi butuh target pace lari
        // kualitas — kosongkan structure & set deskripsi baru.
        newPrescribedJson = {
          ...workout.prescribed_json,
          session_type: newType,
          main_run:
            newType === 'REST'
              ? null
              : {
                  ...(workout.prescribed_json?.main_run || {}),
                  description: 'Jalan kaki ringan Zone 1 — tidak ada target pace lari.',
                  structure: [],
                },
          coach_notes: reason,
        };
      } else if (weatherAdjustment.adjusted && oldType !== 'REST' && oldType !== 'GYM') {
        // Hanya terapkan penyesuaian cuaca jika sesi TIDAK didowngrade dan bukan REST/GYM
        newPrescribedJson = applyWeatherToPrescription(workout.prescribed_json, weatherAdjustment);
      }

      const changed = newType !== oldType || newPrescribedJson !== workout.prescribed_json;
      if (changed) {
        await client.query(
          `UPDATE scheduled_workouts
           SET workout_type = $1, prescribed_json = $2, updated_at = now()
           WHERE id = $3`,
          [newType, JSON.stringify(newPrescribedJson), workout.id]
        );

        const summaryText = _buildAdjustmentSummary({
          oldType,
          newType: newType !== oldType ? newType : null,
          weatherAdjustment,
          reason: reason || 'Penyesuaian cuaca',
        });

        updatedRows.push({
          workoutId: workout.id,
          oldType,
          newType,
          googleEventId: workout.google_event_id,
          title: workout.title,
          summaryText,
        });
      }
    }

    // Catat ke coaching_logs sekali per pemanggilan (terlepas berapa banyak
    // scheduled_workouts yang terdampak) agar riwayat auto-revisi mudah ditelusuri.
    if (updatedRows.length > 0) {
      await client.query(
        `INSERT INTO coaching_logs (user_id, executed_activity_id, evaluation_summary, ai_response_json, schedule_adjusted)
         VALUES ($1, $2, $3, $4, true)`,
        [
          userId,
          auditResult.executed_activity_id || null,
          `Auto-revisi jadwal ${tomorrowDate}: ${updatedRows.map((r) => r.summaryText).join(' | ')}`,
          JSON.stringify({ auditResult, updatedRows, weatherAdjustment }),
        ]
      );
    }

    // Ambil integrasi Google untuk update kalender (dibaca di transaksi yang sama
    // agar konsisten dengan state scheduled_workouts yang baru saja diubah).
    const { rows: integrationRows } = await client.query(
      `SELECT * FROM user_integrations WHERE user_id = $1`,
      [userId]
    );

    return { updatedRows, integration: integrationRows[0] || null };
  });

  // Update Google Calendar DI LUAR transaksi DB (panggilan eksternal, sama
  // seperti pola pemanggilan Gemini di Fase 0/2 — jangan menahan koneksi DB
  // menunggu API eksternal).
  for (const row of dbResult.updatedRows) {
    if (!row.googleEventId) continue;
    try {
      const calResult = await _updateGoogleCalendarEvent({
        userId,
        integration: dbResult.integration,
        googleEventId: row.googleEventId,
        newTitle: `${row.title} [DIREVISI: ${row.newType}]`,
        summaryText: row.summaryText,
      });
      changesApplied.push({ ...row, calendar: calResult });
    } catch (err) {
      console.error(`[adaptiveEngine] Gagal update Google Calendar untuk workout ${row.workoutId}:`, err.message);
      changesApplied.push({ ...row, calendar: { updated: false, reason: err.message } });
    }
  }

  // Workout yang tidak punya google_event_id tetap dilaporkan (tanpa percobaan kalender)
  for (const row of dbResult.updatedRows) {
    if (!row.googleEventId) {
      changesApplied.push({ ...row, calendar: { updated: false, reason: 'Tidak ada google_event_id' } });
    }
  }

  return {
    userId,
    tomorrowDate,
    downgradeType,
    weatherAdjustment,
    changesApplied,
  };
}

module.exports = {
  TSB_REST_THRESHOLD,
  TSB_WALK_THRESHOLD,
  WEATHER_ADJUST_TEMP_C,
  determineDowngradeSessionType,
  computeWeatherAdjustment,
  applyWeatherToPrescription,
  autoAdjustSchedule,
};
