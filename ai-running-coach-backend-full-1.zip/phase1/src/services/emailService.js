'use strict';

/**
 * src/services/emailService.js
 * -----------------------------------------------------------------------
 * Pengiriman email transaksional (verifikasi email, reset password).
 * Jika SMTP_HOST tidak diset, jatuh ke "dev mode": email TIDAK benar-benar
 * terkirim, isinya di-log ke console supaya development/testing tetap bisa
 * jalan tanpa akun SMTP sungguhan. Di produksi, WAJIB set SMTP_* di env.
 * -----------------------------------------------------------------------
 */

const nodemailer = require('nodemailer');

const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:3000';
const SMTP_HOST = process.env.SMTP_HOST;

let _transporter = null;
function _getTransporter() {
  if (!SMTP_HOST) return null; // dev mode
  if (!_transporter) {
    _transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === 'true',
      auth: process.env.SMTP_USER
        ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD }
        : undefined,
    });
  }
  return _transporter;
}

async function _sendEmail({ to, subject, html, text }) {
  const transporter = _getTransporter();

  if (!transporter) {
    console.log('\n========== [DEV MODE] EMAIL TIDAK DIKIRIM SUNGGUHAN ==========');
    console.log(`Kepada : ${to}`);
    console.log(`Subjek : ${subject}`);
    console.log(`Isi    :\n${text}`);
    console.log('================================================================\n');
    return { devMode: true };
  }

  const info = await transporter.sendMail({
    from: process.env.SMTP_FROM || 'APEX Coach <noreply@apexcoach.app>',
    to,
    subject,
    text,
    html,
  });
  return { devMode: false, messageId: info.messageId };
}

async function sendVerificationEmail(email, verificationToken) {
  const link = `${FRONTEND_URL}/verify-email?token=${verificationToken}`;
  return _sendEmail({
    to: email,
    subject: 'Verifikasi Email — APEX Running Coach',
    text: `Klik tautan berikut untuk verifikasi email Anda (berlaku 24 jam):\n${link}`,
    html: `<p>Klik tautan berikut untuk verifikasi email Anda (berlaku 24 jam):</p><p><a href="${link}">${link}</a></p>`,
  });
}

async function sendPasswordResetEmail(email, resetToken) {
  const link = `${FRONTEND_URL}/reset-password?token=${resetToken}`;
  return _sendEmail({
    to: email,
    subject: 'Reset Password — APEX Running Coach',
    text: `Klik tautan berikut untuk mengatur ulang password Anda (berlaku 1 jam). Abaikan jika Anda tidak meminta ini:\n${link}`,
    html: `<p>Klik tautan berikut untuk mengatur ulang password Anda (berlaku 1 jam). Abaikan jika Anda tidak meminta ini:</p><p><a href="${link}">${link}</a></p>`,
  });
}

module.exports = { sendVerificationEmail, sendPasswordResetEmail };
