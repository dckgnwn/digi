'use strict';

/**
 * src/services/weatherService.js
 * -----------------------------------------------------------------------
 * Integrasi Open-Meteo (https://open-meteo.com) — API cuaca gratis, keyless,
 * tidak butuh API key/signup. Dipakai untuk mengisi weatherTempC pada
 * pipeline aktivitas (guardrail weather adaptation di adaptiveEngine.js).
 *
 * Dua endpoint dipakai:
 *  - archive-api.open-meteo.com/v1/archive : data historis (ERA5), cocok
 *    untuk aktivitas yang sudah beberapa hari/minggu lalu.
 *  - api.open-meteo.com/v1/forecast (dengan start_date/end_date) : mencakup
 *    beberapa hari terakhir + prakiraan, dipakai sebagai FALLBACK saat
 *    archive belum punya data untuk tanggal yang sangat baru (lag beberapa
 *    hari pada dataset ERA5).
 * -----------------------------------------------------------------------
 */

const ARCHIVE_URL = 'https://archive-api.open-meteo.com/v1/archive';
const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';

/** Format Date -> "YYYY-MM-DDTHH:00" (UTC, tanpa detik/offset) sesuai format hourly.time Open-Meteo saat timezone=UTC. */
function _toHourString(date) {
  return date.toISOString().slice(0, 13) + ':00';
}

/** Cari index waktu terdekat di array hourly.time terhadap targetHourStr. */
function _findClosestHourIndex(hourlyTimes, targetHourStr) {
  const exactIdx = hourlyTimes.indexOf(targetHourStr);
  if (exactIdx !== -1) return exactIdx;

  const targetMs = new Date(`${targetHourStr}:00Z`).getTime();
  let closestIdx = -1;
  let closestDiff = Infinity;
  for (let i = 0; i < hourlyTimes.length; i++) {
    const diff = Math.abs(new Date(`${hourlyTimes[i]}:00Z`).getTime() - targetMs);
    if (diff < closestDiff) {
      closestDiff = diff;
      closestIdx = i;
    }
  }
  // Tolak jika selisih lebih dari 3 jam — terlalu jauh untuk dianggap representatif.
  return closestDiff <= 3 * 60 * 60 * 1000 ? closestIdx : -1;
}

async function _fetchHourlyTemperature(baseUrl, lat, lng, dateStr) {
  const url = `${baseUrl}?latitude=${lat}&longitude=${lng}&start_date=${dateStr}&end_date=${dateStr}&hourly=temperature_2m&timezone=UTC`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Open-Meteo API error (HTTP ${response.status}) dari ${baseUrl}`);
  }
  const data = await response.json();
  if (!data.hourly || !Array.isArray(data.hourly.temperature_2m)) {
    return null;
  }
  return data.hourly;
}

/**
 * Ambil suhu (°C) pada waktu & lokasi aktivitas tertentu.
 * @param {object} p { lat, lng, isoDateTime }
 * @returns {Promise<number|null>} suhu dalam °C, atau null jika tidak tersedia/lokasi tidak ada
 */
async function getTemperatureAtActivity({ lat, lng, isoDateTime }) {
  if (lat == null || lng == null) return null;

  const activityDate = new Date(isoDateTime);
  const dateStr = activityDate.toISOString().slice(0, 10);
  const targetHourStr = _toHourString(activityDate);

  try {
    let hourly = await _fetchHourlyTemperature(ARCHIVE_URL, lat, lng, dateStr);
    let idx = hourly ? _findClosestHourIndex(hourly.time, targetHourStr) : -1;

    if (idx === -1) {
      // Fallback: dataset archive (ERA5) punya lag beberapa hari untuk tanggal
      // yang sangat baru — coba endpoint forecast yang juga menyimpan histori pendek.
      hourly = await _fetchHourlyTemperature(FORECAST_URL, lat, lng, dateStr);
      idx = hourly ? _findClosestHourIndex(hourly.time, targetHourStr) : -1;
    }

    if (idx === -1 || !hourly) return null;
    const temp = hourly.temperature_2m[idx];
    return typeof temp === 'number' ? temp : null;
  } catch (err) {
    console.warn(`[weatherService] Gagal mengambil suhu untuk (${lat},${lng}) @ ${isoDateTime}:`, err.message);
    return null;
  }
}

module.exports = { getTemperatureAtActivity };
