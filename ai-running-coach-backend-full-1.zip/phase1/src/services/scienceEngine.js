'use strict';

/**
 * src/services/scienceEngine.js
 * -----------------------------------------------------------------------
 * Kumpulan fungsi matematika MURNI (pure function, tanpa I/O, tanpa
 * dependency database) untuk sports science engine AI Running Coach Elit.
 *
 * Basis ilmiah:
 *   - VDOT & Pace Zones : Daniels & Gilbert (1979), "Daniels' Running Formula"
 *   - TSS (hrTSS)       : varian heart-rate dari konsep TSS Dr. Andrew Coggan,
 *                         diadaptasi untuk lari tanpa power meter
 *   - CTL/ATL/TSB       : Banister Impulse-Response two-component model,
 *                         diadopsi TrainingPeaks (PMC methodology)
 * -----------------------------------------------------------------------
 */

// =============================================================================
// UTILITAS INTERNAL
// =============================================================================

function round(value, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

/** VO2 (ml/kg/min) dari kecepatan v dalam meter/menit — Daniels & Gilbert */
function _vo2FromVelocity(v) {
  return -4.6 + 0.182258 * v + 0.000104 * v * v;
}

/** %VO2max yang bisa dipertahankan selama t menit — Daniels & Gilbert */
function _percentVO2Max(tMinutes) {
  return (
    0.8 +
    0.1894393 * Math.exp(-0.012778 * tMinutes) +
    0.2989558 * Math.exp(-0.1932605 * tMinutes)
  );
}

/**
 * Selesaikan kecepatan v (m/menit) dari target VO2 via rumus kuadrat:
 *   0.000104 v^2 + 0.182258 v + (-4.6 - vo2Target) = 0
 * Akar positif (besar) dipakai karena v > 0 secara fisik.
 */
function _velocityFromVO2(vo2Target) {
  const a = 0.000104;
  const b = 0.182258;
  const c = -4.6 - vo2Target;
  const discriminant = b * b - 4 * a * c;
  if (discriminant < 0) {
    throw new Error(`Tidak ada solusi kecepatan real untuk VO2=${vo2Target}`);
  }
  return (-b + Math.sqrt(discriminant)) / (2 * a); // m/menit
}

// =============================================================================
// 1. formatPaceFromSec
// =============================================================================

/**
 * Konversi total detik menjadi string pace "M:SS" (mis. 330 -> "5:30").
 * Menit TIDAK di-pad-nol (konvensi tampilan pace lari umum: "4:32/km",
 * bukan "04:32/km"), detik selalu 2 digit.
 * @param {number} totalSec boleh desimal, akan dibulatkan ke detik terdekat
 * @returns {string}
 */
function formatPaceFromSec(totalSec) {
  if (typeof totalSec !== 'number' || !isFinite(totalSec) || totalSec < 0) {
    throw new Error('formatPaceFromSec membutuhkan totalSec berupa angka non-negatif');
  }
  const rounded = Math.round(totalSec);
  const minutes = Math.floor(rounded / 60);
  const seconds = rounded % 60;
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

// =============================================================================
// 2. calculateVDOT
// =============================================================================

/**
 * Estimasi VDOT dari hasil race/time-trial aktual.
 * @param {number} distanceKm jarak dalam kilometer (mis. 5 untuk 5K)
 * @param {number} timeMinutes waktu tempuh dalam menit (boleh desimal, mis. 25.5)
 * @returns {number} nilai VDOT, dibulatkan 2 desimal
 */
function calculateVDOT(distanceKm, timeMinutes) {
  if (distanceKm <= 0 || timeMinutes <= 0) {
    throw new Error('distanceKm dan timeMinutes harus bernilai positif');
  }
  const distanceMeters = distanceKm * 1000;
  const velocity = distanceMeters / timeMinutes; // meter per menit
  const vo2 = _vo2FromVelocity(velocity);
  const pctMax = _percentVO2Max(timeMinutes);
  const vdot = vo2 / pctMax;
  return round(vdot, 2);
}

// =============================================================================
// 3. calculatePaceZones
// =============================================================================

/**
 * Persentase %VDOT untuk tiap zona intensitas — Daniels' Running Formula ed.4
 */
const _DANIELS_ZONE_PERCENTAGES = {
  easy:       { pctMin: 0.59, pctMax: 0.74 },
  marathon:   { pctMin: 0.75, pctMax: 0.84 },
  threshold:  { pctMin: 0.83, pctMax: 0.88 },
  interval:   { pctMin: 0.95, pctMax: 1.00 },
  repetition: { pctMin: 1.05, pctMax: 1.20 },
};

/**
 * Hitung velocity (m/menit) dari VDOT dan %VDOT target, lalu konversi ke
 * pace detik/km.
 */
function _paceSecKmAtPercent(vdot, pct) {
  const vo2Target = vdot * pct;
  const velocity = _velocityFromVO2(vo2Target); // m/menit
  const minPerKm = 1000 / velocity;
  return minPerKm * 60; // detik/km
}

/**
 * Bangun peta pace training lengkap (string terformat "MM:SS") dari satu
 * nilai VDOT: E-Pace, M-Pace, T-Pace, I-Pace, R-Pace.
 * @param {number} vdot
 * @returns {{easy:string, marathon:string, threshold:string, interval:string, repetition:string}}
 *          setiap value berformat "tercepat–terlambat /km", mis. "6:00-6:15"
 */
function calculatePaceZones(vdot) {
  if (vdot <= 0) throw new Error('vdot harus bernilai positif');

  const result = {};
  for (const [zoneName, { pctMin, pctMax }] of Object.entries(_DANIELS_ZONE_PERCENTAGES)) {
    // pctMax -> intensitas lebih tinggi -> velocity lebih cepat -> detik/km lebih kecil
    const fastestSec = _paceSecKmAtPercent(vdot, pctMax);
    const slowestSec = _paceSecKmAtPercent(vdot, pctMin);
    result[zoneName] = `${formatPaceFromSec(fastestSec)}-${formatPaceFromSec(slowestSec)}`;
  }
  return result;
}

// =============================================================================
// 4. calculateTSS  (hrTSS — varian heart-rate dari Training Stress Score)
// =============================================================================

/**
 * Training Stress Score berbasis Heart Rate (hrTSS), diadaptasi untuk lari
 * tanpa power meter:
 *
 *   IF (Intensity Factor) = avgHR / LTHR
 *   TSS = (durationMinutes / 60) * IF^2 * 100
 *
 * Interpretasi: 1 jam berlari TEPAT di LTHR (IF=1.0) menghasilkan TSS=100,
 * setara dengan definisi TSS klasik Coggan untuk 1 jam di FTP.
 *
 * @param {number} durationMin durasi sesi dalam menit
 * @param {number} avgHr rata-rata heart rate sesi (bpm)
 * @param {number} lthr Lactate Threshold Heart Rate atlet (bpm)
 * @returns {number} TSS, dibulatkan 1 desimal
 */
function calculateTSS(durationMin, avgHr, lthr) {
  if (durationMin <= 0) throw new Error('durationMin harus positif');
  if (lthr <= 0) throw new Error('lthr harus positif');
  if (avgHr <= 0) throw new Error('avgHr harus positif');

  const intensityFactor = avgHr / lthr;
  const tss = (durationMin / 60) * intensityFactor * intensityFactor * 100;
  return round(tss, 1);
}

// =============================================================================
// 5. updateCTL_ATL_TSB  (Banister Impulse-Response / TrainingPeaks PMC)
// =============================================================================

const CTL_TIME_CONSTANT_DAYS = 42;
const ATL_TIME_CONSTANT_DAYS = 7;

/**
 * Update CTL (Fitness, EWMA 42 hari), ATL (Fatigue, EWMA 7 hari), dan hitung
 * TSB (Form).
 *
 * PENTING soal urutan TSB: TSB merepresentasikan kesegaran atlet SAAT
 * MEMULAI sesi hari ini — yaitu hasil akumulasi CTL/ATL dari SEBELUM sesi
 * hari ini ditambahkan (currentCTL, currentATL adalah nilai kemarin/akhir
 * hari sebelumnya). Karena itu TSB dihitung dari currentCTL - currentATL,
 * BUKAN dari nilai CTL/ATL yang baru setelah todayTSS dimasukkan. Ini
 * konvensi standar TrainingPeaks Performance Management Chart.
 *
 * @param {number} currentCTL CTL akhir hari sebelumnya
 * @param {number} currentATL ATL akhir hari sebelumnya
 * @param {number} todayTSS TSS dari sesi hari ini (0 jika hari istirahat)
 * @returns {{ctl:number, atl:number, tsb:number}}
 *          ctl/atl = nilai BARU setelah todayTSS dimasukkan (dipakai sebagai
 *          "currentCTL/currentATL" untuk pemanggilan hari berikutnya);
 *          tsb = form atlet PADA HARI INI (sebelum sesi hari ini)
 */
function updateCTL_ATL_TSB(currentCTL, currentATL, todayTSS) {
  if (todayTSS < 0) throw new Error('todayTSS tidak boleh negatif');

  const tsb = round(currentCTL - currentATL, 2);

  const ctlAlpha = 1 - Math.exp(-1 / CTL_TIME_CONSTANT_DAYS);
  const atlAlpha = 1 - Math.exp(-1 / ATL_TIME_CONSTANT_DAYS);

  const newCTL = currentCTL + (todayTSS - currentCTL) * ctlAlpha;
  const newATL = currentATL + (todayTSS - currentATL) * atlAlpha;

  return {
    ctl: round(newCTL, 2),
    atl: round(newATL, 2),
    tsb,
  };
}

// =============================================================================
// 6. validateGoalFeasibility
// =============================================================================

/**
 * Estimasi laju peningkatan VDOT mingguan yang AMAN & REALISTIS untuk
 * pelari rekreasional-menengah dengan program periodisasi yang dieksekusi
 * dengan baik. Angka ini konservatif secara sengaja — deviasi ke arah
 * optimis meningkatkan risiko overtraining/cedera pada validasi goal.
 * Referensi kualitatif: laju adaptasi VO2max/VDOT melambat (diminishing
 * returns) seiring mendekati potensi genetik individu, sehingga model
 * linear ini hanya valid untuk horizon waktu training block wajar (8-24
 * minggu), bukan ekstrapolasi jangka sangat panjang.
 */
const SAFE_VDOT_GAIN_PER_WEEK = 0.3; // titik VDOT per minggu
const MIN_WEEKS_FOR_ANY_ADAPTATION = 4; // di bawah ini, tubuh belum sempat beradaptasi struktural

/**
 * Validasi apakah target race realistis dicapai dalam sisa waktu yang ada.
 * @param {number} currentVDOT VDOT atlet saat ini
 * @param {number} targetDistanceKm jarak race target (km)
 * @param {number} targetTimeSeconds target waktu finish (detik)
 * @param {number} weeksRemaining sisa minggu sampai race
 * @returns {{
 *   currentVDOT:number, requiredVDOT:number, vdotGap:number,
 *   achievableVDOTGain:number, weeksRemaining:number,
 *   status:'REALISTIC'|'STAGED_MILESTONE_REQUIRED'|'HIGH_INJURY_RISK',
 *   message:string
 * }}
 */
function validateGoalFeasibility(currentVDOT, targetDistanceKm, targetTimeSeconds, weeksRemaining) {
  if (currentVDOT <= 0) throw new Error('currentVDOT harus positif');
  if (targetDistanceKm <= 0) throw new Error('targetDistanceKm harus positif');
  if (targetTimeSeconds <= 0) throw new Error('targetTimeSeconds harus positif');
  if (weeksRemaining < 0) throw new Error('weeksRemaining tidak boleh negatif');

  const targetTimeMinutes = targetTimeSeconds / 60;
  const requiredVDOT = calculateVDOT(targetDistanceKm, targetTimeMinutes);
  const vdotGap = round(requiredVDOT - currentVDOT, 2);
  const achievableVDOTGain = round(SAFE_VDOT_GAIN_PER_WEEK * weeksRemaining, 2);

  let status;
  let message;

  if (weeksRemaining < MIN_WEEKS_FOR_ANY_ADAPTATION && vdotGap > 0) {
    status = 'HIGH_INJURY_RISK';
    message =
      `Sisa waktu hanya ${weeksRemaining} minggu — di bawah ambang minimum ` +
      `${MIN_WEEKS_FOR_ANY_ADAPTATION} minggu untuk adaptasi fisiologis struktural apa pun ` +
      `(mitokondria, kapiler, ekonomi lari). Mengejar VDOT gap ${vdotGap} pada jendela ini ` +
      `berarti satu-satunya cara "mengejar" adalah lewat volume/intensitas ekstrem mendadak — ` +
      `resep untuk cedera overuse, bukan peningkatan performa.`;
  } else if (vdotGap <= 0) {
    status = 'REALISTIC';
    message =
      `Target ini SUDAH berada dalam kapasitas fisiologis Anda saat ini (VDOT dibutuhkan ` +
      `${requiredVDOT} vs VDOT saat ini ${currentVDOT}). Fokus program: eksekusi pacing dan ` +
      `race-specific preparation, bukan pengembangan kapasitas aerobik dasar.`;
  } else if (vdotGap <= achievableVDOTGain * 0.7) {
    status = 'REALISTIC';
    message =
      `VDOT gap ${vdotGap} berada dalam margin aman dari estimasi peningkatan yang bisa dicapai ` +
      `(~${achievableVDOTGain} poin dalam ${weeksRemaining} minggu). Target REALISTIS dengan ` +
      `periodisasi progresif standar (base -> build -> peak -> taper).`;
  } else if (vdotGap <= achievableVDOTGain * 1.3) {
    status = 'STAGED_MILESTONE_REQUIRED';
    message =
      `VDOT gap ${vdotGap} berada di batas atas kapasitas adaptasi yang realistis untuk ` +
      `${weeksRemaining} minggu (estimasi maksimum ~${achievableVDOTGain} poin). Target MASIH ` +
      `mungkin, TAPI wajib dipecah jadi milestone bertahap (race persiapan di minggu-minggu ` +
      `tengah) untuk memvalidasi progres nyata sebelum berkomitmen penuh pada target akhir.`;
  } else {
    status = 'HIGH_INJURY_RISK';
    message =
      `VDOT gap ${vdotGap} jauh melampaui estimasi kapasitas adaptasi aman untuk ${weeksRemaining} ` +
      `minggu (~${achievableVDOTGain} poin). Mengejar target ini pada jendela waktu ini memaksa ` +
      `overload di luar batas toleransi jaringan (tendon/tulang) dan sistem saraf. Rekomendasi: ` +
      `revisi target waktu ATAU perpanjang jendela persiapan.`;
  }

  return {
    currentVDOT: round(currentVDOT, 2),
    requiredVDOT,
    vdotGap,
    achievableVDOTGain,
    weeksRemaining,
    status,
    message,
  };
}

/**
 * Estimasi VDOT dari sesi lari SUBMAKSIMAL (bukan race/time-trial) memakai
 * rasio Heart Rate Reserve (Swain regression) untuk mendekati %VO2max efektif.
 * HANYA valid untuk usaha aerobik steady-state (Easy/Long Run) — TIDAK valid
 * untuk interval/tempo karena hubungan pace:HR berbeda pada usaha non-steady.
 * @param {object} p { distanceMeters, timeSeconds, avgHR, hrMax, hrRest }
 * @returns {number} VDOT
 */
function estimateVDOTFromTraining({ distanceMeters, timeSeconds, avgHR, hrMax, hrRest }) {
  const velocity = distanceMeters / (timeSeconds / 60); // m/menit
  const vo2AtVelocity = _vo2FromVelocity(velocity);
  const hrr = (avgHR - hrRest) / (hrMax - hrRest);
  // %VO2max ~ %HRR terkoreksi (Swain et al.), dibatasi konservatif agar
  // tidak overestimate VDOT dari usaha yang bukan usaha maksimal.
  const pctVO2FromHRR = Math.min(0.97, Math.max(0.5, 1.2435 * hrr - 0.1794));
  const vdot = vo2AtVelocity / pctVO2FromHRR;
  return round(vdot, 2);
}

// =============================================================================
// 7. READINESS SCORE — dipakai dashboard Fase 4/5 (simplifikasi 3-status dari TSB)
// =============================================================================

/**
 * Petakan TSB menjadi skor 0-100 untuk gauge dashboard. Heuristik linear
 * sederhana (BUKAN standar industri baku — TSB tidak punya skala 0-100
 * resmi): TSB=0 (netral) -> 50; setiap +/-1 TSB menggeser skor 1 poin,
 * di-clamp ke [0,100].
 */
function tsbToReadinessPct(tsb) {
  return Math.max(0, Math.min(100, Math.round(50 + tsb)));
}

/**
 * Simplifikasi 3-status untuk tampilan UI (spec dashboard: Fresh/Optimal/
 * Overreaching) — versi lebih kaya (5-level) ada di trainingLoad.classifyTSB
 * pada backend Fase 0 untuk kebutuhan guardrail yang lebih presisi.
 */
function readinessStatusFromTsb(tsb) {
  if (tsb > 5) return 'FRESH';
  if (tsb < -10) return 'OVERREACHING';
  return 'OPTIMAL';
}

// =============================================================================
// EXPORTS
// =============================================================================

module.exports = {
  formatPaceFromSec,
  calculateVDOT,
  estimateVDOTFromTraining,
  calculatePaceZones,
  calculateTSS,
  updateCTL_ATL_TSB,
  validateGoalFeasibility,
  tsbToReadinessPct,
  readinessStatusFromTsb,
  // konstanta diekspos untuk keperluan testing/tuning eksternal
  CTL_TIME_CONSTANT_DAYS,
  ATL_TIME_CONSTANT_DAYS,
  SAFE_VDOT_GAIN_PER_WEEK,
  MIN_WEEKS_FOR_ANY_ADAPTATION,
};
