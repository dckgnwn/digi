'use strict';

/**
 * src/services/stravaService.js
 * -----------------------------------------------------------------------
 * Integrasi Strava API v3: refresh token OAuth otomatis, fetch detail
 * aktivitas, dan fetch 1Hz streams (dipakai untuk cardiac drift saat user
 * tidak mengunggah file .FIT manual).
 * -----------------------------------------------------------------------
 */

const { query } = require('../config/db');

const STRAVA_CLIENT_ID = process.env.STRAVA_CLIENT_ID;
const STRAVA_CLIENT_SECRET = process.env.STRAVA_CLIENT_SECRET;
const STRAVA_OAUTH_TOKEN_URL = 'https://www.strava.com/oauth/token';
const STRAVA_API_BASE = 'https://www.strava.com/api/v3';
const TOKEN_REFRESH_BUFFER_SEC = 300; // refresh 5 menit sebelum benar-benar kadaluarsa

// ---------------------------------------------------------------------------
// OAUTH TOKEN REFRESH
// ---------------------------------------------------------------------------

/**
 * Pastikan access token Strava user masih valid; refresh otomatis jika
 * `strava_token_expires_at` sudah/hampir kadaluarsa, dan persist token baru
 * ke Neon PostgreSQL.
 * @param {string} userId
 * @returns {Promise<string>} access token yang valid untuk dipakai memanggil Strava API
 */
async function getValidStravaAccessToken(userId) {
  if (!STRAVA_CLIENT_ID || !STRAVA_CLIENT_SECRET) {
    throw new Error('STRAVA_CLIENT_ID / STRAVA_CLIENT_SECRET belum diset di environment variables');
  }

  const { rows } = await query(`SELECT * FROM user_integrations WHERE user_id = $1`, [userId]);
  if (rows.length === 0 || !rows[0].strava_refresh_token) {
    throw new Error(`User ${userId} belum menghubungkan akun Strava (refresh token tidak ada)`);
  }
  const integration = rows[0];

  const nowSec = Math.floor(Date.now() / 1000);
  const expiresAtSec = integration.strava_token_expires_at
    ? Math.floor(new Date(integration.strava_token_expires_at).getTime() / 1000)
    : 0;

  const stillValid = integration.strava_access_token && expiresAtSec - nowSec > TOKEN_REFRESH_BUFFER_SEC;
  if (stillValid) {
    return integration.strava_access_token;
  }

  // Token kadaluarsa/hampir kadaluarsa -> refresh
  const response = await fetch(STRAVA_OAUTH_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_id: STRAVA_CLIENT_ID,
      client_secret: STRAVA_CLIENT_SECRET,
      grant_type: 'refresh_token',
      refresh_token: integration.strava_refresh_token,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Gagal refresh token Strava untuk user ${userId} (HTTP ${response.status}): ${errText}`);
  }

  const data = await response.json();

  await query(
    `UPDATE user_integrations
     SET strava_access_token = $1, strava_refresh_token = $2, strava_token_expires_at = to_timestamp($3)
     WHERE user_id = $4`,
    [data.access_token, data.refresh_token, data.expires_at, userId]
  );

  return data.access_token;
}

/**
 * Cari userId internal dari strava_athlete_id (dipakai saat menerima webhook,
 * karena payload webhook hanya berisi owner_id versi Strava).
 * @param {number|string} stravaAthleteId
 * @returns {Promise<string|null>} userId internal, atau null jika tidak ditemukan
 */
async function findUserIdByStravaAthleteId(stravaAthleteId) {
  const { rows } = await query(
    `SELECT user_id FROM user_integrations WHERE strava_athlete_id = $1`,
    [stravaAthleteId]
  );
  return rows.length > 0 ? rows[0].user_id : null;
}

// ---------------------------------------------------------------------------
// FETCH DATA AKTIVITAS
// ---------------------------------------------------------------------------

/**
 * Ambil detail lengkap satu aktivitas dari Strava.
 * @param {string|number} activityId
 * @param {string} accessToken
 * @returns {Promise<object>} objek aktivitas Strava (distance, moving_time,
 *          average_heartrate, max_heartrate, average_cadence, type, dsb.)
 */
async function getStravaActivityDetails(activityId, accessToken) {
  const response = await fetch(`${STRAVA_API_BASE}/activities/${activityId}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (response.status === 401) {
    throw new Error(`Token Strava tidak valid/kadaluarsa saat fetch aktivitas ${activityId} (401 Unauthorized)`);
  }
  if (response.status === 404) {
    throw new Error(`Aktivitas Strava ${activityId} tidak ditemukan (404) — mungkin sudah dihapus atau private`);
  }
  if (response.status === 429) {
    throw new Error('Strava API rate limit tercapai (429) — coba lagi setelah jendela rate limit reset');
  }
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Strava API error saat fetch aktivitas ${activityId} (HTTP ${response.status}): ${errText}`);
  }

  return response.json();
}

/**
 * Ambil 1Hz streams (time, heartrate, velocity_smooth, cadence, altitude)
 * untuk keperluan cardiac drift, jika tersedia untuk aktivitas ini.
 * @param {string|number} activityId
 * @param {string} accessToken
 * @returns {Promise<Array<{t:number, heart_rate:number|null, speed_mps:number|null, cadence_rpm:number|null, altitude_m:number|null}>|null>}
 *          null jika streams tidak tersedia untuk aktivitas ini
 */
async function getStravaActivityStreams(activityId, accessToken) {
  const keys = 'time,heartrate,velocity_smooth,cadence,altitude';
  const response = await fetch(
    `${STRAVA_API_BASE}/activities/${activityId}/streams?keys=${keys}&key_by_type=true`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );

  if (response.status === 404) {
    return null; // aktivitas tanpa streams (mis. entri manual tanpa GPS/sensor)
  }
  if (response.status === 401) {
    throw new Error(`Token Strava tidak valid/kadaluarsa saat fetch streams aktivitas ${activityId} (401)`);
  }
  if (response.status === 429) {
    throw new Error('Strava API rate limit tercapai (429) saat fetch streams');
  }
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Strava API error saat fetch streams aktivitas ${activityId} (HTTP ${response.status}): ${errText}`);
  }

  const streams = await response.json();
  const timeArr = streams.time?.data || [];
  if (timeArr.length === 0) return null;

  const hrArr = streams.heartrate?.data || [];
  const speedArr = streams.velocity_smooth?.data || [];
  const cadenceArr = streams.cadence?.data || [];
  const altitudeArr = streams.altitude?.data || [];

  return timeArr.map((t, i) => ({
    t,
    heart_rate: hrArr[i] ?? null,
    speed_mps: speedArr[i] ?? null,
    // CATATAN: berbeda dari file .FIT, cadence stream Strava untuk lari TIDAK
    // digandakan di sini karena semantik per-aktivitas bervariasi tergantung
    // device sumber; nilai dikembalikan APA ADANYA dari Strava.
    cadence_rpm: cadenceArr[i] ?? null,
    altitude_m: altitudeArr[i] ?? null,
  }));
}

module.exports = {
  getValidStravaAccessToken,
  findUserIdByStravaAthleteId,
  getStravaActivityDetails,
  getStravaActivityStreams,
};
