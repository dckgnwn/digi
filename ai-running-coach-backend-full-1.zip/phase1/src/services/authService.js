'use strict';

/**
 * src/services/authService.js
 * -----------------------------------------------------------------------
 * Autentikasi berbasis JWT dua-token:
 *   - Access token: JWT pendek (15 menit default), dipakai di header
 *     Authorization untuk setiap request API — kalau bocor, dampaknya
 *     terbatas karena cepat kadaluarsa.
 *   - Refresh token: string acak opaque (BUKAN JWT), disimpan sebagai HASH
 *     di tabel refresh_tokens, umur panjang (30 hari), DIROTASI setiap kali
 *     dipakai (token lama langsung di-revoke, token baru diterbitkan).
 *     Jika token yang SUDAH di-revoke dicoba dipakai lagi (indikasi token
 *     dicuri & sedang dipakai pihak lain setelah pemilik sah melakukan
 *     refresh), SELURUH refresh token milik user langsung di-revoke sebagai
 *     tindakan pengamanan ("refresh token reuse detection").
 *
 * Plus: verifikasi email (token acak, 24 jam) dan reset password (token
 * acak, 1 jam) — keduanya disimpan sebagai HASH di kolom users, bukan
 * token mentah, dengan alasan sama seperti refresh token.
 * -----------------------------------------------------------------------
 */

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query, withTransaction } = require('../config/db');
const emailService = require('./emailService');

const JWT_SECRET = process.env.JWT_SECRET;
const ACCESS_TOKEN_EXPIRES_IN = process.env.ACCESS_TOKEN_EXPIRES_IN || '15m';
const REFRESH_TOKEN_TTL_DAYS = Number(process.env.REFRESH_TOKEN_TTL_DAYS) || 30;
const EMAIL_VERIFICATION_TTL_HOURS = 24;
const PASSWORD_RESET_TTL_HOURS = 1;
const BCRYPT_SALT_ROUNDS = 12;

if (!JWT_SECRET) {
  throw new Error('JWT_SECRET belum diset di environment variables');
}

// ---------------------------------------------------------------------------
// UTILITAS TOKEN
// ---------------------------------------------------------------------------

function _sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function _randomToken(bytes = 40) {
  return crypto.randomBytes(bytes).toString('hex');
}

function generateAccessToken(user) {
  return jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: ACCESS_TOKEN_EXPIRES_IN });
}

/** @returns {{sub:string, email:string}} payload jika valid; melempar error jika tidak valid/kadaluarsa */
function verifyAccessToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

/**
 * Terbitkan refresh token baru untuk user, simpan HASH-nya di DB.
 * @returns {Promise<string>} refresh token MENTAH (hanya dikembalikan sekali ini saja)
 */
async function _issueRefreshToken(userId, client = null) {
  const rawToken = _randomToken();
  const tokenHash = _sha256(rawToken);
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000);

  const runner = client || { query };
  await runner.query(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1,$2,$3)`,
    [userId, tokenHash, expiresAt]
  );
  return rawToken;
}

async function _issueTokenPair(user, client = null) {
  const accessToken = generateAccessToken(user);
  const refreshToken = await _issueRefreshToken(user.id, client);
  return { accessToken, refreshToken };
}

// ---------------------------------------------------------------------------
// REGISTER / LOGIN
// ---------------------------------------------------------------------------

async function registerUser({ email, password, fullName, weightKg, heightCm }) {
  if (!email || !password || !fullName) {
    throw new Error('email, password, dan fullName wajib diisi');
  }
  if (password.length < 8) {
    throw new Error('Password minimal 8 karakter');
  }

  const normalizedEmail = email.toLowerCase();
  const existing = await query(`SELECT id FROM users WHERE email = $1`, [normalizedEmail]);
  if (existing.rows.length > 0) {
    throw new Error('Email sudah terdaftar');
  }

  const passwordHash = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);
  const verificationToken = _randomToken(24);
  const verificationTokenHash = _sha256(verificationToken);
  const verificationExpiresAt = new Date(Date.now() + EMAIL_VERIFICATION_TTL_HOURS * 60 * 60 * 1000);

  const { rows } = await query(
    `INSERT INTO users
       (email, password_hash, full_name, weight_kg, height_cm,
        email_verification_token, email_verification_expires_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     RETURNING id, email, full_name, weight_kg, height_cm, email_verified, created_at`,
    [normalizedEmail, passwordHash, fullName, weightKg || null, heightCm || null, verificationTokenHash, verificationExpiresAt]
  );
  const user = rows[0];

  try {
    await emailService.sendVerificationEmail(user.email, verificationToken);
  } catch (err) {
    // Kegagalan kirim email TIDAK boleh menggagalkan registrasi — user tetap
    // bisa pakai akunnya dan minta kirim ulang verifikasi nanti.
    console.error('[authService] Gagal mengirim email verifikasi:', err.message);
  }

  const tokens = await _issueTokenPair(user);
  return { ...tokens, user };
}

async function loginUser({ email, password }) {
  if (!email || !password) {
    throw new Error('email dan password wajib diisi');
  }

  const { rows } = await query(
    `SELECT id, email, password_hash, full_name, weight_kg, height_cm, email_verified
     FROM users WHERE email = $1`,
    [email.toLowerCase()]
  );
  if (rows.length === 0) {
    throw new Error('Email atau password salah');
  }

  const user = rows[0];
  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    throw new Error('Email atau password salah');
  }

  delete user.password_hash;
  const tokens = await _issueTokenPair(user);
  return { ...tokens, user };
}

async function getUserById(userId) {
  const { rows } = await query(
    `SELECT id, email, full_name, weight_kg, height_cm, email_verified, created_at FROM users WHERE id = $1`,
    [userId]
  );
  return rows[0] || null;
}

// ---------------------------------------------------------------------------
// REFRESH TOKEN ROTATION
// ---------------------------------------------------------------------------

/**
 * Tukar refresh token lama dengan pasangan access+refresh token baru.
 * Melempar error jika token tidak ditemukan, kadaluarsa, atau (KRITIS)
 * sudah pernah dipakai sebelumnya — kasus terakhir men-trigger revoke
 * SELURUH refresh token user sebagai tindakan pengamanan.
 * @param {string} rawRefreshToken
 * @returns {Promise<{accessToken:string, refreshToken:string, user:object}>}
 */
async function rotateRefreshToken(rawRefreshToken) {
  if (!rawRefreshToken) throw new Error('refreshToken wajib diisi');
  const tokenHash = _sha256(rawRefreshToken);

  return withTransaction(async (client) => {
    const { rows } = await client.query(
      `SELECT rt.*, u.id AS u_id, u.email AS u_email, u.full_name, u.weight_kg, u.height_cm, u.email_verified
       FROM refresh_tokens rt
       JOIN users u ON u.id = rt.user_id
       WHERE rt.token_hash = $1`,
      [tokenHash]
    );

    if (rows.length === 0) {
      throw new Error('Refresh token tidak dikenali');
    }
    const record = rows[0];

    if (record.revoked_at) {
      // REUSE DETECTION: token ini sudah pernah dipakai/di-revoke sebelumnya.
      // Kemungkinan token dicuri. Kunci semua sesi user demi keamanan.
      await client.query(
        `UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`,
        [record.user_id]
      );
      throw new Error(
        'Refresh token yang sudah tidak berlaku terdeteksi dipakai ulang — semua sesi telah diamankan (logout paksa). Silakan login kembali.'
      );
    }

    if (new Date(record.expires_at).getTime() < Date.now()) {
      throw new Error('Refresh token sudah kadaluarsa — silakan login kembali');
    }

    const user = {
      id: record.u_id,
      email: record.u_email,
      full_name: record.full_name,
      weight_kg: record.weight_kg,
      height_cm: record.height_cm,
      email_verified: record.email_verified,
    };

    const newRawToken = _randomToken();
    const newTokenHash = _sha256(newRawToken);
    const newExpiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000);

    await client.query(
      `UPDATE refresh_tokens SET revoked_at = now(), replaced_by_hash = $1 WHERE id = $2`,
      [newTokenHash, record.id]
    );
    await client.query(
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1,$2,$3)`,
      [record.user_id, newTokenHash, newExpiresAt]
    );

    return { accessToken: generateAccessToken(user), refreshToken: newRawToken, user };
  });
}

/** Revoke satu refresh token (dipakai saat logout). */
async function revokeRefreshToken(rawRefreshToken) {
  if (!rawRefreshToken) return;
  const tokenHash = _sha256(rawRefreshToken);
  await query(`UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1 AND revoked_at IS NULL`, [tokenHash]);
}

/** Revoke SEMUA refresh token milik user (dipakai setelah reset password). */
async function revokeAllRefreshTokens(userId) {
  await query(`UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [userId]);
}

// ---------------------------------------------------------------------------
// VERIFIKASI EMAIL
// ---------------------------------------------------------------------------

async function verifyEmail(rawToken) {
  if (!rawToken) throw new Error('Token verifikasi wajib diisi');
  const tokenHash = _sha256(rawToken);

  const { rows } = await query(
    `SELECT id, email_verification_expires_at FROM users WHERE email_verification_token = $1`,
    [tokenHash]
  );
  if (rows.length === 0) {
    throw new Error('Token verifikasi tidak valid');
  }
  const user = rows[0];
  if (new Date(user.email_verification_expires_at).getTime() < Date.now()) {
    throw new Error('Token verifikasi sudah kadaluarsa — minta kirim ulang');
  }

  await query(
    `UPDATE users SET email_verified = true, email_verification_token = NULL, email_verification_expires_at = NULL
     WHERE id = $1`,
    [user.id]
  );
}

async function resendVerificationEmail(userId) {
  const { rows } = await query(`SELECT email, email_verified FROM users WHERE id = $1`, [userId]);
  if (rows.length === 0) throw new Error('User tidak ditemukan');
  if (rows[0].email_verified) throw new Error('Email sudah terverifikasi');

  const verificationToken = _randomToken(24);
  const verificationTokenHash = _sha256(verificationToken);
  const verificationExpiresAt = new Date(Date.now() + EMAIL_VERIFICATION_TTL_HOURS * 60 * 60 * 1000);

  await query(
    `UPDATE users SET email_verification_token = $1, email_verification_expires_at = $2 WHERE id = $3`,
    [verificationTokenHash, verificationExpiresAt, userId]
  );
  await emailService.sendVerificationEmail(rows[0].email, verificationToken);
}

// ---------------------------------------------------------------------------
// FORGOT / RESET PASSWORD
// ---------------------------------------------------------------------------

/**
 * SENGAJA tidak melempar error/membedakan respons untuk email yang tidak
 * terdaftar — mencegah enumerasi email lewat pesan error yang berbeda-beda.
 */
async function requestPasswordReset(email) {
  if (!email) return;
  const { rows } = await query(`SELECT id FROM users WHERE email = $1`, [email.toLowerCase()]);
  if (rows.length === 0) return; // diam-diam tidak melakukan apa-apa

  const resetToken = _randomToken(24);
  const resetTokenHash = _sha256(resetToken);
  const resetExpiresAt = new Date(Date.now() + PASSWORD_RESET_TTL_HOURS * 60 * 60 * 1000);

  await query(
    `UPDATE users SET password_reset_token = $1, password_reset_expires_at = $2 WHERE id = $3`,
    [resetTokenHash, resetExpiresAt, rows[0].id]
  );
  await emailService.sendPasswordResetEmail(email.toLowerCase(), resetToken);
}

async function resetPassword(rawToken, newPassword) {
  if (!rawToken || !newPassword) throw new Error('token dan newPassword wajib diisi');
  if (newPassword.length < 8) throw new Error('Password minimal 8 karakter');

  const tokenHash = _sha256(rawToken);
  const { rows } = await query(
    `SELECT id, password_reset_expires_at FROM users WHERE password_reset_token = $1`,
    [tokenHash]
  );
  if (rows.length === 0) throw new Error('Token reset password tidak valid');

  const user = rows[0];
  if (new Date(user.password_reset_expires_at).getTime() < Date.now()) {
    throw new Error('Token reset password sudah kadaluarsa — minta ulang');
  }

  const passwordHash = await bcrypt.hash(newPassword, BCRYPT_SALT_ROUNDS);
  await query(
    `UPDATE users SET password_hash = $1, password_reset_token = NULL, password_reset_expires_at = NULL WHERE id = $2`,
    [passwordHash, user.id]
  );

  // Reset password = anggap kredensial lama berpotensi bocor -> logout paksa semua sesi.
  await revokeAllRefreshTokens(user.id);
}

module.exports = {
  generateAccessToken,
  verifyAccessToken,
  registerUser,
  loginUser,
  getUserById,
  rotateRefreshToken,
  revokeRefreshToken,
  revokeAllRefreshTokens,
  verifyEmail,
  resendVerificationEmail,
  requestPasswordReset,
  resetPassword,
};
