'use strict';

/**
 * src/services/geminiCoachService.js
 * -----------------------------------------------------------------------
 * Integrasi Gemini 3.6 Flash via SDK resmi `@google/genai`, dikunci ke
 * persona "Pelatih Elit Tegas — Anti-Ego Running".
 *
 * PRINSIP DESAIN (konsisten dengan Fase 0/1):
 *   Gemini TIDAK PERNAH menjadi satu-satunya penentu keputusan yang
 *   berdampak keselamatan/beban latihan (mis. apakah Ego Running terjadi,
 *   apakah sesi besok harus dibatalkan). Keputusan itu dihitung secara
 *   DETERMINISTIK di JavaScript murni terlebih dahulu (lihat
 *   `_computeAuditFacts`), lalu dikirim ke Gemini sebagai FAKTA YANG SUDAH
 *   FINAL. Gemini hanya diminta menghasilkan narasi/analisis kualitatif di
 *   atas fakta tersebut. Setelah respons Gemini diterima, field
 *   keselamatan-kritis (ego_running_detected, cancel_tomorrow_interval,
 *   delta_pace_sec_km, delta_hr_bpm) di-OVERRIDE ulang dengan nilai
 *   deterministik kita — pola "trust but verify" — sehingga LLM tidak
 *   bisa "melunakkan" keputusan lewat variasi generasi teks.
 * -----------------------------------------------------------------------
 */

const { GoogleGenAI } = require('@google/genai');

const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.6-flash';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

let _client = null;
function _getClient() {
  if (!GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY belum diset di environment variables');
  }
  if (!_client) {
    _client = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
  }
  return _client;
}

// ---------------------------------------------------------------------------
// PERSONA — SYSTEM INSTRUCTION
// ---------------------------------------------------------------------------

const STRICT_COACH_SYSTEM_INSTRUCTION = `
Anda adalah "APEX" — AI Running Coach elit bersertifikasi sports science, dengan
kepribadian TEGAS, ANALITIS, TANPA KOMPROMI ("tough love"). Anda melatih atlet
yang serius mengejar performa, bukan mencari validasi emosional.

ATURAN MUTLAK — TIDAK BOLEH DILANGGAR:
1. ANTI-EGO-RUNNING: Easy Run yang dilakukan terlalu cepat/HR terlalu tinggi
   BUKAN prestasi — itu pelanggaran prinsip polarized training yang merusak
   adaptasi aerobik dan mengganggu supercompensation sesi kualitas berikutnya.
   Jika data menunjukkan pola ini, Anda WAJIB menegur dengan tegas dan
   menyebut secara eksplisit bahwa ini "Junk Miles" — jarak yang dibakar
   tanpa manfaat latihan yang proporsional dengan risikonya.
2. Anda SELALU merujuk pada angka yang diberikan dalam konteks (delta pace,
   delta HR, TSB, VDOT). Jangan pernah membuat klaim numerik yang tidak ada
   di data yang diberikan.
3. Anda TIDAK PERNAH melunakkan penilaian karena atlet "sudah berusaha keras".
   Usaha yang salah arah tetap salah arah, sekeras apa pun usahanya.
4. Ketika HR tinggi tapi pace lambat, Anda menganalisis SECARA SPESIFIK dari
   empat kemungkinan penyebab yang diberikan — jangan menjawab generik
   "kurang fit". Setiap penyebab dinilai likelihood-nya berdasarkan data yang
   tersedia (jangan mengarang data yang tidak diberikan).
5. Anda TIDAK PERNAH memberi diagnosis medis definitif. Untuk kondisi yang
   berpotensi serius, arahkan ke evaluasi profesional.
6. Bahasa: Indonesia, tegas, padat, tidak bertele-tele.
7. OUTPUT ANDA HARUS 100% VALID JSON sesuai skema yang diberikan di prompt —
   tidak ada teks di luar struktur JSON, tidak ada markdown code fence.
`.trim();

// ---------------------------------------------------------------------------
// JSON SCHEMA CONTRACT — generateDailyPrescription
// (dipakai sebagai responseSchema Gemini DAN disalin sebagai teks penuh
//  di dalam prompt, agar konsistensi output 100% terjamin dari dua arah)
// ---------------------------------------------------------------------------

const DAILY_PRESCRIPTION_SCHEMA = {
  type: 'OBJECT',
  properties: {
    session_date: { type: 'STRING', description: 'Format YYYY-MM-DD' },
    session_type: {
      type: 'STRING',
      enum: ['EASY', 'INTERVAL', 'TEMPO', 'LONG_RUN', 'GYM', 'REST', 'RACE'],
    },
    weather_adjusted: { type: 'BOOLEAN' },
    warmup: {
      type: 'OBJECT',
      properties: {
        duration_minutes: { type: 'NUMBER' },
        description: { type: 'STRING' },
        drills: { type: 'ARRAY', items: { type: 'STRING' } },
      },
      required: ['duration_minutes', 'description', 'drills'],
    },
    running_drills: {
      type: 'ARRAY',
      description: 'Drill lari teknik: A-Skip, B-Skip, Bounds, Strides, dsb.',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' },
          sets: { type: 'NUMBER' },
          distance_m: { type: 'NUMBER' },
          notes: { type: 'STRING' },
        },
        required: ['name', 'sets', 'distance_m', 'notes'],
      },
    },
    main_run: {
      type: 'OBJECT',
      properties: {
        description: { type: 'STRING' },
        target_distance_km: { type: 'NUMBER' },
        target_duration_minutes: { type: 'NUMBER' },
        target_pace_min_sec_km: { type: 'STRING', description: 'format M:SS, batas TERCEPAT' },
        target_pace_max_sec_km: { type: 'STRING', description: 'format M:SS, batas TERLAMBAT' },
        target_hr_min: { type: 'NUMBER' },
        target_hr_max: { type: 'NUMBER' },
        structure: {
          type: 'ARRAY',
          description: 'Segmentasi sesi (khusus interval/tempo); array kosong untuk easy/long run polos',
          items: {
            type: 'OBJECT',
            properties: {
              segment: { type: 'STRING' },
              duration_minutes: { type: 'NUMBER' },
              distance_km: { type: 'NUMBER' },
              target_pace: { type: 'STRING' },
              target_hr: { type: 'NUMBER' },
              recovery_minutes: { type: 'NUMBER' },
            },
            required: ['segment', 'duration_minutes', 'distance_km', 'target_pace', 'target_hr', 'recovery_minutes'],
          },
        },
      },
      required: [
        'description', 'target_distance_km', 'target_duration_minutes',
        'target_pace_min_sec_km', 'target_pace_max_sec_km',
        'target_hr_min', 'target_hr_max', 'structure',
      ],
    },
    gym_strength: {
      type: 'OBJECT',
      properties: {
        required: { type: 'BOOLEAN' },
        sequence_after_run: { type: 'BOOLEAN', description: 'WAJIB true jika session_type INTERVAL/TEMPO' },
        exercises: {
          type: 'ARRAY',
          description: 'Contoh: RDL, Leg Press, Lat Pulldown, Calf Raises',
          items: {
            type: 'OBJECT',
            properties: {
              name: { type: 'STRING' },
              sets: { type: 'NUMBER' },
              reps: { type: 'NUMBER' },
              load_guidance: { type: 'STRING' },
              rpe: { type: 'NUMBER' },
            },
            required: ['name', 'sets', 'reps', 'load_guidance', 'rpe'],
          },
        },
      },
      required: ['required', 'sequence_after_run', 'exercises'],
    },
    cooldown: {
      type: 'OBJECT',
      properties: {
        duration_minutes: { type: 'NUMBER' },
        description: { type: 'STRING' },
      },
      required: ['duration_minutes', 'description'],
    },
    nutrition: {
      type: 'OBJECT',
      properties: {
        pre_workout: { type: 'STRING' },
        during_workout: { type: 'STRING' },
        post_workout: { type: 'STRING' },
        hydration_notes: { type: 'STRING' },
      },
      required: ['pre_workout', 'during_workout', 'post_workout', 'hydration_notes'],
    },
    coach_notes: { type: 'STRING' },
  },
  required: [
    'session_date', 'session_type', 'weather_adjusted', 'warmup', 'running_drills',
    'main_run', 'gym_strength', 'cooldown', 'nutrition', 'coach_notes',
  ],
};

// ---------------------------------------------------------------------------
// JSON SCHEMA CONTRACT — auditExecutedRun (bagian yang DIISI GEMINI)
// Field numerik/boolean keselamatan-kritis (delta_pace_sec_km, delta_hr_bpm,
// ego_running_detected, cancel_tomorrow_interval) TETAP diminta dari Gemini
// agar output selalu satu objek JSON utuh sesuai kontrak, TAPI nilainya
// di-override deterministik setelah parsing (lihat auditExecutedRun()).
// ---------------------------------------------------------------------------

const AUDIT_RESPONSE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    audit_summary: { type: 'STRING' },
    delta_pace_sec_km: { type: 'NUMBER', description: 'aktual - resep, negatif berarti lebih cepat dari resep' },
    delta_hr_bpm: { type: 'NUMBER', description: 'aktual - resep' },
    verdict: {
      type: 'STRING',
      enum: ['COMPLIANT', 'EGO_RUNNING_JUNK_MILES', 'UNDERPERFORMED', 'HIGH_HR_LOW_PACE_INVESTIGATE', 'OTHER'],
    },
    ego_running_detected: { type: 'BOOLEAN' },
    reprimand_message: {
      type: 'STRING',
      description: 'Teguran tegas profesional jika ego_running_detected true; string kosong jika tidak berlaku',
    },
    high_hr_low_pace_analysis: {
      type: 'OBJECT',
      properties: {
        applicable: { type: 'BOOLEAN' },
        probable_causes: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              cause: {
                type: 'STRING',
                enum: ['CADENCE_VERTICAL_OSCILLATION', 'AEROBIC_DECOUPLING', 'CNS_FATIGUE', 'DEHYDRATION'],
              },
              likelihood: { type: 'STRING', enum: ['LOW', 'MEDIUM', 'HIGH'] },
              reasoning: { type: 'STRING' },
              recommended_action: { type: 'STRING' },
            },
            required: ['cause', 'likelihood', 'reasoning', 'recommended_action'],
          },
        },
      },
      required: ['applicable', 'probable_causes'],
    },
    cancel_tomorrow_interval: { type: 'BOOLEAN' },
    schedule_adjustment_reason: { type: 'STRING' },
  },
  required: [
    'audit_summary', 'delta_pace_sec_km', 'delta_hr_bpm', 'verdict',
    'ego_running_detected', 'reprimand_message', 'high_hr_low_pace_analysis',
    'cancel_tomorrow_interval', 'schedule_adjustment_reason',
  ],
};

// ---------------------------------------------------------------------------
// TOLERANSI DETERMINISTIK (sama filosofinya dengan guardrail Fase 0)
// ---------------------------------------------------------------------------

const EGO_RUNNING_PACE_TOLERANCE_SEC = 8;   // toleransi 8 detik/km lebih cepat dari batas easy
const EGO_RUNNING_HR_TOLERANCE_BPM = 4;     // toleransi 4 bpm di atas batas HR easy
const HIGH_HR_LOW_PACE_HR_THRESHOLD_BPM = 5;    // HR aktual melebihi target sebesar ini
const HIGH_HR_LOW_PACE_PACE_THRESHOLD_SEC = 10; // pace aktual LEBIH LAMBAT dari target sebesar ini (detik/km)

/** Parse string pace "M:SS" menjadi total detik. */
function _parsePaceToSec(paceStr) {
  const [m, s] = String(paceStr).split(':').map(Number);
  if (Number.isNaN(m) || Number.isNaN(s)) {
    throw new Error(`Format pace tidak valid: ${paceStr}`);
  }
  return m * 60 + s;
}

/**
 * Hitung fakta audit secara DETERMINISTIK (tanpa LLM) dari prescription vs
 * executionData. Ini adalah satu-satunya sumber kebenaran untuk keputusan
 * yang berdampak beban latihan.
 *
 * @param {object} prescription objek hasil generateDailyPrescription (atau subset: main_run)
 * @param {object} executionData { avgPaceSecKm, avgHR, distanceKm, durationMinutes }
 */
function _computeAuditFacts(prescription, executionData) {
  const mainRun = prescription.main_run;
  const isEasySession = prescription.session_type === 'EASY';

  // Untuk sesi easy, "resep" pace pembanding adalah batas TERCEPAT yang diizinkan
  // (target_pace_min_sec_km, secara semantik = batas kecepatan tercepat easy zone).
  const prescribedPaceSec = _parsePaceToSec(mainRun.target_pace_min_sec_km);
  const prescribedHR = mainRun.target_hr_max;

  const deltaPaceSecKm = round(executionData.avgPaceSecKm - prescribedPaceSec, 1);
  const deltaHrBpm = round(executionData.avgHR - prescribedHR, 1);

  // PENTING: Ego Running dan High-HR-Low-Pace adalah DUA FENOMENA FISIOLOGIS
  // BERLAWANAN dan harus saling eksklusif:
  //   - Ego Running   = usaha BERLEBIH yang DISENGAJA -> pace LEBIH CEPAT dari
  //                      batas (dan/atau HR naik SAAT pace juga cepat/setara).
  //   - High-HR-Low-Pace = usaha kardiovaskular TINGGI tapi OUTPUT pace RENDAH
  //                      (lebih lambat) -> indikasi fatigue/dehidrasi/decoupling,
  //                      BUKAN pelanggaran disiplin. Mensyaratkan pace jelas
  //                      lebih lambat, bukan lebih cepat.
  const paceTooFast = deltaPaceSecKm < -EGO_RUNNING_PACE_TOLERANCE_SEC;
  const hrTooHighWhilePaceFastOrEven = deltaHrBpm > EGO_RUNNING_HR_TOLERANCE_BPM && deltaPaceSecKm <= 0;

  let egoRunningDetected = false;
  if (isEasySession) {
    egoRunningDetected = paceTooFast || hrTooHighWhilePaceFastOrEven;
  }

  const highHrLowPaceCase =
    !egoRunningDetected &&
    deltaHrBpm > HIGH_HR_LOW_PACE_HR_THRESHOLD_BPM &&
    deltaPaceSecKm > HIGH_HR_LOW_PACE_PACE_THRESHOLD_SEC;

  const cancelTomorrowInterval = egoRunningDetected;

  // UNDERPERFORMED hanya relevan untuk sesi KUALITAS (interval/tempo/long run)
  // yang gagal mencapai pace target. Untuk sesi EASY, pace lebih lambat dari
  // batas tercepat justru NORMAL/DIHARAPKAN — bukan kegagalan.
  const isQualitySession = ['INTERVAL', 'TEMPO', 'LONG_RUN'].includes(prescription.session_type);

  let verdict;
  if (egoRunningDetected) verdict = 'EGO_RUNNING_JUNK_MILES';
  else if (highHrLowPaceCase) verdict = 'HIGH_HR_LOW_PACE_INVESTIGATE';
  else if (isQualitySession && deltaPaceSecKm > HIGH_HR_LOW_PACE_PACE_THRESHOLD_SEC) verdict = 'UNDERPERFORMED';
  else verdict = 'COMPLIANT';

  return {
    deltaPaceSecKm,
    deltaHrBpm,
    egoRunningDetected,
    highHrLowPaceCase,
    cancelTomorrowInterval,
    verdict,
    prescribedPaceSec,
    prescribedHR,
  };
}

function round(v, d = 2) {
  const f = 10 ** d;
  return Math.round(v * f) / f;
}

// ---------------------------------------------------------------------------
// PEMANGGILAN GEMINI GENERIK
// ---------------------------------------------------------------------------

async function _callGemini({ promptText, responseSchema, temperature = 0.4 }) {
  const client = _getClient();
  const response = await client.models.generateContent({
    model: GEMINI_MODEL,
    contents: [{ role: 'user', parts: [{ text: promptText }] }],
    config: {
      systemInstruction: STRICT_COACH_SYSTEM_INSTRUCTION,
      responseMimeType: 'application/json',
      responseSchema,
      temperature,
      maxOutputTokens: 2048,
    },
  });

  const rawText = response.text;
  if (!rawText) {
    throw new Error('Gemini tidak mengembalikan konten teks yang valid');
  }

  try {
    return JSON.parse(rawText);
  } catch (err) {
    throw new Error(`Gagal parse JSON dari Gemini: ${err.message}\nRaw: ${rawText.slice(0, 500)}`);
  }
}

// ---------------------------------------------------------------------------
// 1. generateDailyPrescription
// ---------------------------------------------------------------------------

/**
 * Hasilkan resep latihan harian lengkap dalam format JSON terstruktur.
 * @param {object} athleteData { fullName, weightKg, heightCm, maxHr, lthr, restingHr, vdot }
 * @param {object} availability { dayOfWeek, activityPreference, maxDurationMinutes, equipmentType }
 * @param {object} tsb { value, ctl, atl } — Training Stress Balance terkini
 * @param {object} weatherData { tempC, humidityPct } | null
 * @returns {Promise<object>} objek sesuai DAILY_PRESCRIPTION_SCHEMA
 */
async function generateDailyPrescription(athleteData, availability, tsb, weatherData) {
  const promptText = `
Anda akan membuat RESEP LATIHAN HARIAN untuk atlet berikut. Ikuti persona dan
aturan mutlak pada system instruction.

=== KONTRAK SKEMA JSON OUTPUT (WAJIB DIIKUTI PERSIS) ===
${JSON.stringify(DAILY_PRESCRIPTION_SCHEMA, null, 2)}

=== DATA ATLET ===
${JSON.stringify(athleteData, null, 2)}

=== KETERSEDIAAN HARI INI ===
${JSON.stringify(availability, null, 2)}

=== TRAINING STRESS BALANCE (FORM) SAAT INI ===
${JSON.stringify(tsb, null, 2)}
Panduan interpretasi TSB: < -30 = overreaching berat (turunkan intensitas
drastis atau REST); -30 s/d -10 = fatigue terkontrol (masih boleh kualitas
dengan hati-hati); -10 s/d +5 = zona produktif optimal; > +5 = segar (siap
sesi berat/race).

=== CUACA ===
${weatherData ? JSON.stringify(weatherData, null, 2) : 'Tidak ada data cuaca — asumsikan kondisi normal.'}
Jika tempC > 30, target pace WAJIB dilonggarkan +10 detik/km (atau +15 jika
>= 35°C) dan target HR max dinaikkan +5 bpm dibanding kondisi normal, dan set
weather_adjusted=true.

=== INSTRUKSI ===
Berdasarkan availability.activityPreference, tentukan session_type yang sesuai.
Jika session_type adalah INTERVAL atau TEMPO, gym_strength.required HARUS true
dan gym_strength.sequence_after_run HARUS true, dengan exercises mencakup
kombinasi dari: RDL, Leg Press, Lat Pulldown, Calf Raises (pilih yang sesuai
equipmentType yang tersedia). Jika session_type EASY/LONG_RUN/REST,
gym_strength.required boleh false dengan exercises array kosong.
running_drills WAJIB diisi untuk sesi EASY/INTERVAL/TEMPO (mis. A-Skip,
B-Skip/Bounds, Strides) sebagai bagian dari warmup dinamis — array kosong
hanya untuk REST atau LONG_RUN murni.

Keluarkan HANYA objek JSON sesuai kontrak skema di atas. Tidak ada teks lain.
`.trim();

  return _callGemini({ promptText, responseSchema: DAILY_PRESCRIPTION_SCHEMA, temperature: 0.5 });
}

// ---------------------------------------------------------------------------
// 2. auditExecutedRun
// ---------------------------------------------------------------------------

/**
 * Audit hasil lari aktual terhadap resep, deteksi Ego Running / High-HR-Low-
 * Pace, dan hasilkan narasi tegas dari Gemini di atas fakta yang sudah
 * dihitung deterministik.
 *
 * @param {object} prescription objek hasil generateDailyPrescription sebelumnya
 * @param {object} executionData { avgPaceSecKm, avgHR, distanceKm, durationMinutes, cadenceSpm, verticalOscillationCm, hydrationLitersConsumed }
 * @returns {Promise<object>} objek sesuai AUDIT_RESPONSE_SCHEMA, dengan field
 *          keselamatan-kritis TER-OVERRIDE deterministik
 */
async function auditExecutedRun(prescription, executionData) {
  const facts = _computeAuditFacts(prescription, executionData);

  const promptText = `
Anda akan mengaudit sebuah lari yang SUDAH SELESAI DIEKSEKUSI dibandingkan
resepnya. FAKTA NUMERIK BERIKUT SUDAH FINAL DAN TIDAK BOLEH DIUBAH — gunakan
PERSIS angka ini di field delta_pace_sec_km, delta_hr_bpm, ego_running_detected,
cancel_tomorrow_interval, dan verdict pada output Anda:

=== FAKTA TERHITUNG (DETERMINISTIK, JANGAN DIUBAH) ===
${JSON.stringify(
  {
    delta_pace_sec_km: facts.deltaPaceSecKm,
    delta_hr_bpm: facts.deltaHrBpm,
    ego_running_detected: facts.egoRunningDetected,
    high_hr_low_pace_case: facts.highHrLowPaceCase,
    cancel_tomorrow_interval: facts.cancelTomorrowInterval,
    verdict: facts.verdict,
  },
  null,
  2
)}

=== KONTRAK SKEMA JSON OUTPUT (WAJIB DIIKUTI PERSIS) ===
${JSON.stringify(AUDIT_RESPONSE_SCHEMA, null, 2)}

=== RESEP ASLI (main_run) ===
${JSON.stringify(prescription.main_run, null, 2)}
session_type resep: ${prescription.session_type}

=== DATA EKSEKUSI AKTUAL ===
${JSON.stringify(executionData, null, 2)}

=== INSTRUKSI PENULISAN NARASI ===
1. Isi audit_summary: ringkasan 2-3 kalimat tegas tentang kepatuhan sesi ini.
2. Jika ego_running_detected=true: tulis reprimand_message berupa teguran
   KERAS dan PROFESIONAL, WAJIB menyebut istilah "Junk Miles" secara eksplisit,
   dan jelaskan konsekuensi fisiologisnya (gangguan adaptasi aerobik, interferensi
   supercompensation sesi kualitas). Jika ego_running_detected=false, isi
   reprimand_message dengan string kosong "".
3. Jika high_hr_low_pace_case=true: isi high_hr_low_pace_analysis.applicable=true
   dan evaluasi KEEMPAT penyebab berikut dengan likelihood spesifik berdasarkan
   data yang tersedia (cadenceSpm, verticalOscillationCm, hydrationLitersConsumed,
   dan pola durasi/jarak jika relevan) — JANGAN mengarang data yang tidak diberikan,
   nyatakan "data tidak cukup untuk menilai" jika memang tidak tersedia:
   - CADENCE_VERTICAL_OSCILLATION: efisiensi biomekanik lari menurun
   - AEROBIC_DECOUPLING: base aerobik belum cukup kuat untuk durasi/intensitas ini
   - CNS_FATIGUE: kelelahan sistem saraf pusat dari akumulasi training load
   - DEHYDRATION: asupan cairan tidak memadai untuk kondisi/durasi sesi
   Jika high_hr_low_pace_case=false, set applicable=false dan probable_causes=[].
4. Isi schedule_adjustment_reason dengan alasan singkat MENGAPA
   cancel_tomorrow_interval bernilai seperti yang diberikan di fakta di atas.

Keluarkan HANYA objek JSON sesuai kontrak skema di atas. Tidak ada teks lain.
`.trim();

  const geminiResult = await _callGemini({ promptText, responseSchema: AUDIT_RESPONSE_SCHEMA, temperature: 0.4 });

  // "Trust but verify": override field keselamatan-kritis dengan fakta deterministik,
  // apa pun yang dihasilkan Gemini. Field narasi (summary, reprimand, analysis
  // kualitatif) tetap dari Gemini.
  const finalResult = {
    ...geminiResult,
    delta_pace_sec_km: facts.deltaPaceSecKm,
    delta_hr_bpm: facts.deltaHrBpm,
    verdict: facts.verdict,
    ego_running_detected: facts.egoRunningDetected,
    cancel_tomorrow_interval: facts.cancelTomorrowInterval,
    reprimand_message: facts.egoRunningDetected ? (geminiResult.reprimand_message || _fallbackReprimand()) : '',
  };

  if (
    geminiResult.ego_running_detected !== facts.egoRunningDetected ||
    geminiResult.cancel_tomorrow_interval !== facts.cancelTomorrowInterval
  ) {
    console.warn(
      '[geminiCoachService] Peringatan: field keselamatan-kritis dari Gemini berbeda dari fakta ' +
      'deterministik — nilai deterministik dipakai. Gemini output:',
      { ego: geminiResult.ego_running_detected, cancel: geminiResult.cancel_tomorrow_interval }
    );
  }

  return finalResult;
}

function _fallbackReprimand() {
  return (
    '🚨 EGO RUNNING TERDETEKSI — JUNK MILES. Anda berlari melampaui batas Easy Zone yang ' +
    'ditetapkan. Ini bukan pencapaian — ini gangguan langsung terhadap adaptasi aerobik dan ' +
    'akan mengurangi kualitas sesi interval/tempo berikutnya. Jadwal besok direvisi otomatis.'
  );
}

// ---------------------------------------------------------------------------
// 3. chatWithCoach — konsultasi bebas untuk FloatingCoachDrawer (Fase 4)
// ---------------------------------------------------------------------------

/**
 * Balasan percakapan bebas (bukan JSON terstruktur) untuk widget chat.
 * Tetap dikunci ke persona APEX via system instruction yang sama, dan
 * tetap diberi konteks data atlet supaya jawabannya berbasis fakta,
 * tapi TIDAK memakai responseSchema karena output di sini adalah
 * kalimat percakapan bebas, bukan kontrak API terstruktur.
 *
 * @param {object} contextData ringkasan kondisi atlet saat ini (TSB, VDOT,
 *        resep hari ini, dsb.) — dikumpulkan controller dari database.
 * @param {string} userMessage pesan dari user
 * @returns {Promise<string>} balasan teks dari Gemini
 */
async function chatWithCoach(contextData, userMessage) {
  const client = _getClient();

  const promptText = `
KONTEKS DATA ATLET SAAT INI (JSON, satu-satunya sumber kebenaran numerik):
${JSON.stringify(contextData, null, 2)}

PESAN ATLET:
${userMessage}

Balas sebagai APEX, singkat (maksimal 4-6 kalimat kecuali diminta detail),
tegas, dan berbasis data di atas. Jangan mengarang angka yang tidak ada
di konteks. Jika pertanyaan meminta penambahan volume/intensitas di luar
rencana, tolak dengan tegas dan jelaskan risikonya sesuai aturan mutlak
pada persona Anda.
`.trim();

  const response = await client.models.generateContent({
    model: GEMINI_MODEL,
    contents: [{ role: 'user', parts: [{ text: promptText }] }],
    config: {
      systemInstruction: STRICT_COACH_SYSTEM_INSTRUCTION,
      temperature: 0.6,
      maxOutputTokens: 500,
    },
  });

  const rawText = response.text;
  if (!rawText) {
    throw new Error('Gemini tidak mengembalikan konten teks yang valid untuk chat');
  }
  return rawText.trim();
}

module.exports = {
  GEMINI_MODEL,
  STRICT_COACH_SYSTEM_INSTRUCTION,
  DAILY_PRESCRIPTION_SCHEMA,
  AUDIT_RESPONSE_SCHEMA,
  generateDailyPrescription,
  auditExecutedRun,
  chatWithCoach,
  // diekspos untuk unit testing logika deterministik tanpa memanggil Gemini
  _computeAuditFacts,
};
