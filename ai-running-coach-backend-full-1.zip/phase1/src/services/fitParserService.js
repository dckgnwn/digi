'use strict';

/**
 * src/services/fitParserService.js
 * -----------------------------------------------------------------------
 * Parser file .FIT (binary) memakai SDK resmi Garmin `@garmin/fitsdk`.
 *
 * CATATAN KONVENSI CADENCE:
 * Field `cadence` pada FIT Record message untuk aktivitas lari umumnya
 * direkam sebagai rpm SATU KAKI (jumlah langkah satu kaki per menit), bukan
 * total steps per minute (SPM) kedua kaki. Konvensi industri (Garmin
 * Connect, Strava, dsb.) mengalikan nilai ini dengan 2 untuk mendapatkan
 * SPM total yang biasa ditampilkan ke pelari. Modul ini mengikuti konvensi
 * tersebut PERSIS sesuai permintaan produk.
 * -----------------------------------------------------------------------
 */

const { Decoder, Stream } = require('@garmin/fitsdk');

// ---------------------------------------------------------------------------
// UTILITAS INTERNAL
// ---------------------------------------------------------------------------

function _round(v, d = 2) {
  const f = 10 ** d;
  return Math.round(v * f) / f;
}

function _average(values) {
  const valid = values.filter((v) => typeof v === 'number' && isFinite(v));
  if (valid.length === 0) return null;
  return valid.reduce((s, v) => s + v, 0) / valid.length;
}

/** Konversi kecepatan (m/s) menjadi pace (detik/km). Null jika speed<=0. */
function _speedToPaceSecKm(speedMps) {
  if (!speedMps || speedMps <= 0) return null;
  return Math.round(1000 / speedMps);
}

/** Konversi FIT semicircles -> derajat desimal (unit posisi GPS asli FIT SDK). */
function _semicirclesToDegrees(semicircles) {
  return semicircles * (180 / 2 ** 31);
}

// ---------------------------------------------------------------------------
// CARDIAC DRIFT / PACE:HR DECOUPLING — dipakai ulang oleh stravaService.js
// untuk telemetri dari Strava Streams API (bukan hanya dari file .FIT)
// ---------------------------------------------------------------------------

/**
 * Hitung Cardiac Drift % dari array telemetri generik.
 * @param {Array<{t:number, heart_rate:number|null, speed_mps:number|null}>} records
 * @returns {{decouplingPct:number, avgHRFirstHalf:number, avgHRSecondHalf:number, avgSpeedFirstHalf:number, avgSpeedSecondHalf:number}}
 */
function calculateCardiacDriftFromTelemetry(records) {
  const validRecords = records.filter(
    (r) => typeof r.heart_rate === 'number' && r.heart_rate > 0 && typeof r.speed_mps === 'number' && r.speed_mps > 0
  );

  if (validRecords.length < 20) {
    throw new Error('Butuh minimal ~20 sampel telemetri valid (HR & speed) untuk menghitung cardiac drift');
  }

  const midpointTime = validRecords[validRecords.length - 1].t / 2;
  const firstHalf = validRecords.filter((r) => r.t <= midpointTime);
  const secondHalf = validRecords.filter((r) => r.t > midpointTime);

  if (firstHalf.length === 0 || secondHalf.length === 0) {
    throw new Error('Tidak cukup data pada salah satu paruh sesi untuk menghitung cardiac drift');
  }

  const avgHR1 = _average(firstHalf.map((r) => r.heart_rate));
  const avgHR2 = _average(secondHalf.map((r) => r.heart_rate));
  const avgSpeed1 = _average(firstHalf.map((r) => r.speed_mps));
  const avgSpeed2 = _average(secondHalf.map((r) => r.speed_mps));

  const ratio1 = avgSpeed1 / avgHR1; // efisiensi aerobik (speed/HR) paruh pertama
  const ratio2 = avgSpeed2 / avgHR2; // efisiensi aerobik paruh kedua

  const decouplingPct = ((ratio1 - ratio2) / ratio1) * 100;

  return {
    decouplingPct: _round(decouplingPct, 2),
    avgHRFirstHalf: Math.round(avgHR1),
    avgHRSecondHalf: Math.round(avgHR2),
    avgSpeedFirstHalf: _round(avgSpeed1, 3),
    avgSpeedSecondHalf: _round(avgSpeed2, 3),
  };
}

// ---------------------------------------------------------------------------
// parseFitBuffer
// ---------------------------------------------------------------------------

/**
 * Parse buffer biner .FIT menjadi summary sesi + array telemetri 1Hz.
 * @param {Buffer} buffer isi file .FIT mentah
 * @returns {{
 *   summary: object,
 *   telemetry1Hz: Array<object>,
 *   parseWarnings: Array<object>
 * }}
 */
function parseFitBuffer(buffer) {
  if (!Buffer.isBuffer(buffer)) {
    throw new Error('parseFitBuffer membutuhkan input bertipe Buffer');
  }

  const stream = Stream.fromBuffer(buffer);

  if (!Decoder.isFIT(stream)) {
    throw new Error('File yang diunggah bukan file .FIT yang valid (magic header tidak cocok)');
  }

  const decoder = new Decoder(stream);
  if (!decoder.checkIntegrity()) {
    throw new Error('File .FIT gagal validasi integritas (CRC tidak cocok) — file mungkin korup');
  }

  const { messages, errors } = decoder.read();
  const parseWarnings = (errors || []).map((e) => ({ message: e.message || String(e) }));

  const recordMesgs = (messages && messages.recordMesgs) || [];
  if (recordMesgs.length === 0) {
    throw new Error('Tidak ada Record message (data 1Hz) ditemukan di dalam file .FIT ini');
  }

  const sessionMesgs = (messages && messages.sessionMesgs) || [];
  const firstTimestampMs = new Date(recordMesgs[0].timestamp).getTime();

  const telemetry1Hz = recordMesgs.map((r) => {
    const tSec = Math.round((new Date(r.timestamp).getTime() - firstTimestampMs) / 1000);
    const speedMps = typeof r.speed === 'number' ? r.speed : (typeof r.enhancedSpeed === 'number' ? r.enhancedSpeed : null);
    return {
      t: tSec,
      heart_rate: typeof r.heartRate === 'number' ? r.heartRate : null,
      speed_mps: speedMps,
      pace_sec_km: _speedToPaceSecKm(speedMps),
      cadence_spm: typeof r.cadence === 'number' ? r.cadence * 2 : null, // konversi rpm satu-kaki -> SPM total
      altitude_m: typeof r.altitude === 'number' ? r.altitude : (typeof r.enhancedAltitude === 'number' ? r.enhancedAltitude : null),
      power_w: typeof r.power === 'number' ? r.power : null,
      distance_m: typeof r.distance === 'number' ? r.distance : null,
      lat: typeof r.positionLat === 'number' ? _semicirclesToDegrees(r.positionLat) : null,
      lng: typeof r.positionLong === 'number' ? _semicirclesToDegrees(r.positionLong) : null,
    };
  });

  const avgHR = _average(telemetry1Hz.map((r) => r.heart_rate));
  const maxHR = telemetry1Hz.reduce((max, r) => (r.heart_rate != null && r.heart_rate > max ? r.heart_rate : max), 0);
  const avgSpeedMps = _average(telemetry1Hz.map((r) => r.speed_mps));
  const avgCadenceRawRpm = _average(recordMesgs.map((r) => (typeof r.cadence === 'number' ? r.cadence : null)));
  const avgPowerW = _average(telemetry1Hz.map((r) => r.power_w));

  const durationSec = telemetry1Hz[telemetry1Hz.length - 1].t;
  const lastDistance = telemetry1Hz.reduce((max, r) => (r.distance_m != null && r.distance_m > max ? r.distance_m : max), 0);

  // Fallback dari sessionMesgs jika tersedia (lebih akurat karena dihitung device,
  // bukan hasil integrasi ulang dari record 1Hz yang bisa punya gap GPS).
  const sessionSummary = sessionMesgs[0] || {};
  const totalDistanceMeters = typeof sessionSummary.totalDistance === 'number' ? sessionSummary.totalDistance : lastDistance;
  const totalDurationSec =
    typeof sessionSummary.totalTimerTime === 'number' ? Math.round(sessionSummary.totalTimerTime) : durationSec;

  let cardiacDrift = null;
  try {
    cardiacDrift = calculateCardiacDriftFromTelemetry(telemetry1Hz);
  } catch (err) {
    // Tidak fatal — sesi terlalu pendek atau data HR/speed tidak lengkap.
    parseWarnings.push({ message: `Cardiac drift tidak dapat dihitung: ${err.message}` });
  }

  // Titik GPS pertama yang valid — dipakai untuk lookup cuaca (weatherService).
  const firstGpsPoint = telemetry1Hz.find((r) => r.lat != null && r.lng != null) || null;

  const summary = {
    startTime: recordMesgs[0].timestamp instanceof Date ? recordMesgs[0].timestamp.toISOString() : String(recordMesgs[0].timestamp),
    durationSec: totalDurationSec,
    distanceMeters: _round(totalDistanceMeters, 1),
    avgHR: avgHR != null ? Math.round(avgHR) : null,
    maxHR: maxHR > 0 ? maxHR : null,
    avgSpeedMps: avgSpeedMps != null ? _round(avgSpeedMps, 3) : null,
    avgPaceSecKm: _speedToPaceSecKm(avgSpeedMps),
    avgCadenceSpm: avgCadenceRawRpm != null ? Math.round(avgCadenceRawRpm * 2) : null,
    avgPowerW: avgPowerW != null ? Math.round(avgPowerW) : null,
    cardiacDriftPct: cardiacDrift ? cardiacDrift.decouplingPct : null,
    cardiacDriftDetail: cardiacDrift,
    recordCount: recordMesgs.length,
    startLat: firstGpsPoint ? _round(firstGpsPoint.lat, 6) : null,
    startLng: firstGpsPoint ? _round(firstGpsPoint.lng, 6) : null,
  };

  return { summary, telemetry1Hz, parseWarnings };
}

module.exports = {
  parseFitBuffer,
  calculateCardiacDriftFromTelemetry,
};
