'use strict';

const { query, withTransaction } = require('../config/db');

const VALID_ACTIVITY_PREFS = new Set(['REST', 'EASY', 'INTERVAL', 'TEMPO', 'LONG_RUN', 'GYM']);
const VALID_EQUIPMENT = new Set(['FULL_GYM', 'HOME_DUMBBELL', 'BODYWEIGHT']);

// ---------------------------------------------------------------------------
// GET /v1/calendar/events?from=&to=
// ---------------------------------------------------------------------------

async function getEvents(req, res, next) {
  try {
    const userId = req.user.id;
    const { from, to } = req.query;
    if (!from || !to) {
      return res.status(400).json({ error: 'Query parameter from dan to (YYYY-MM-DD) wajib diisi' });
    }

    const events = [];

    // 1. Scheduled runs (belum selesai, bukan GYM/REST — GYM ditangani terpisah di bawah)
    const scheduledRes = await query(
      `SELECT id, scheduled_date, workout_type, title, is_completed
       FROM scheduled_workouts
       WHERE user_id = $1 AND scheduled_date BETWEEN $2 AND $3
         AND workout_type NOT IN ('REST', 'GYM') AND is_completed = false`,
      [userId, from, to]
    );
    for (const row of scheduledRes.rows) {
      events.push({
        id: `sched-${row.id}`,
        date: row.scheduled_date.toISOString().slice(0, 10),
        type: 'SCHEDULED_RUN',
        title: row.title || row.workout_type,
        sessionType: row.workout_type,
        distanceKm: null,
        isCompleted: false,
      });
    }

    // 2. Sesi Gym (standalone, workout_type = 'GYM')
    const gymRes = await query(
      `SELECT id, scheduled_date, title, is_completed
       FROM scheduled_workouts
       WHERE user_id = $1 AND scheduled_date BETWEEN $2 AND $3 AND workout_type = 'GYM'`,
      [userId, from, to]
    );
    for (const row of gymRes.rows) {
      events.push({
        id: `gym-${row.id}`,
        date: row.scheduled_date.toISOString().slice(0, 10),
        type: 'GYM',
        title: row.title || 'Gym Strength',
        sessionType: 'GYM',
        distanceKm: null,
        isCompleted: row.is_completed,
      });
    }

    // 3. Completed runs (aktivitas aktual dari Strava/FIT)
    const completedRes = await query(
      `SELECT ea.id, ea.title, ea.distance_km, COALESCE(sw.scheduled_date, ea.created_at::date) AS event_date
       FROM executed_activities ea
       LEFT JOIN scheduled_workouts sw ON ea.scheduled_workout_id = sw.id
       WHERE ea.user_id = $1 AND COALESCE(sw.scheduled_date, ea.created_at::date) BETWEEN $2 AND $3`,
      [userId, from, to]
    );
    for (const row of completedRes.rows) {
      events.push({
        id: `exec-${row.id}`,
        date: row.event_date.toISOString().slice(0, 10),
        type: 'COMPLETED_RUN',
        title: row.title || 'Lari Selesai',
        distanceKm: row.distance_km != null ? Number(row.distance_km) : null,
        isCompleted: true,
      });
    }

    // 4. Race day
    const raceRes = await query(
      `SELECT target_race_name, target_race_date FROM athlete_baselines
       WHERE user_id = $1 AND target_race_date BETWEEN $2 AND $3`,
      [userId, from, to]
    );
    for (const row of raceRes.rows) {
      events.push({
        id: `race-${row.target_race_date.toISOString().slice(0, 10)}`,
        date: row.target_race_date.toISOString().slice(0, 10),
        type: 'RACE_DAY',
        title: row.target_race_name || 'Race Day',
        distanceKm: null,
        isCompleted: false,
      });
    }

    res.json(events);
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// GET /v1/availability
// ---------------------------------------------------------------------------

async function getAvailability(req, res, next) {
  try {
    const userId = req.user.id;
    const { rows } = await query(
      `SELECT day_of_week, activity_preference, max_duration_minutes, equipment_type
       FROM user_availability WHERE user_id = $1 ORDER BY day_of_week ASC`,
      [userId]
    );
    res.json(
      rows.map((r) => ({
        dayOfWeek: r.day_of_week,
        activityPreference: r.activity_preference,
        maxDurationMinutes: r.max_duration_minutes,
        equipmentType: r.equipment_type,
      }))
    );
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// PUT /v1/availability
// ---------------------------------------------------------------------------

async function putAvailability(req, res, next) {
  try {
    const userId = req.user.id;
    const { days } = req.body;

    if (!Array.isArray(days) || days.length === 0) {
      return res.status(400).json({ error: 'Field days (array) wajib diisi' });
    }

    for (const d of days) {
      if (typeof d.dayOfWeek !== 'number' || d.dayOfWeek < 0 || d.dayOfWeek > 6) {
        return res.status(400).json({ error: `dayOfWeek tidak valid: ${d.dayOfWeek}` });
      }
      if (!VALID_ACTIVITY_PREFS.has(d.activityPreference)) {
        return res.status(400).json({ error: `activityPreference tidak valid: ${d.activityPreference}` });
      }
      if (d.equipmentType != null && !VALID_EQUIPMENT.has(d.equipmentType)) {
        return res.status(400).json({ error: `equipmentType tidak valid: ${d.equipmentType}` });
      }
      if (typeof d.maxDurationMinutes !== 'number' || d.maxDurationMinutes < 0) {
        return res.status(400).json({ error: `maxDurationMinutes tidak valid: ${d.maxDurationMinutes}` });
      }
    }

    await withTransaction(async (client) => {
      for (const d of days) {
        await client.query(
          `INSERT INTO user_availability (user_id, day_of_week, activity_preference, max_duration_minutes, equipment_type)
           VALUES ($1,$2,$3,$4,$5)
           ON CONFLICT (user_id, day_of_week)
           DO UPDATE SET activity_preference = $3, max_duration_minutes = $4, equipment_type = $5`,
          [userId, d.dayOfWeek, d.activityPreference, d.maxDurationMinutes, d.equipmentType || null]
        );
      }
    });

    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

module.exports = { getEvents, getAvailability, putAvailability };
