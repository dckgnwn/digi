'use strict';

/**
 * src/controllers/webhookController.js
 * -----------------------------------------------------------------------
 * Menangani:
 *   - GET  /api/v1/strava/webhook          (handshake verifikasi)
 *   - POST /api/v1/strava/webhook          (event receiver)
 *   - POST /api/v1/telemetry/upload-fit    (upload manual file .FIT)
 *
 * Pipeline pemrosesan aktivitas (dipakai oleh kedua sumber: Strava & FIT
 * manual) disatukan dalam `_processCompletedActivity()` agar logikanya
 * konsisten terlepas dari sumber datanya.
 * -----------------------------------------------------------------------
 */

const crypto = require('crypto');
const { query, withTransaction } = require('../config/db');
const stravaService = require('../services/stravaService');
const fitParserService = require('../services/fitParserService');
const scienceEngine = require('../services/scienceEngine');
const geminiCoachService = require('../services/geminiCoachService');
const adaptiveEngine = require('../services/adaptiveEngine');
const weatherService = require('../services/weatherService');

const STRAVA_WEBHOOK_VERIFY_TOKEN = process.env.STRAVA_WEBHOOK_VERIFY_TOKEN;
const RUNNING_ACTIVITY_TYPES = new Set(['Run', 'TrailRun', 'VirtualRun']);

// ---------------------------------------------------------------------------
// UTILITAS
// ---------------------------------------------------------------------------

function _timingSafeEqual(a, b) {
  const bufA = Buffer.from(String(a || ''));
  const bufB = Buffer.from(String(b || ''));
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function _toDateOnlyString(date) {
  return date.toISOString().slice(0, 10);
}

/** Ambil baseline (LTHR/HRmax/HRrest) atlet; lempar error jelas jika belum diisi. */
async function _getAthleteBaseline(userId) {
  const { rows } = await query(`SELECT lthr, max_hr, resting_hr FROM athlete_baselines WHERE user_id = $1`, [userId]);
  if (rows.length === 0 || !rows[0].lthr) {
    throw new Error(`Athlete baseline (LTHR) belum diisi untuk user ${userId} — tidak bisa menghitung TSS. Lengkapi via PUT /v1/athlete/baseline`);
  }
  return { lthr: rows[0].lthr, maxHr: rows[0].max_hr, restingHr: rows[0].resting_hr };
}

// ---------------------------------------------------------------------------
// PIPELINE UTAMA — DIPAKAI OLEH WEBHOOK STRAVA & UPLOAD FIT MANUAL
// ---------------------------------------------------------------------------

/**
 * Proses satu aktivitas lari yang sudah selesai: hitung TSS/cardiac drift,
 * update CTL/ATL/TSB, audit via Gemini, adaptive reschedule jika perlu, dan
 * catat coaching_logs.
 *
 * @param {object} p
 * @param {string} p.userId
 * @param {string} p.source 'strava' | 'manual_fit'
 * @param {string|null} p.externalActivityId
 * @param {string} p.title
 * @param {Date} p.activityDate tanggal/waktu mulai aktivitas
 * @param {number} p.distanceKm
 * @param {number} p.durationMinutes
 * @param {number} p.avgHR
 * @param {number|null} p.maxHR
 * @param {number|null} p.avgCadenceSpm
 * @param {number|null} p.weatherTempC suhu saat sesi jika SUDAH diketahui (override manual);
 *        jika null dan p.lat/p.lng tersedia, akan diambil otomatis dari weatherService
 * @param {number|null} p.lat lintang lokasi mulai aktivitas (untuk lookup cuaca otomatis)
 * @param {number|null} p.lng bujur lokasi mulai aktivitas (untuk lookup cuaca otomatis)
 * @param {Array<object>|null} p.telemetry1Hz array telemetri (bentuk fitParserService atau stravaService)
 * @returns {Promise<object>} ringkasan hasil pemrosesan
 */
async function _processCompletedActivity(p) {
  const {
    userId, source, externalActivityId, title, activityDate,
    distanceKm, durationMinutes, avgHR, maxHR, avgCadenceSpm,
    weatherTempC, lat, lng, telemetry1Hz,
  } = p;

  const activityDateStr = _toDateOnlyString(activityDate);
  const avgPaceSecKm = distanceKm > 0 ? Math.round((durationMinutes * 60) / distanceKm) : null;

  // Resolusi suhu: pakai nilai eksplisit jika diberikan, else coba lookup
  // otomatis dari koordinat GPS aktivitas (Open-Meteo, keyless).
  let resolvedWeatherTempC = weatherTempC ?? null;
  if (resolvedWeatherTempC == null && lat != null && lng != null) {
    resolvedWeatherTempC = await weatherService.getTemperatureAtActivity({
      lat, lng, isoDateTime: activityDate.toISOString(),
    });
  }

  // 1. TSS
  const baseline = await _getAthleteBaseline(userId);
  const tssScore = avgHR ? scienceEngine.calculateTSS(durationMinutes, avgHR, baseline.lthr) : null;

  // 2. Cardiac Drift (jika telemetri tersedia)
  let cardiacDriftPct = null;
  if (Array.isArray(telemetry1Hz) && telemetry1Hz.length >= 20) {
    try {
      const drift = fitParserService.calculateCardiacDriftFromTelemetry(telemetry1Hz);
      cardiacDriftPct = drift.decouplingPct;
    } catch (err) {
      console.warn(`[webhookController] Cardiac drift tidak dapat dihitung untuk user ${userId}:`, err.message);
    }
  }

  // 3. Simpan executed_activity + update CTL/ATL/TSB dalam satu transaksi
  const { executedActivityId, tsb, ctl, atl, scheduledWorkout } = await withTransaction(async (client) => {
    const schedRes = await client.query(
      `SELECT * FROM scheduled_workouts WHERE user_id = $1 AND scheduled_date = $2 ORDER BY created_at ASC LIMIT 1`,
      [userId, activityDateStr]
    );
    const matchedSchedule = schedRes.rows[0] || null;

    const insertRes = await client.query(
      `INSERT INTO executed_activities
        (user_id, scheduled_workout_id, source, external_activity_id, title, distance_km,
         duration_minutes, avg_pace_sec, avg_hr, max_hr, avg_cadence, tss_score, cardiac_drift_pct, telemetry_1hz)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       ON CONFLICT (source, external_activity_id) WHERE external_activity_id IS NOT NULL
       DO UPDATE SET distance_km=$6, duration_minutes=$7, avg_pace_sec=$8, avg_hr=$9, max_hr=$10,
                     avg_cadence=$11, tss_score=$12, cardiac_drift_pct=$13, telemetry_1hz=$14
       RETURNING id`,
      [
        userId, matchedSchedule?.id || null, source, externalActivityId, title, distanceKm,
        durationMinutes, avgPaceSecKm, avgHR, maxHR, avgCadenceSpm, tssScore, cardiacDriftPct,
        telemetry1Hz ? JSON.stringify(telemetry1Hz) : null,
      ]
    );
    const executedActivityId = insertRes.rows[0].id;

    if (matchedSchedule) {
      await client.query(`UPDATE scheduled_workouts SET is_completed = true, updated_at = now() WHERE id = $1`, [matchedSchedule.id]);
    }

    // Update CTL/ATL/TSB
    const prev = await client.query(
      `SELECT ctl, atl FROM daily_readiness WHERE user_id = $1 AND date < $2 ORDER BY date DESC LIMIT 1`,
      [userId, activityDateStr]
    );
    const prevCTL = prev.rows.length > 0 ? Number(prev.rows[0].ctl) : 0;
    const prevATL = prev.rows.length > 0 ? Number(prev.rows[0].atl) : 0;

    const loadResult = scienceEngine.updateCTL_ATL_TSB(prevCTL, prevATL, tssScore || 0);

    await client.query(
      `INSERT INTO daily_readiness (user_id, date, ctl, atl, tsb)
       VALUES ($1,$2,$3,$4,$5)
       ON CONFLICT (user_id, date) DO UPDATE SET ctl=$3, atl=$4, tsb=$5`,
      [userId, activityDateStr, loadResult.ctl, loadResult.atl, loadResult.tsb]
    );

    // Estimasi & catat VDOT — HANYA valid untuk usaha aerobik steady-state.
    // Interval/tempo dilewati karena hubungan pace:HR-nya bukan steady-state
    // sehingga estimasi Swain-regression tidak berlaku (akan menyesatkan tren).
    const nonSteadyTypes = new Set(['INTERVAL', 'TEMPO']);
    const sessionType = matchedSchedule?.workout_type;
    if (avgHR && baseline.maxHr && baseline.restingHr && !nonSteadyTypes.has(sessionType)) {
      try {
        const estimatedVdot = scienceEngine.estimateVDOTFromTraining({
          distanceMeters: distanceKm * 1000,
          timeSeconds: durationMinutes * 60,
          avgHR,
          hrMax: baseline.maxHr,
          hrRest: baseline.restingHr,
        });
        await client.query(
          `INSERT INTO vdot_history (user_id, date, vdot, source, source_distance_m, source_time_sec)
           VALUES ($1,$2,$3,'estimated',$4,$5)
           ON CONFLICT (user_id, date) DO UPDATE SET vdot=$3, source_distance_m=$4, source_time_sec=$5`,
          [userId, activityDateStr, estimatedVdot, Math.round(distanceKm * 1000), Math.round(durationMinutes * 60)]
        );
      } catch (err) {
        console.warn(`[webhookController] Gagal estimasi VDOT untuk user ${userId}:`, err.message);
      }
    }

    return {
      executedActivityId,
      tsb: loadResult.tsb,
      ctl: loadResult.ctl,
      atl: loadResult.atl,
      scheduledWorkout: matchedSchedule,
    };
  });

  // 4. Audit via Gemini 3.6 Flash (di luar transaksi — panggilan eksternal)
  let auditResult = null;
  if (scheduledWorkout && scheduledWorkout.prescribed_json && scheduledWorkout.prescribed_json.main_run) {
    try {
      auditResult = await geminiCoachService.auditExecutedRun(scheduledWorkout.prescribed_json, {
        avgPaceSecKm,
        avgHR,
        distanceKm,
        durationMinutes,
        cadenceSpm: avgCadenceSpm,
      });
    } catch (err) {
      console.error(`[webhookController] Gagal audit Gemini untuk user ${userId}:`, err.message);
    }
  }

  // 5. Adaptive rescheduling jika ada pelanggaran zone/fatigue
  let adjustmentResult = null;
  const tsbCritical = tsb < adaptiveEngine.TSB_WALK_THRESHOLD;
  const needsAdjustment = (auditResult && (auditResult.ego_running_detected || auditResult.cancel_tomorrow_interval)) || tsbCritical;

  if (needsAdjustment) {
    try {
      adjustmentResult = await adaptiveEngine.autoAdjustSchedule(userId, {
        session_date: activityDateStr,
        ego_running_detected: auditResult ? auditResult.ego_running_detected : false,
        cancel_tomorrow_interval: auditResult ? auditResult.cancel_tomorrow_interval : false,
        tsb,
        weatherTempC: resolvedWeatherTempC,
        executed_activity_id: executedActivityId,
        schedule_adjustment_reason:
          auditResult?.schedule_adjustment_reason ||
          `TSB kritis (${tsb}) terdeteksi setelah sesi ${activityDateStr}.`,
      });
    } catch (err) {
      console.error(`[webhookController] Gagal auto-adjust schedule untuk user ${userId}:`, err.message);
    }
  }

  // 6. Catat coaching_logs
  await query(
    `INSERT INTO coaching_logs (user_id, executed_activity_id, evaluation_summary, ai_response_json, schedule_adjusted)
     VALUES ($1,$2,$3,$4,$5)`,
    [
      userId,
      executedActivityId,
      auditResult ? auditResult.audit_summary : 'Tidak ada resep terjadwal untuk tanggal ini — audit dilewati.',
      JSON.stringify({ auditResult, tsb, ctl, atl, adjustmentResult }),
      Boolean(adjustmentResult),
    ]
  );

  return { executedActivityId, tssScore, cardiacDriftPct, tsb, ctl, atl, auditResult, adjustmentResult, weatherTempC: resolvedWeatherTempC };
}

// ---------------------------------------------------------------------------
// 1. GET /api/v1/strava/webhook — HANDSHAKE VERIFIKASI
// ---------------------------------------------------------------------------

function handleWebhookVerification(req, res) {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (!STRAVA_WEBHOOK_VERIFY_TOKEN) {
    console.error('[webhookController] STRAVA_WEBHOOK_VERIFY_TOKEN belum diset di environment variables');
    return res.status(500).json({ error: 'Konfigurasi server tidak lengkap' });
  }

  if (mode === 'subscribe' && _timingSafeEqual(token, STRAVA_WEBHOOK_VERIFY_TOKEN)) {
    console.log('[webhookController] Verifikasi webhook Strava berhasil.');
    return res.status(200).json({ 'hub.challenge': challenge });
  }

  console.warn('[webhookController] Verifikasi webhook Strava GAGAL — token tidak cocok atau mode salah.');
  return res.status(403).send('Forbidden');
}

// ---------------------------------------------------------------------------
// 2. POST /api/v1/strava/webhook — EVENT RECEIVER
// ---------------------------------------------------------------------------

async function handleWebhookEvent(req, res) {
  // WAJIB: ack 200 dalam <2 detik, atau Strava akan retry hingga 3x.
  res.status(200).json({ received: true });

  const event = req.body;
  if (!event || event.object_type !== 'activity' || event.aspect_type !== 'create') {
    return; // event bukan pembuatan aktivitas baru -> tidak relevan untuk pipeline ini
  }

  const { object_id: activityId, owner_id: stravaAthleteId } = event;

  try {
    const userId = await stravaService.findUserIdByStravaAthleteId(stravaAthleteId);
    if (!userId) {
      console.warn(`[webhookController] Tidak ditemukan user internal untuk strava_athlete_id=${stravaAthleteId}`);
      return;
    }

    const accessToken = await stravaService.getValidStravaAccessToken(userId);
    const details = await stravaService.getStravaActivityDetails(activityId, accessToken);

    if (!RUNNING_ACTIVITY_TYPES.has(details.type)) {
      console.log(`[webhookController] Aktivitas ${activityId} bertipe '${details.type}', bukan lari — dilewati.`);
      return;
    }

    let telemetry1Hz = null;
    try {
      telemetry1Hz = await stravaService.getStravaActivityStreams(activityId, accessToken);
    } catch (err) {
      console.warn(`[webhookController] Gagal fetch streams aktivitas ${activityId}:`, err.message);
    }

    const result = await _processCompletedActivity({
      userId,
      source: 'strava',
      externalActivityId: String(activityId),
      title: details.name || `Strava Activity ${activityId}`,
      activityDate: new Date(details.start_date),
      distanceKm: details.distance / 1000,
      durationMinutes: details.moving_time / 60,
      avgHR: details.average_heartrate || null,
      maxHR: details.max_heartrate || null,
      avgCadenceSpm: typeof details.average_cadence === 'number' ? Math.round(details.average_cadence * 2) : null,
      weatherTempC: null,
      lat: Array.isArray(details.start_latlng) && details.start_latlng.length === 2 ? details.start_latlng[0] : null,
      lng: Array.isArray(details.start_latlng) && details.start_latlng.length === 2 ? details.start_latlng[1] : null,
      telemetry1Hz,
    });

    console.log(`[webhookController] Aktivitas Strava ${activityId} berhasil diproses untuk user ${userId}:`, {
      tssScore: result.tssScore,
      tsb: result.tsb,
      verdict: result.auditResult?.verdict,
    });
  } catch (err) {
    console.error(`[webhookController] Gagal memproses webhook event aktivitas ${activityId}:`, err);
  }
}

// ---------------------------------------------------------------------------
// 3. POST /api/v1/telemetry/upload-fit — UPLOAD MANUAL
// ---------------------------------------------------------------------------

async function uploadFitTelemetry(req, res) {
  try {
    if (!req.file || !req.file.buffer) {
      return res.status(400).json({ error: 'File .FIT wajib disertakan pada field multipart "fitFile"' });
    }

    // FIX KEAMANAN (Fase 5): userId sekarang SELALU dari req.user.id, hasil
    // verifikasi JWT oleh middleware requireAuth — bukan lagi dari req.body
    // yang bisa dipalsukan siapa pun untuk meng-upload atas nama user lain.
    const userId = req.user.id;

    let parsed;
    try {
      parsed = fitParserService.parseFitBuffer(req.file.buffer);
    } catch (err) {
      return res.status(422).json({ error: `File .FIT tidak valid: ${err.message}` });
    }

    const { summary, telemetry1Hz, parseWarnings } = parsed;

    const result = await _processCompletedActivity({
      userId,
      source: 'manual_fit',
      externalActivityId: null,
      title: req.body.title || 'Upload FIT Manual',
      activityDate: new Date(summary.startTime),
      distanceKm: summary.distanceMeters / 1000,
      durationMinutes: summary.durationSec / 60,
      avgHR: summary.avgHR,
      maxHR: summary.maxHR,
      avgCadenceSpm: summary.avgCadenceSpm,
      weatherTempC: req.body.weatherTempC ? Number(req.body.weatherTempC) : null,
      lat: summary.startLat,
      lng: summary.startLng,
      telemetry1Hz,
    });

    return res.status(201).json({ summary, parseWarnings, ...result });
  } catch (err) {
    console.error('[webhookController] Gagal memproses upload FIT manual:', err);
    return res.status(500).json({ error: err.message || 'Internal Server Error saat memproses file .FIT' });
  }
}

module.exports = {
  handleWebhookVerification,
  handleWebhookEvent,
  uploadFitTelemetry,
  _processCompletedActivity, // diekspos untuk unit testing pipeline tanpa HTTP layer
};
