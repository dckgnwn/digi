'use strict';

const authService = require('../services/authService');

async function handleRegister(req, res) {
  try {
    const { email, password, fullName, weightKg, heightCm } = req.body;
    const result = await authService.registerUser({ email, password, fullName, weightKg, heightCm });
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

async function handleLogin(req, res) {
  try {
    const { email, password } = req.body;
    const result = await authService.loginUser({ email, password });
    res.status(200).json(result);
  } catch (err) {
    res.status(401).json({ error: err.message });
  }
}

async function handleMe(req, res, next) {
  try {
    const user = await authService.getUserById(req.user.id);
    if (!user) return res.status(404).json({ error: 'User tidak ditemukan' });
    res.json(user);
  } catch (err) {
    next(err);
  }
}

async function handleRefresh(req, res) {
  try {
    const { refreshToken } = req.body;
    const result = await authService.rotateRefreshToken(refreshToken);
    res.status(200).json(result);
  } catch (err) {
    res.status(401).json({ error: err.message });
  }
}

async function handleLogout(req, res) {
  try {
    const { refreshToken } = req.body;
    await authService.revokeRefreshToken(refreshToken);
    res.status(204).send();
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

async function handleVerifyEmail(req, res) {
  try {
    const { token } = req.body;
    await authService.verifyEmail(token);
    res.status(200).json({ message: 'Email berhasil diverifikasi.' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

async function handleResendVerification(req, res, next) {
  try {
    await authService.resendVerificationEmail(req.user.id);
    res.status(200).json({ message: 'Email verifikasi telah dikirim ulang.' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

async function handleForgotPassword(req, res) {
  try {
    const { email } = req.body;
    await authService.requestPasswordReset(email);
    // Respons SELALU sama terlepas email terdaftar atau tidak (cegah enumerasi).
    res.status(200).json({ message: 'Jika email terdaftar, tautan reset password telah dikirim.' });
  } catch (err) {
    res.status(500).json({ error: 'Terjadi kesalahan. Coba lagi nanti.' });
  }
}

async function handleResetPassword(req, res) {
  try {
    const { token, newPassword } = req.body;
    await authService.resetPassword(token, newPassword);
    res.status(200).json({ message: 'Password berhasil diubah. Silakan login kembali.' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

module.exports = {
  handleRegister,
  handleLogin,
  handleMe,
  handleRefresh,
  handleLogout,
  handleVerifyEmail,
  handleResendVerification,
  handleForgotPassword,
  handleResetPassword,
};
