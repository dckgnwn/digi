'use strict';

const { query } = require('../config/db');

// ---------------------------------------------------------------------------
// GET /v1/activities/:id/telemetry
// ---------------------------------------------------------------------------

async function getActivityTelemetry(req, res, next) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    // Ownership check — pastikan aktivitas ini benar milik user yang login,
    // bukan hanya mengandalkan ID yang ditebak dari luar (IDOR prevention).
    const { rows } = await query(
      `SELECT telemetry_1hz FROM executed_activities WHERE id = $1 AND user_id = $2`,
      [id, userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Aktivitas tidak ditemukan' });
    }

    res.json(rows[0].telemetry_1hz || []);
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// GET /v1/athletes/vdot-history
// ---------------------------------------------------------------------------

async function getVdotHistory(req, res, next) {
  try {
    const userId = req.user.id;
    const { rows } = await query(
      `SELECT date, vdot FROM vdot_history WHERE user_id = $1 ORDER BY date ASC`,
      [userId]
    );
    res.json(rows.map((r) => ({ date: r.date.toISOString().slice(0, 10), vdot: Number(r.vdot) })));
  } catch (err) {
    next(err);
  }
}

module.exports = { getActivityTelemetry, getVdotHistory };
