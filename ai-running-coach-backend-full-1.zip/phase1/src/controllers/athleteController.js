'use strict';

const { query } = require('../config/db');

// ---------------------------------------------------------------------------
// GET /v1/athlete/baseline
// ---------------------------------------------------------------------------

async function getBaseline(req, res, next) {
  try {
    const { rows } = await query(`SELECT * FROM athlete_baselines WHERE user_id = $1`, [req.user.id]);
    res.json(rows[0] || null);
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// PUT /v1/athlete/baseline
// ---------------------------------------------------------------------------

/**
 * Upsert baseline fisiologis atlet. Endpoint ini WAJIB dipanggil sekali
 * setelah registrasi sebelum pipeline TSS/VDOT/guardrail bisa berjalan
 * (lihat webhookController._getAthleteLTHR yang akan menolak proses
 * aktivitas tanpa baseline ini).
 */
async function putBaseline(req, res, next) {
  try {
    const userId = req.user.id;
    const {
      maxHr, lthr, restingHr, vdot,
      targetRaceName, targetRaceDistanceKm, targetRaceDate, targetRaceTimeSeconds,
    } = req.body;

    if (!maxHr || !lthr || !restingHr) {
      return res.status(400).json({ error: 'maxHr, lthr, dan restingHr wajib diisi' });
    }
    if (lthr >= maxHr) {
      return res.status(400).json({ error: 'lthr harus lebih kecil dari maxHr' });
    }
    if (restingHr >= lthr) {
      return res.status(400).json({ error: 'restingHr harus lebih kecil dari lthr' });
    }

    const { rows } = await query(
      `INSERT INTO athlete_baselines
        (user_id, max_hr, lthr, resting_hr, vdot, target_race_name, target_race_distance_km, target_race_date, target_race_time_seconds)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (user_id) DO UPDATE SET
         max_hr = $2, lthr = $3, resting_hr = $4, vdot = COALESCE($5, athlete_baselines.vdot),
         target_race_name = $6, target_race_distance_km = $7, target_race_date = $8,
         target_race_time_seconds = $9, updated_at = now()
       RETURNING *`,
      [
        userId, maxHr, lthr, restingHr, vdot || null,
        targetRaceName || null, targetRaceDistanceKm || null, targetRaceDate || null, targetRaceTimeSeconds || null,
      ]
    );

    res.status(200).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { getBaseline, putBaseline };
