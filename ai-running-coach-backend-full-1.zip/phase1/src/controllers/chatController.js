'use strict';

const crypto = require('crypto');
const { query } = require('../config/db');
const geminiCoachService = require('../services/geminiCoachService');

/**
 * Kumpulkan ringkasan konteks atlet untuk dikirim ke Gemini sebagai dasar
 * jawaban chat (bukan permintaan baru ke Gemini untuk audit/resep — hanya
 * data yang sudah tersedia di database).
 */
async function _buildChatContext(userId) {
  const [loadRes, baselineRes, prescriptionRes] = await Promise.all([
    query(`SELECT date, ctl, atl, tsb FROM daily_readiness WHERE user_id = $1 ORDER BY date DESC LIMIT 1`, [userId]),
    query(`SELECT vdot, target_race_name, target_race_date, target_race_distance_km FROM athlete_baselines WHERE user_id = $1`, [userId]),
    query(
      `SELECT workout_type, prescribed_json FROM scheduled_workouts
       WHERE user_id = $1 AND scheduled_date = CURRENT_DATE ORDER BY created_at ASC LIMIT 1`,
      [userId]
    ),
  ]);

  return {
    training_load_terkini: loadRes.rows[0] || null,
    baseline_atlet: baselineRes.rows[0] || null,
    resep_hari_ini: prescriptionRes.rows[0]?.prescribed_json || null,
  };
}

// ---------------------------------------------------------------------------
// POST /v1/coach/chat
// ---------------------------------------------------------------------------

async function postChatMessage(req, res, next) {
  try {
    const userId = req.user.id;
    const { message } = req.body;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({ error: 'Field message wajib diisi' });
    }

    const contextData = await _buildChatContext(userId);
    const replyText = await geminiCoachService.chatWithCoach(contextData, message.trim());

    res.json({
      id: crypto.randomUUID(),
      role: 'coach',
      content: replyText,
      createdAt: new Date().toISOString(),
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { postChatMessage };
