'use strict';

/**
 * src/controllers/dashboardController.js
 * -----------------------------------------------------------------------
 * Mengimplementasikan kontrak endpoint yang didokumentasikan di frontend
 * Fase 4 (lib/api.ts). userId SELALU dari req.user.id (hasil requireAuth),
 * TIDAK PERNAH dari query/body — menutup celah spoofing userId.
 * -----------------------------------------------------------------------
 */

const { query } = require('../config/db');
const scienceEngine = require('../services/scienceEngine');
const adaptiveEngine = require('../services/adaptiveEngine');
const stravaService = require('../services/stravaService');
const { _processCompletedActivity } = require('./webhookController');

const RUNNING_ACTIVITY_TYPES = new Set(['Run', 'TrailRun', 'VirtualRun']);

// ---------------------------------------------------------------------------
// GET /v1/dashboard/overview
// ---------------------------------------------------------------------------

async function getOverview(req, res, next) {
  try {
    const userId = req.user.id;

    const loadRes = await query(
      `SELECT ctl, atl, tsb FROM daily_readiness WHERE user_id = $1 ORDER BY date DESC LIMIT 1`,
      [userId]
    );
    const ctl = loadRes.rows[0] ? Number(loadRes.rows[0].ctl) : 0;
    const atl = loadRes.rows[0] ? Number(loadRes.rows[0].atl) : 0;
    const tsb = loadRes.rows[0] ? Number(loadRes.rows[0].tsb) : 0;

    const lastSyncRes = await query(
      `SELECT MAX(created_at) AS last_sync FROM executed_activities WHERE user_id = $1 AND source = 'strava'`,
      [userId]
    );

    const lastActivityRes = await query(
      `SELECT id, cardiac_drift_pct FROM executed_activities
       WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [userId]
    );

    res.json({
      readinessScorePct: scienceEngine.tsbToReadinessPct(tsb),
      tsb,
      ctl,
      atl,
      readinessStatus: scienceEngine.readinessStatusFromTsb(tsb),
      lastStravaSyncAt: lastSyncRes.rows[0]?.last_sync || null,
      lastExecutedActivityId: lastActivityRes.rows[0]?.id || null,
      lastActivityCardiacDriftPct:
        lastActivityRes.rows[0]?.cardiac_drift_pct != null ? Number(lastActivityRes.rows[0].cardiac_drift_pct) : null,
    });
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// GET /v1/dashboard/briefing
// ---------------------------------------------------------------------------

async function getBriefing(req, res, next) {
  try {
    const userId = req.user.id;

    const { rows } = await query(
      `SELECT cl.evaluation_summary, cl.ai_response_json, cl.created_at
       FROM coaching_logs cl
       JOIN executed_activities ea ON cl.executed_activity_id = ea.id
       LEFT JOIN scheduled_workouts sw ON ea.scheduled_workout_id = sw.id
       WHERE ea.user_id = $1
         AND COALESCE(sw.scheduled_date, ea.created_at::date) = CURRENT_DATE
       ORDER BY cl.created_at DESC LIMIT 1`,
      [userId]
    );

    if (rows.length === 0) {
      return res.json(null);
    }

    const row = rows[0];
    const payload = row.ai_response_json || {};
    const auditResult = payload.auditResult || null;

    res.json({
      auditSummary: row.evaluation_summary,
      verdict: auditResult?.verdict || 'OTHER',
      reprimandMessage: auditResult?.reprimand_message || null,
      generatedAt: row.created_at,
    });
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// GET /v1/dashboard/today-prescription
// ---------------------------------------------------------------------------

async function getTodayPrescription(req, res, next) {
  try {
    const userId = req.user.id;

    const { rows } = await query(
      `SELECT prescribed_json FROM scheduled_workouts
       WHERE user_id = $1 AND scheduled_date = CURRENT_DATE
       ORDER BY created_at ASC LIMIT 1`,
      [userId]
    );

    if (rows.length === 0 || !rows[0].prescribed_json) {
      return res.json(null);
    }

    res.json(rows[0].prescribed_json);
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// POST /v1/coach/request-adjustment
// ---------------------------------------------------------------------------

/**
 * Memicu ulang audit + adaptive reschedule secara manual (mis. user merasa
 * tidak enak badan dan ingin Coach meninjau ulang jadwal besok tanpa
 * menunggu sinkronisasi aktivitas baru).
 */
async function requestAdjustment(req, res, next) {
  try {
    const userId = req.user.id;

    const loadRes = await query(
      `SELECT date, tsb FROM daily_readiness WHERE user_id = $1 ORDER BY date DESC LIMIT 1`,
      [userId]
    );
    if (loadRes.rows.length === 0) {
      return res.status(400).json({ error: 'Belum ada data training load untuk dievaluasi' });
    }
    const { date: lastDate, tsb } = loadRes.rows[0];
    const lastDateStr = lastDate.toISOString().slice(0, 10);

    const result = await adaptiveEngine.autoAdjustSchedule(userId, {
      session_date: lastDateStr,
      ego_running_detected: false,
      cancel_tomorrow_interval: false,
      tsb: Number(tsb),
      weatherTempC: null,
      executed_activity_id: null,
      schedule_adjustment_reason: 'Permintaan peninjauan manual oleh atlet melalui dashboard.',
    });

    const downgraded = result.downgradeType != null;
    res.json({
      message: downgraded
        ? `Jadwal besok disesuaikan menjadi ${result.downgradeType} berdasarkan TSB terkini (${tsb}).`
        : `TSB terkini (${tsb}) masih dalam batas aman — tidak ada perubahan jadwal yang diperlukan.`,
    });
  } catch (err) {
    next(err);
  }
}

// ---------------------------------------------------------------------------
// POST /v1/strava/sync — pull manual (fallback di luar webhook push)
// ---------------------------------------------------------------------------

async function syncStrava(req, res, next) {
  try {
    const userId = req.user.id;

    const integrationRes = await query(`SELECT strava_athlete_id FROM user_integrations WHERE user_id = $1`, [userId]);
    if (integrationRes.rows.length === 0 || !integrationRes.rows[0].strava_athlete_id) {
      return res.status(400).json({ error: 'Akun Strava belum terhubung' });
    }

    const accessToken = await stravaService.getValidStravaAccessToken(userId);

    // Strava tidak punya endpoint "list aktivitas sejak webhook terakhir" yang
    // sederhana selain /athlete/activities dengan paginasi waktu — di sini kita
    // ambil aktivitas dalam 3 hari terakhir sebagai jendela sinkronisasi manual.
    const afterEpoch = Math.floor(Date.now() / 1000) - 3 * 24 * 60 * 60;
    const response = await fetch(
      `https://www.strava.com/api/v3/athlete/activities?after=${afterEpoch}&per_page=30`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Gagal mengambil daftar aktivitas Strava (HTTP ${response.status}): ${errText}`);
    }
    const activities = await response.json();
    const runs = activities.filter((a) => RUNNING_ACTIVITY_TYPES.has(a.type));

    let newActivities = 0;
    for (const activity of runs) {
      const existing = await query(
        `SELECT id FROM executed_activities WHERE source = 'strava' AND external_activity_id = $1`,
        [String(activity.id)]
      );
      if (existing.rows.length > 0) continue; // sudah diproses sebelumnya (idempotent)

      let telemetry1Hz = null;
      try {
        telemetry1Hz = await stravaService.getStravaActivityStreams(activity.id, accessToken);
      } catch (err) {
        console.warn(`[dashboardController] Gagal fetch streams aktivitas ${activity.id}:`, err.message);
      }

      await _processCompletedActivity({
        userId,
        source: 'strava',
        externalActivityId: String(activity.id),
        title: activity.name || `Strava Activity ${activity.id}`,
        activityDate: new Date(activity.start_date),
        distanceKm: activity.distance / 1000,
        durationMinutes: activity.moving_time / 60,
        avgHR: activity.average_heartrate || null,
        maxHR: activity.max_heartrate || null,
        avgCadenceSpm: typeof activity.average_cadence === 'number' ? Math.round(activity.average_cadence * 2) : null,
        weatherTempC: null,
        lat: Array.isArray(activity.start_latlng) && activity.start_latlng.length === 2 ? activity.start_latlng[0] : null,
        lng: Array.isArray(activity.start_latlng) && activity.start_latlng.length === 2 ? activity.start_latlng[1] : null,
        telemetry1Hz,
      });
      newActivities += 1;
    }

    res.json({ synced: true, newActivities });
  } catch (err) {
    next(err);
  }
}

module.exports = { getOverview, getBriefing, getTodayPrescription, requestAdjustment, syncStrava };
