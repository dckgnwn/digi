'use strict';

/**
 * src/routes/apiRoutes.js
 * -----------------------------------------------------------------------
 * Mendaftarkan seluruh endpoint API v1.
 *
 * PEMBAGIAN AKSES:
 *  - PUBLIK + authLimiter (ketat): register, login, refresh, forgot/reset
 *    password, verify-email — rawan brute-force/enumeration.
 *  - PUBLIK tanpa limiter ketat: webhook Strava (diverifikasi mekanisme
 *    Strava sendiri, bukan rate-limit berbasis IP karena Strava bisa
 *    mengirim banyak event legit dari IP yang sama).
 *  - TERPROTEKSI (requireAuth): semua endpoint dashboard/kalender/coach/
 *    telemetry/athlete — userId SELALU diturunkan dari req.user.id.
 * -----------------------------------------------------------------------
 */

const express = require('express');

const webhookController = require('../controllers/webhookController');
const authController = require('../controllers/authController');
const dashboardController = require('../controllers/dashboardController');
const calendarController = require('../controllers/calendarController');
const analyticsController = require('../controllers/analyticsController');
const chatController = require('../controllers/chatController');
const athleteController = require('../controllers/athleteController');

const { requireAuth } = require('../middleware/auth');
const { upload } = require('../middleware/uploadFit');
const { authLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

// ---------------------------------------------------------------------------
// AUTH (publik, dengan rate limit ketat)
// ---------------------------------------------------------------------------
router.post('/v1/auth/register', authLimiter, authController.handleRegister);
router.post('/v1/auth/login', authLimiter, authController.handleLogin);
router.post('/v1/auth/refresh', authLimiter, authController.handleRefresh);
router.post('/v1/auth/logout', authController.handleLogout);
router.get('/v1/auth/me', requireAuth, authController.handleMe);
router.post('/v1/auth/verify-email', authLimiter, authController.handleVerifyEmail);
router.post('/v1/auth/resend-verification', requireAuth, authLimiter, authController.handleResendVerification);
router.post('/v1/auth/forgot-password', authLimiter, authController.handleForgotPassword);
router.post('/v1/auth/reset-password', authLimiter, authController.handleResetPassword);

// ---------------------------------------------------------------------------
// STRAVA WEBHOOK (publik — diverifikasi via mekanisme Strava sendiri)
// ---------------------------------------------------------------------------
router.get('/v1/strava/webhook', webhookController.handleWebhookVerification);
router.post('/v1/strava/webhook', webhookController.handleWebhookEvent);

// ---------------------------------------------------------------------------
// UPLOAD FIT MANUAL (terproteksi)
// ---------------------------------------------------------------------------
router.post(
  '/v1/telemetry/upload-fit',
  requireAuth,
  (req, res, next) => {
    upload.single('fitFile')(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      next();
    });
  },
  webhookController.uploadFitTelemetry
);

// ---------------------------------------------------------------------------
// DASHBOARD (terproteksi)
// ---------------------------------------------------------------------------
router.get('/v1/dashboard/overview', requireAuth, dashboardController.getOverview);
router.get('/v1/dashboard/briefing', requireAuth, dashboardController.getBriefing);
router.get('/v1/dashboard/today-prescription', requireAuth, dashboardController.getTodayPrescription);
router.post('/v1/coach/request-adjustment', requireAuth, dashboardController.requestAdjustment);
router.post('/v1/strava/sync', requireAuth, dashboardController.syncStrava);

// ---------------------------------------------------------------------------
// KALENDER & AVAILABILITY (terproteksi)
// ---------------------------------------------------------------------------
router.get('/v1/calendar/events', requireAuth, calendarController.getEvents);
router.get('/v1/availability', requireAuth, calendarController.getAvailability);
router.put('/v1/availability', requireAuth, calendarController.putAvailability);

// ---------------------------------------------------------------------------
// ANALYTICS (terproteksi)
// ---------------------------------------------------------------------------
router.get('/v1/activities/:id/telemetry', requireAuth, analyticsController.getActivityTelemetry);
router.get('/v1/athletes/vdot-history', requireAuth, analyticsController.getVdotHistory);

// ---------------------------------------------------------------------------
// CHAT COACH (terproteksi)
// ---------------------------------------------------------------------------
router.post('/v1/coach/chat', requireAuth, chatController.postChatMessage);

// ---------------------------------------------------------------------------
// ATHLETE BASELINE / ONBOARDING (terproteksi)
// ---------------------------------------------------------------------------
router.get('/v1/athlete/baseline', requireAuth, athleteController.getBaseline);
router.put('/v1/athlete/baseline', requireAuth, athleteController.putBaseline);

module.exports = router;
