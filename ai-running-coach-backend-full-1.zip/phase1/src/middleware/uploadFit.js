'use strict';

const multer = require('multer');

// Simpan di memori (bukan disk) karena file .FIT langsung diparse jadi buffer,
// tidak perlu disimpan permanen di filesystem server.
const storage = multer.memoryStorage();

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB — cukup untuk file .FIT ultra-long run
  fileFilter: (req, file, cb) => {
    const allowedExt = /\.fit$/i;
    if (!allowedExt.test(file.originalname)) {
      return cb(new Error('Hanya file dengan ekstensi .fit yang diterima'));
    }
    cb(null, true);
  },
});

module.exports = { upload };
