'use strict';

/**
 * src/middleware/auth.js
 * -----------------------------------------------------------------------
 * Middleware requireAuth: satu-satunya sumber kebenaran identitas user
 * untuk seluruh endpoint terproteksi. Controller TIDAK PERNAH mempercayai
 * userId dari query/body client — selalu dari req.user.id (hasil verifikasi
 * signature JWT). Ini menutup celah keamanan di Fase 3 di mana userId bisa
 * dipalsukan lewat field body biasa.
 * -----------------------------------------------------------------------
 */

const { verifyAccessToken } = require('../services/authService');

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ error: 'Token otorisasi tidak ada atau formatnya salah' });
  }

  try {
    const payload = verifyAccessToken(token);
    req.user = { id: payload.sub, email: payload.email };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token tidak valid atau sudah kadaluarsa' });
  }
}

module.exports = { requireAuth };
