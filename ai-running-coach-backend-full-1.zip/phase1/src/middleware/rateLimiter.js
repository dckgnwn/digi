'use strict';

/**
 * src/middleware/rateLimiter.js
 * -----------------------------------------------------------------------
 * Dua tingkat limiter:
 *  - authLimiter: ketat, untuk endpoint login/register/forgot-password —
 *    mencegah brute-force credential guessing & email enumeration spam.
 *  - apiLimiter: longgar, untuk seluruh endpoint terproteksi lainnya —
 *    mencegah penyalahgunaan/DoS tanpa mengganggu pemakaian normal.
 * -----------------------------------------------------------------------
 */

const rateLimit = require('express-rate-limit');

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 menit
  max: 10, // maksimal 10 percobaan per IP per jendela waktu
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan. Coba lagi dalam beberapa menit.' },
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 menit
  max: 120, // 120 request/menit/IP — longgar untuk pemakaian dashboard normal
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak request. Perlambat sedikit.' },
});

module.exports = { authLimiter, apiLimiter };
